﻿<#
    .SYNOPSIS
    Installs all required Windows Server 2012/2012 R2/2016/2019 (Preview) components & optional tools for Lync Server 2013, Skype for Business Server 2015 and 2019.

    .DESCRIPTION
    Configures the necessary prerequisites to install Lync Server 2013/Skype for Business Server 2015/2019 on a Windows Server 2012/2012 R2/2016/2019 server. Optional tools, utilities, and configurations are also available, including those by Microsoft and third party vendors.

    .NOTES
    Version               : 5.5 - See changelog at https://ucunleashed.com/3619 for fixes & changes introduced with each version
    Wish list             : Better error trapping
    Rights Required       : Local administrator on Windows Server for some functions
                          : CsAdministrator for some functions
    Sched Task Required   : No
    Lync/Skype4B versions : Lync Server 2013, Skype for Business Server 2015, Skype for Business Server 2019 Preview (including
                            on Windows Server 2019)
    Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
    Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
    Donations             : https://www.paypal.me/PatRichard
    Dedicated Post        : https://ucunleashed.com/3600
    Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                            script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                            including, without limitation, any implied warranties of merchantability or of fitness for a particular
                            purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                            remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                            without limitation, damages for loss of business profits, business interruption, loss of business
                            information, or other pecuniary loss) arising out of the use of or inability to use the script or
                            documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                            copied from others, may be republished without author(s) express written permission. Author(s) retain the
                            right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                            https://ucunleashed.com/code-disclaimer.
    Acknowledgements      : SP1 install of SQL Express 2012
                            http://blogs.technet.com/b/lyncativity/archive/2012/12/06/preinstalling-sql-express-2012-sp1-for-lync-server-2013.aspx
                          : SQL Management Studio install idea & some related code, and option for non-default SQL install paths from
                            Chris Elliot
                          : Debugging Tools updated default.tmx
                            http://blog.lyncdialog.com/2013/03/inboundrouting-and-outboundrouting-does.html (recommended by @LyncGuy)
                          : Suggestion to deal with proxies for downloads and some related testing from Tom Arbuthnot (@TomArbuthnot)
                          : Initial New-Popup function from Jeff Hicks (@JeffHicks)
                            http://jdhitsolutions.com/blog/2013/04/powershell-popup/
                          : Initial Sysinternals code from
                            http://blogs.microsoft.co.il/blogs/scriptfanatic/archive/2008/09/06/keep-in-sync-with-sysinternals-tools.aspx
                          : Test for proxy
                            http://www.powershellmagazine.com/2013/02/06/pstip-validate-if-proxy-credentials-are-required/
                          : Extra help with SQL path regular expression to also include spaces from David Wyatt
                            http://social.technet.microsoft.com/profile/david%20wyatt/?ws=usercard-mini
                          : Setting Windows Automatic Updates
                            http://smallvoid.com/article/winnt-automatic-updates-config.html
                          : Planning updates for Office Web Apps Server
                            http://technet.microsoft.com/en-us/library/jj219435.aspx
                          : Looking for improper certs
                            http://guybachar.wordpress.com/2014/05/28/find-certificates-that-are-put-in-the-trusted-root-certification-authorities-store- incorrectly-on-the-local-computer/
                          : POODLE attack defense
                            http://masteringlync.com/2014/10/20/poodle-and-lync-server-2013/
                            http://masteringlync.com/2014/10/23/poodle-testing-results-for-lync/
                          : Fabric circular logging
                            http://tomtalks.uk/2014/10/check-you-lync-server-windows-fabric-log-size-with-powershell/
                          : PowerShell tail method
                            http://stackoverflow.com/questions/4426442/unix-tail-equivalent-command-in-windows-powershell
                          : Building a pick list
                            http://quickclix.wordpress.com/2014/10/30/stringarrayasmenu/
                          : Syntax clarification for the -tail option
                            https://social.technet.microsoft.com/Forums/windowsserver/en-US/9f61cd83-5339-4426-ac4f-f8cc0b7627e5/spawning-powershell-in-another-session-and-calling-file-with-spaces?forum=winserverpowershell
                          : Converting subnet masks
                            http://www.indented.co.uk/2010/01/23/powershell-subnet-math/
                          : Silent install of OWAS
                            http://stackoverflow.com/questions/15341177/office-web-apps-unattended-server-installation
                          : Simple input box
                            http://windowsitpro.com/blog/getting-input-and-inputboxes-powershell
                          : Mounting disk images
                            http://blogs.technet.com/b/heyscriptingguy/archive/2012/10/15/oct-15-blog.aspx
                          : Customer config file for PortQryUI
                            http://flinchbot.wordpress.com/2013/05/10/portqueryui-config-xml-file-for-lync/
                          : Unzipping files in PowerShell
                            http://serverfault.com/questions/18872/how-to-zip-unzip-files-in-powershell
                          : Microsoft Lync/Skype for Business WireShark plugin
                            http://www.mylynclab.com/2014/05/microsoft-lync-wireshark-plugin.html
                          : Lync Edge Server replication failed resolution
                            http://lyncuc.blogspot.ca/2013/09/lync-edge-server-replication-failed.html
                          : Silent installation of OWAS language packs
                            http://www.sharepoint13.org/?p=124
                          : Detection of VC++ 2012 installed Version
                            http://stackoverflow.com/questions/18398221/c-redistributable-2012-update-3-detection
                          : Missing Director prereqs
                            http://www.leedesmond.com/weblog/?p=982
                          : Reading XML files 
                            http://stackoverflow.com/questions/18509358/how-to-read-xml-in-powershell
                            http://stackoverflow.com/questions/20433932/determine-xml-node-exists
                            http://stackoverflow.com/questions/1819341/how-to-read-xml-file-from-web-using-powershell
                            http://www.tomsitpro.com/articles/powershell-read-xml-files,2-895.html
                            https://jamesmccaffrey.wordpress.com/2007/12/02/parsing-xml-files-with-powershell/
                            https://www.simple-talk.com/sysadmin/powershell/powershell-data-basics-xml/
                          : Determining forest and domain functional levels
                            http://kpytko.pl/active-directory-domain-services/determine-dfl-and-ffl-using-powershell/
                          : Finding the distinguished name of the current domain
                            http://blogs.msmvps.com/richardsiddaway/2012/01/21/get-the-domain-distinguished-name/
                          : Temporarily block the installation of .NET Framework 4.6.1
                            https://support.microsoft.com/en-us/kb/3133990
                          : Removing .NET Framework 4.6.1
                            http://www.expta.com/2016/02/how-to-uninstall-net-framework-461.html
                          : Fixing missing DLL error when troublshooting 'unhealty' OOS servers
                            https://andikrueger.wordpress.com/2016/06/16/office-online-server-msvcr120-dll-missing/
                            https://social.technet.microsoft.com/Forums/office/en-US/649d8633-0908-4d98-aee0-b81de37d7a51/office-online-server-2016-health- status?forum=OfficeOnlineServer
                            http://blog.chiffers.com/2017/05/17/skype-network-assessment-tool-could-not-load-file-or-assembly/
                          : Enhanced Experience for Meetings Hosted on Skype for Business On-premises
                            https://techcommunity.microsoft.com/t5/Skype-for-Business-Blog/Enhanced-Experience-for-Meetings-Hosted-on-Skype-for-Business-On/ba-p/75347
                          : Adding/removing items from an array
                            http://www.jonathanmedd.net/2014/01/adding-and-removing-items-from-a-powershell-array.html
                          : Old school spinning cursor
                            https://www.reddit.com/r/PowerShell/comments/t00il/oldschool_style_indeterminate_progress_indicator/
                          : Use Powershell to Change Host's FQDN / Suffix (confirmed my thinking)
                            http://www.allthingstechie.net/2015/04/use-powershell-to-change-hosts-fqdn.html
                          : Some great exception handling info
                            https://stackoverflow.com/questions/6779186/powershell-try-catch-finally
                            https://blogs.technet.microsoft.com/heyscriptingguy/2015/09/16/understanding-non-terminating-errors-in-powershell/
                          : Miscleaneous OWAS stuff
                            http://technet.microsoft.com/en-us/library/jj219455.aspx#prerequisites
                            http://hpicao.blogspot.com/2012/11/lync-2013-with-office-web-apps-server.html
                            http://www.wictorwilen.se/office-web-apps-server-2013---machines-are-always-reported-as-unhealthy
                            http://technet.microsoft.com/en-us/library/jj219435.aspx#software
                            https://dmunified.com/2016/05/23/deploy-office-online-server-with-skype-for-business/
                          : .NET versions
                            https://docs.microsoft.com/en-us/dotnet/framework/migration-guide/versions-and-dependencies
                          : Determing calling function from within a function
                            https://stackoverflow.com/questions/3689543/is-there-a-way-to-retrieve-a-powershell-function-name-from-within-a-function
                          : Setting permissions and inheritance on shares
                            https://stackoverflow.com/questions/3282656/setting-inheritance-and-propagation-flags-with-set-acl-and-powershell
                          : Getting AV product status
                            https://jdhitsolutions.com/blog/powershell/5187/get-antivirus-product-status-with-powershell/
                          : Good catch block examples
                            https://stackoverflow.com/questions/6779186/powershell-try-catch-finally
                          : PsCallStack
                            https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/get-pscallstack?view=powershell-6
                          : Get all groups a member belongs to
                            http://techibee.com/active-directory/powershell-how-to-get-all-the-ad-groups-current-user-belongs/1672
                          : Disable SMBv1
                            https://support.microsoft.com/en-us/help/2696547.
    Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
    Limitations           : Only works on Windows Server 2012, Windows Server 2012 R2, Windows Server 2016, and Windows Server 2019.                            This is by design. There are no plans to support any version of Windows Server before 2012. 
                            This script has only been tested against servers configured with the en-US culture.
    Known issues          : Downloading files through a proxy is still somewhat of a kludge, especially if the proxy is not configured
                            in IE.

    .EXAMPLE
    .\Set-CsFeatures.ps1 -Skype4b

    Description
    -----------
    Runs script in Skype for Business 2015 mode. Options chosen while running in this mode are tailored to Skype for Business 2015.

    .EXAMPLE
    .\Set-CsFeatures.ps1 -Skype4b2019

    Description
    -----------
    Runs script in Skype for Business 2019 mode. Options chosen while running in this mode are tailored to Skype for Business 2019.

    .EXAMPLE
    .\Set-CsFeatures.ps1

    Description
    -----------
    Runs script with default values. A prompt will appear to determine what mode it should run. (Lync, Skype for Business 2015, etc.)

    .EXAMPLE
    .\Set-CsFeatures.ps1 -WindowsSource "d:"

    Description
    -----------
    Runs script with the location defined for the Windows Server 2012/2012 R2/2016/2019 installation files

    .EXAMPLE
    .\Set-CsFeatures.ps1 -WindowsSource "d:\images\WindowsServer2016.iso"

    Description
    -----------
    Runs script with the location defined for the ISO image of Windows Server 2012/2012 R2/2016/2019. The script will automatically mount and dismount the .ISO image as needed.

    .EXAMPLE
    .\Set-CsFeatures.ps1 -SQLPath "d:\sqlexpress"

    Description
    -----------
    Runs the script and installs any required SQL Express instances in the specified location

    .EXAMPLE
    .\Set-CsFeatures.ps1 -TargetFolder "d:\installbits"

    Description
    -----------
    Runs the script, and saves any downloaded files and written logs in the specified location instead of the default "c:\_install"

    .EXAMPLE
    .\Set-CsFeatures.ps1 -InitialMenuOption 3

    Description
    -----------
    Runs the script, and automatically starts option 3 (Front End server). Once it's finished with that option, the script functions as normal, and displays the menu. NOTE: only options from the main menu can be specified. Options in submenus are not availabile with -InitialMenuOption.

    .EXAMPLE
    .\Set-CsFeatures.ps1 -tail

    Description
    -----------
    Runs script with default values, but also shows an additional PowerShell window showing a live running logfile.

    .INPUTS
    None. You cannot pipe objects to this script.
#>
#Requires -Version 3.0

[CmdletBinding(SupportsShouldProcess, SupportsPaging, DefaultParameterSetName = 'Default', HelpUri = 'https://ucunleashed.com/3600')]
param(
  # Defines the location for any downloaded files. Defaults to 'c:\_install'. Additionally, log files generated by this script are located in a subfolder of TargetFolder called 'logs'. TargetFolder does not support paths with spaces, but does support non-hidden UNC paths.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'DownloadAll')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [ValidatePattern('(?:[a-zA-Z]\:|\\\\[]\w\.+|\w-\\[\w.]+)\\(?:[\w]+\\)*\w[\w.]+')]
  [string] $TargetFolder = "$env:SystemDrive\_Install",

  # Defines the location of the Windows Server installation files. This is needed to install .Net 3.5 since those files are not installed on the server by default. Defaults to first detected CD-ROM/DVD drive. This can be a local file path, path to an .ISO file, or a non-hidden UNC path.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [Alias('Source')]
  [string] $WindowsSource = $(Get-CimInstance -ClassName 'Win32_LogicalDisk' -Filter 'DriveType=5' | Sort-Object -Property DeviceID | Select-Object -First 1).DeviceId,

  # Defines the desired installation path for SQL Express. Defaults to 'c:\Program Files\Microsoft SQL Server'
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]
  [Parameter(ParameterSetName = 'Mediation')]
  [Parameter(ParameterSetName = 'PChat')]
  [ValidatePattern('^(?:[a-zA-Z]\:|\\\\[\w\.]+\\[\w\.\x20]+)\\(?:[\w\x20]+\\)*\w([\w\.\x20])+$')]
  [string] $SQLPath = "$env:ProgramFiles\Microsoft SQL Server",

  # Allows you to start the script with the option you want, without first displaying the menu.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [ValidateRange(1,98)]
  [int] $InitialMenuOption,

  # If specified, will include SQL Server Management Studio automatically when prereqs are installed for any server that has SQL Express instances. If not specified, a prompt will appear.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]
  [Parameter(ParameterSetName = 'Mediation')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $IncludeSSMS,

  # If specified, will include Telnet automatically when prereqs for Front End servers, Director servers, Mediation servers, Edge servers, and/or Persistent Chat servers are installed. If not specified, a prompt will appear.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $IncludeTelnet,

  # If specified, will include the firewall rules for Get-CsConnections automatically when prereqs for Front End servers are installed. If not specified, a prompt will appear.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'FrontEnd')]
  [switch] $IncludeFW,

  # If specified, tells the script to automatically set the Power Config on the server to High Power. This is instead of the script prompting. This option is available for all server roles.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $IncludeHighPower,

  # If specified, tells the script to automatically include the Skype for Business Online admin tools when installing prerequisites for front-end servers.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'FrontEnd')]
  [switch] $IncludeOnlineAdminTools,

  # If specified, tells the script to include the extra SQL Express instance required for Standard Edition front end servers. This is instead of the script prompting.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'FrontEnd')]
  [switch] $IncludeStandard,

  # This value is only used during mid-prereq reboots. It is automatically set and read by the script, and should never be manually specified.
  # [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'GetInfoFromRegistry')]
  [switch] $GetInfoFromRegistry,

  # Tells this script to not install or configure anything - just download the files. This is useful if you're going to be building servers that do not have Internet access and want to fetch the files beforehand.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [switch] $DownloadOnly,

  # Tells this script to not install or configure anything - just download ALL of the files. This is useful if you're going to be building servers that do not have Internet access and want to fetch the files beforehand.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'DownloadAll')]
  [switch] $DownloadAll,

  # This switch forces the running status to be reset. This option should ONLY be used if the script exits/aborts dirty.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'ClearRunningStatus')]
  [switch] $ClearRunningStatus,

  # When specified, skips the check for Server Core. It is not meant to be called manually.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'DownloadAll')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $SkipCoreCheck,

  # When specified, opens another PowerShell session and tails the log file, similar to *nix. This is really only beneficial during troubleshooting. Note that the tail window may block visibility of some dialog boxes and prompts.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'DownloadAll')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $Tail,

  # When specified, uses values specific to Skype For Business Server 2015 for prerequisites. This also includes SQL Express and SQL Management Studio installations.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'DownloadAll')]
  [Parameter(ParameterSetName = 'DownloadOnly')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]
  [Parameter(ParameterSetName = 'PChat')] 
  [switch] $Skype4b,
  
  # When specified, uses values specific to Skype For Business Server 2019 for prerequisites. This also includes SQL Express and SQL Management Studio installations.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'DownloadAll')]
  [Parameter(ParameterSetName = 'DownloadOnly')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [switch] $Skype4b2019,

  # When specified, skips the check for a newer version of the script. This option is included mainly for when the script reboots the server.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')] 
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $SkipUpdateCheck,

  # When specified, skips the prompt and automatically disables auto updates for Windows Server. If not specified, a prompt is displayed.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $DisableAutoUpdates,

  # When specified, skips the prompt for the installation of the Office Online Server english language pack. If not specifed, a prompt is displayed.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [switch] $IncludeLanguagePack,

  # When specified, skips the configuration of the NICs on edge servers. This requires that you manually complete those steps. This was added because the only methods I've found to do some of the config are extremely kludgy, and can be problematic.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Edge')]
  [switch] $SkipEdgeNicConfig,

  # When specified, will not automatically restart the script after a required reboot. The ONLY time this should be used is if you need to do something before the script starts again.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [Parameter(ParameterSetName = 'PChat')]
  [switch] $SkipAutoStart,

  # When specified, will automatically disable the Windows Action Center prompt when Server Manager is launched on Windows Server 2019.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Default')]
  [Parameter(ParameterSetName = 'Director')]
  [Parameter(ParameterSetName = 'Edge')]
  [Parameter(ParameterSetName = 'FrontEnd')]  
  [Parameter(ParameterSetName = 'Mediation')]  
  [Parameter(ParameterSetName = 'OOS')]
  [switch] $DisableWAC,

  # Used to define the domain suffix applied to edge servers
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Edge')]
  [string] $DomainSuffix,

  # When specified, will disable Microsoft File and Printer Sharing. This is useful when building edge servers. If not specified, a prompt will appear at the appropriate time in the build process.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Edge')]
  [switch] $DisableFPSharing,

  # When specified, will disable LMHosts file lookup. This is useful when building edge servers. If not specified, a prompt will appear at the appropriate time in the build process.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Edge')]
  [switch] $DisableLmHosts,

  # When specified, will disable NetBIOS. This is useful when building edge servers. If not specified, a prompt will appear at the appropriate time in the build process.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Edge')]
  [switch] $DisableNetBios,

  # Automatically adds trusted certificates to edge servers. This includes comodo, digicert, entrust, geotrust, globalsign, godaddy, letsencrypt, networksolutions, ssl, swisssign, symantec, thawte, and wisekey.
  [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Edge')]
  [switch] $IncludeTrustedCerts
) # end of param block
[version] $ScriptVersion = '5.5'
# This is the number of the article on the blog site for this script. This variable is used for update checking, help, etc.
[int] $Article = 3600
[DateTime] $StartTime = Get-Date
# This is where we write data in the registry - mostly for when the script has to restart after a reboot. This is because the Windows built-in runonce option is capped at 250 characters, and we often need much more than that. The script cleans up data under this key as needed. There is no bloat.
[string] $RunOnceRoot = 'HKLM:\SOFTWARE\Innervation\Set-CsFeatures'
[string] $ThisScriptName = $RunOnceRoot | Split-Path -Leaf

# Check for admin access and stop if not detected. That's because many of the tasks in this script require elevated access.
$principal = New-Object -TypeName System.Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
[bool] $IsIntroAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-Not ($IsIntroAdmin)){
  Write-Output -InputObject 'Admin access not detected. This script must run in an elevated PowerShell session. Please restart PowerShell as administrator and try again.'
  Exit
}

# Barf if the script isn't running under a 64bit process. We need full power!
if (-Not ([Environment]::Is64BitProcess) -and (-Not ($DownloadAll)) -and (-Not ($DownloadOnly))){
  Write-Host -Object '
    ┌──────────────────────────────────────────────────────────┐
    │             32bit PowerShell Not Supported               │
    │             ------------------------------               │
    │    Sorry, the 32bit version of PowerShell is not         │
    │    compatible with some of the functions and cmdlets     │
    │    required to configure this server. Please restart     │
    │    this script in a 64bit session of PowerShell.         │
    └──────────────────────────────────────────────────────────┘' -ForegroundColor Red
  Exit
}

#region Functions
function Add-PinnedAppToStartMenu {
  <#
      .SYNOPSIS
      Pins an application to the Windows Server Start Menu

      .DESCRIPTION
      Pins an application to the Windows Server Start Menu

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known      

      .EXAMPLE
      Add-PinnedAppToStartMenu -Path 'c:\Program Files\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe' -Pin

      Description
      -----------
      Would pin OCSLogger to the Start Menu

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  Param (
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [String[]] $Path,

    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'PinnedAppToStartMenuAdd')]
    [switch] $pin,

    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'PinnedAppToStartMenuRemove')]
    [switch] $unpin
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  $Shell = New-Object -ComObject Shell.Application
  $Desktop = $Shell.NameSpace(0X0)
  
  switch ($PsCmdlet.ParameterSetName) {
    PinnedAppToStartMenuRemove{
      [string] $PinVerb = 'Unpin from Start'
    }
    PinnedAppToStartMenuAdd{
      [string] $PinVerb = 'Pin to Start'
    }
  }
  if (Test-Path -Path $path){
    Foreach ($itemPath in $Path)  {      
      $ItemLnk = $Desktop.ParseName($itemPath)
      $ItemVerbs = $ItemLnk.Verbs()
      Foreach ($ItemVerb in $ItemVerbs) {
        If ($ItemVerb.Name.Replace('&','') -match $PinVerb) {
          $ItemVerb.DoIt()
        }
      }
    }
  } else {
    Write-Log -Type Error -message "`"$path`" does not exist" -Indent 1
  }
} # end function Add-PinnedAppToStartMenu

function Add-TrustedRootCertsToEdge {
  <#
      .SYNOPSIS
      Adds the trusted root certs of the most popular certificate authorities to the local server.

      .DESCRIPTION
      Adds the trusted root certs of the most popular certificate authorities (comodo.com, digicert.com, entrust.net, geotrust.com, globalsign.com, godaddy.com, symantec.com, thawte.com, wisekey.com) to the local server.

      .NOTES
      Version               : 1.2
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/3029
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known      
    
      .EXAMPLE
      Add-TrustedRootCertsToEdge -RootCertCa 'https://digicert.com'

      Description
      -----------
      Adds the Digicert root certificate(s).

      .EXAMPLE
      'https://digicert.com' | Add-TrustedRootCertsToEdge 

      Description
      -----------
      Adds the Digicert root certificate(s).

      .INPUTS
      URI object. You can pipe objects to this function.
  #>
  [CmdletBinding(SupportsPaging, HelpUri = 'https://ucunleashed.com/3029')]
  param(
    [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [uri] $rootcertca
  ) # end of param block
  BEGIN{
    Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  }
  PROCESS{
    #$rootcertca | ForEach-Object {    
      try{
        #Write-Log -Type info -Message "Adding $rootcertca to the trusted certification authorities" -Indent 1
        # $null = Invoke-WebRequest -Uri $rootcertca
        # added -UseBasicParsing to deal with issues when the IE initial config isn't completed. It would throw blood here.
        Write-Output -InputObject "Adding $rootcertca"
        $null = Invoke-WebRequest -Uri $rootcertca -UseBasicParsing
      }
      catch{
        #Write-Log -Type Error -Message "Failed adding certificate to the trusted certification authorities. Error was `'$($_.Exception.Message)`'" -NoConsole -Indent 1
        Write-Output -InputObject $($_.Exception.Message)
      }
    #}
  }
  END{
    #Write-Log -Type Divider -NoConsole
  }
} # end function Add-TrustedRootCertsToEdge

function Add-TrustedRootCertsToEdge.old {
  <#
      .SYNOPSIS
      Adds the trusted root certs of the most popular certificate authorities to the local server.

      .DESCRIPTION
      Adds the trusted root certs of the most popular certificate authorities (comodo.com, digicert.com, entrust.net, geotrust.com, globalsign.com, godaddy.com, symantec.com, thawte.com, wisekey.com) to the local server.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/3029
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Limitations           : None known
      Known issues          : None yet, but I'm sure you'll find some!
    
      .EXAMPLE
      Add-TrustedRootCertsToEdge

      Description
      -----------
      

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging, HelpUri = 'https://ucunleashed.com/3029')]
  param(
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [Object[]] $rootcertca = @('https://comodo.com', 'https://digicert.com', 'https://www.entrust.net', 'https://geotrust.com', 'https://www.globalsign.com', 'https://godaddy.com', 'https://letsencrypt.org', 'https://www.networksolutions.com', 'https://www.ssl.com', 'https://www.swisssign.com', 'https://www.symantec.com', 'https://thawte.com', 'https://wisekey.com')
  ) # end of param block
  Write-Log -Type Info -Message 'Adding trusted root certification authorities to edge servers' -NoConsole  
  $rootcertca | ForEach-Object {    
    try{
      Write-Log -Type info -Message "Adding $_ to the trusted certification authorities" -Indent 1
      # $null = Invoke-WebRequest -Uri $_
      # added -UseBasicParsing to deal with issues when the IE initial config isn't completed. It would throw blood here.
      $null = Invoke-WebRequest -Uri $_ -UseBasicParsing
    }
    catch{
      Write-Log -Type Error -Message "Failed adding certificate to the trusted certification authorities. Error was `'$($_.Exception.Message)`'" -NoConsole -Indent 1
    }
  }
  Write-Log -Type Divider -NoConsole
} # end function Add-TrustedRootCertsToEdge

function Disable-Smbv1Protocol {
  <#
      .SYNOPSIS
      

      .DESCRIPTION
      

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known      

      .EXAMPLE
      

      Description
      -----------
      

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  Param (
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  if ($IsSrv2012){
    $IsSmbv1Enabled = (Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol).Enabled
  }    
  if ($IsSrv2012R2 -or $IsSrv2016 -or $IsSrv2019){
    $IsSmbv1Enabled = Get-WindowsFeature -Name FS-SMB1 | Select-Object -ExpandProperty Installed        
  }
  if ($IsSmbv1Enabled){
    Write-Log -Type Info -Message 'SMBv1 is currently enabled.' -Indent 1    
    Write-Log -Type Info -Message 'Disabling SMBv1.' -Indent 1
    try {
      if ($IsSrv2012){
        Set-SmbServerConfiguration -EnableSMB1Protocol $false -Confirm:$false -ErrorAction Stop
      }
      if ($IsSrv2012R2 -or $IsSrv2016 -or $IsSrv2019){
        $null = Disable-WindowsOptionalFeature -Online -FeatureName smb1protocol -NoRestart -ErrorAction Stop
      }
      Write-Log -Type Warn -Message 'SMBv1 disabled. A reboot is required before the change takes effect.' -Indent 1
      $RebootRequired = $true
    }
    catch{
      $_.Exception.Message
    }
  }else{
    Write-Log -Type Info -Message 'SMBv1 already disabled' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Disable-Smb1Protocol

function Disable-WacPrompt {
  <#
      .SYNOPSIS
      Disables the Windows Admin Center prompt in Server Manager.

      .DESCRIPTION
      Disables the Windows Admin Center prompt in Server Manager in Windows Server 2019.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : Windows Server 2019

      .EXAMPLE
      Disable-WacPrompt

      Description
      -----------
      Disables the Windows Admin Center prompt in Server Manager.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  if (-Not($IsSrv2019)){
    Write-Log -Type Info -Message 'Operating system is not Windows Server 2019' -NoConsole -Indent 1
    Write-Log -Type Divider -NoConsole
    Break
  }
  Write-Log -Type Info -Message 'Disable Windows Admin Center prompt'
  Write-Log -Type Info -Message 'Checking Windows Admin Center prompt config'
  if ((Get-ItemProperty -Path 'HKLM:\Software\Microsoft\ServerManager' -Name DoNotPopWACConsoleAtSMLaunch -ErrorAction SilentlyContinue).DoNotPopWACConsoleAtSmLaunch -ne 1){
    if ($DisableWAC -or ((New-Popup -Message 'Disable Windows Admin Center prompt in Windows Server 2019? This may help reduce confusion and conflicts.' -Title 'Disable Windows Action Center prompt?' -Buttons 'YesNo' -Icon Question) -eq 6)){
      Write-Log -Type Info -Message 'Disabling Windows Admin Center prompt' -NoConsole -Indent 1
      Set-ItemProperty -Path 'HKLM:\Software\Microsoft\ServerManager' -Name DoNotPopWACConsoleAtSMLaunch -Value 1
    }else{
      Write-Log -Type Info -Message 'User opted not to disable Windows Admin Center prompt' -NoConsole -Indent 1
    }
  }else{
    Write-Log -Type Info -Message 'Windows Admin Center prompt is already disabled.' -NoConsole -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Disable-WacPrompt

function Get-Folder {
  <#
      .SYNOPSIS
      Displays a folder dialog box, and returns the selected folder. Also allows for a new folder to be created.

      .DESCRIPTION
      Displays a folder dialog box, and returns the selected folder. Also allows for a new folder to be created.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Get-Folder

      Description
      -----------
      Displays a folder dialog box, and returns the selected folder. Also allows for a new folder to be created.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging)]
  param(
    # Message that is displayed to the user when the browse folder dialog box opens
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $Message = 'Select the desired folder',

    <#
        Starting location for the dialog box. Options are:
        http://msdn.microsoft.com/en-us/library/windows/desktop/bb774096    
        ssfALTSTARTUP        = 0x1d,
        ssfAPPDATA           = 0x1a,
        ssfBITBUCKET         = 0x0a,
        ssfCOMMONALTSTARTUP  = 0x1e,
        ssfCOMMONAPPDATA     = 0x23,
        ssfCOMMONDESKTOPDIR  = 0x19,
        ssfCOMMONFAVORITES   = 0x1f,
        ssfCOMMONPROGRAMS    = 0x17,
        ssfCOMMONSTARTMENU   = 0x16,
        ssfCOMMONSTARTUP     = 0x18,
        ssfCONTROLS          = 0x03,
        ssfCOOKIES           = 0x21,
        ssfDESKTOP           = 0x00,
        ssfDESKTOPDIRECTORY  = 0x10,
        ssfDRIVES            = 0x11,
        ssfFAVORITES         = 0x06,
        ssfFONTS             = 0x14,
        ssfHISTORY           = 0x22,
        ssfINTERNETCACHE     = 0x20,
        ssfLOCALAPPDATA      = 0x1c,
        ssfMYPICTURES        = 0x27,
        ssfNETHOOD           = 0x13,
        ssfNETWORK           = 0x12,
        ssfPERSONAL          = 0x05,
        ssfPRINTERS          = 0x04,
        ssfPRINTHOOD         = 0x1b,
        ssfPROFILE           = 0x28,
        ssfPROGRAMFILES      = 0x26,
        ssfPROGRAMFILESx86   = 0x30,
        ssfPROGRAMS          = 0x02,
        ssfRECENT            = 0x08,
        ssfSENDTO            = 0x09,
        ssfSTARTMENU         = 0x0b,
        ssfSTARTUP           = 0x07,
        ssfSYSTEM            = 0x25,
        ssfSYSTEMx86         = 0x29,
        ssfTEMPLATES         = 0x15,
        ssfWINDOWS           = 0x24
    #>
    [Parameter()]
    [int] $path = 0x00
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  [Object] $FolderObject = New-Object -ComObject Shell.Application
  $folder = $FolderObject.BrowseForFolder(0, $message, 0, $path)
  Write-Log -Type Info -Message "Value returned: $($folder.self.path)" -NoConsole
  if ($null -ne $folder) {
    # Write-Log -Type Info -Message "Value returned: $($folder.self.path)" -NoConsole
    return $folder.self.Path
  } else {
    Write-Output -InputObject 'No folder specified'
  }
} # end function Get-Folder

function Get-RunningStatus {
  <#
      .SYNOPSIS
      Gets the current running status of the script.

      .DESCRIPTION
      Gets the current running status of the script. This is done by reading a registry value and returning the results. This is to ensure that only a single instance of the script is running.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Stop-Script
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  if ((Get-ItemProperty -Path $RunOnceRoot -Name 'running' -ErrorAction SilentlyContinue).running -eq 1){
    Write-Log -Type Error -Message 'Script is already running. Call the script with -ClearRunningStatus if you are POSITIVE it is not running (including by other users on the same server).' -Indent 1
    Stop-Script 
  }
} # end function Get-RunningStatus

function Get-UacStatus {
  <#
      .SYNOPSIS
      Gets the current status of User Account Control (UAC) on a computer.

      .DESCRIPTION
      Gets the current status of User Account Control (UAC) on a computer. $true indicates UAC is enabled, $false that it is disabled.

      .NOTES
      Version               : 1.1
      Rights Required       : Local admin on server
      Function Dependencies : Write-Log
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/1026
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Get-UacStatus

      Description
      -----------
      Returns the status of UAC for the local computer. $true if UAC is enabled, $false if disabled.

      .EXAMPLE
      Get-UacStatus -Computer [computer name]

      Description
      -----------
      Returns the status of UAC for the computer specified via -Computer. $true if UAC is enabled, $false if disabled.

      .INPUTS
      None. You cannot pipe objects to this script.

      #Requires -Version 2.0
  #>
  [CmdletBinding(SupportsPaging, HelpUri = 'https://ucunleashed.com/1026')]
  param(
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $Computer
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking UAC configuration'
  [string] $RegistryValue = 'EnableLUA'
  [string] $RegistryPath = 'Software\Microsoft\Windows\CurrentVersion\Policies\System'
  [bool] $UACStatus = $false
  $OpenRegistry = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,$Computer)
  $Subkey = $OpenRegistry.OpenSubKey($RegistryPath,$false)
  $Subkey.ToString() | Out-Null
  $UACStatus = ($Subkey.GetValue($RegistryValue) -eq 1)
  return $UACStatus
} # end function Get-UacStatus

function Get-UpdateInfo {
  <#
      .SYNOPSIS
      Queries an online XML source for version information to determine if a new version of the script is available.

      .DESCRIPTION
      Queries an online XML source for version information to determine if a new version of the script is available.

      .NOTES
      Version               : 1.7 - See changelog at https://ucunleashed.com/3168 for fixes & changes introduced with each version
      Wish list             : Better error trapping
      Rights Required       : N/A
      Function Dependencies : Write-Log, New-Popup, Stop-Script
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/3168
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : Reading XML files 
                              http://stackoverflow.com/questions/18509358/how-to-read-xml-in-powershell
                              http://stackoverflow.com/questions/20433932/determine-xml-node-exists
                            : TLS 1.2 fixup (via @GreigInSydney)
                              https://github.com/chocolatey/choco/wiki/Installation#installing-with-restricted-tls
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known 

      .EXAMPLE
      Get-UpdateInfo -Article 123

      Description
      -----------
      Runs function to check for updates to article/script 123.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/3168')]
  param (
    # Specifies the blog article number. This is used to check the XML file for version info.
    [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [int] $Article,
    
    # Path to the XML file that contains the update information.
    [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $XmlPath = 'https://ucunleashed.com/downloads/version.xml'
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  [bool] $HasInternetAccess = ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet)
  if ($HasInternetAccess){
    Write-Log -Type Info -Message 'Performing update check'
    # ------------------ TLS 1.2 fixup
    # $SecurityProtocolSettingsOriginal = [Net.ServicePointManager]::SecurityProtocol
    # Write-Log -Type Info -Message "Original security protocol settings: $SecurityProtocolSettingsOriginal" -NoConsole
    try {
      # Set TLS 1.2 (3072). Use integers because the enumeration values for TLS 1.2 won't exist in .NET 4.0, even though they are 
      # addressable if .NET 4.5+ is installed (.NET 4.5 is an in-place upgrade).
      Write-Log -Type Info -Message 'New security protocol settings: Tls12 (3072)' -NoConsole -Indent 1
      [Net.ServicePointManager]::SecurityProtocol = 3072
      # Need to error check here to ensure it was actually changed.
    } catch {
      Write-Log -Type Warn -Message 'Unable to set PowerShell to use TLS 1.2 due to old .NET Framework installed.' -Indent 1
    }
    # ------------------ end TLS 1.2 fixup
    try{
      Write-Log -Type Info -Message "Retrieving update info for article $Article" -NoConsole -Indent 1
      [xml] $xml = (New-Object -TypeName System.Net.WebClient -ErrorAction Stop).DownloadString($XmlPath)
    }
    catch{
      Write-Log -Type Warn -Message "Error occurred while retreiving XML update data from `'$XmlPath`'" -Indent 1
      Write-Log -Type Warn -Message "Failed with `'$($_.Exception.Message)`'" -Indent 1 -NoConsole
    }
    try{
      [object] $ArticleXml = Select-Xml -Xml $xml -XPath "//article[@id='$($article)']"
      [string] $Ga = $ArticleXml.Node.Version.Trim()
      Write-Log -Type Info -Message "GA version according to XML is $Ga" -NoConsole -Indent 1
    
      [string] $Title = $ArticleXml.Node.Title.Trim()
      if (-Not ([string] $DownloadUrl = $ArticleXml.Node.DownloadUrl.Trim())){
        [string] $DownloadUrl = "https://ucunleashed.com/$article#downloads"
      }
      [string] $changelog = "This version includes: `n" + $ArticleXml.Node.Changelog.Trim()

      if ($Ga -gt $ScriptVersion){
        Write-Log -Type Warn -Message "Outdated version. Version $Ga is latest version. Prompting user to upgrade." -NoConsole
        if ((New-Popup -Message "Version $Ga is now available. $changelog `n`nWould you like to download it?" -Title "New version of $Title available!" -Buttons YesNo -Icon Question) -eq 6){
          Write-Log -Type Info -Message "User elected to download version $Ga." -NoConsole -Indent 1
          Write-Log -Type Info -Message "Opening Internet Explorer and going to $DownloadUrl" -NoConsole -Indent 1
          Start-Process -FilePath $DownloadUrl
          Write-Log -Type Warn -Message "Script is exiting. Please start the new version of the script once you've downloaded it." -NoLog
          Stop-Script
        }else{
          Write-Log -Type Warn -Message "User elected NOT to download version $Ga." -Indent 1 -NoConsole
        }
      }elseif ($Ga -eq $ScriptVersion){
        Write-Log -Type Info -Message "Current version. Version $Ga is latest version." -NoConsole
          }elseif (-Not ($Ga)) {
        Write-Log -Type Warn -Message 'No version info available' -NoConsole
      }
    }
    catch{
      Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
    }
  }else{
    Write-Log -Type Warn -Message 'Unable to check online for update info.' -NoConsole
  }
  Write-Log -Type Info -Message 'Completed update check' -NoConsole -Indent 1
} # end function Get-UpdateInfo

function Get-VirtualizationInfo { # https://gallery.technet.microsoft.com/scriptcenter/Determine-if-a-computer-is-cdd20473/view/Discussions#content
  <# 
      .SYNOPSIS 
      Validate if a remote server is virtual or physical 
      .DESCRIPTION 
      Uses wmi (along with an optional credential) to determine if a remote computers, or list of remote computers are virtual. 
      If found to be virtual, a best guess effort is done on which type of virtual platform it is running on. 
      .PARAMETER ComputerName 
      Computer or IP address of machine 
      .PARAMETER Credential 
      Provide an alternate credential 
      .EXAMPLE 
      $Credential = Get-Credential 
      Get-RemoteServerVirtualStatus 'Server1','Server2' -Credential $Credential | select ComputerName,IsVirtual,VirtualType | ft 
     
      Description: 
      ------------------ 
      Using an alternate credential, determine if server1 and server2 are virtual. Return the results along with the type of virtual machine it might be. 
      .EXAMPLE 
      (Get-RemoteServerVirtualStatus server1).IsVirtual 
     
      Description: 
      ------------------ 
      Determine if server1 is virtual and returns either true or false. 

      .LINK 
      http://www.the-little-things.net/ 
      .LINK 
      http://nl.linkedin.com/in/zloeber 
      .NOTES 
     
      Name       : Get-RemoteServerVirtualStatus 
      Version    : 1.1.0 12/09/2014
                - Removed prompt for credential
                - Refactored some of the code a bit.
                1.0.0 07/27/2013 
                - First release 
      Author     : Zachary Loeber 
  #> 
  [cmdletBinding()] 
  param(
    # Computer or IP address of machine to test
    [parameter(Position = 0, ValueFromPipeline)] 
    [string] $ComputerName = $env:COMPUTERNAME
  )
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  # $wmibios = Get-WmiObject Win32_BIOS -ComputerName $ComputerName -ErrorAction Stop | Select-Object version,serialnumber
  $wmibios = Get-CimInstance -ClassName 'Win32_BIOS' -ComputerName $ComputerName -ErrorAction Stop | Select-Object -Property Version,SerialNumber
  # $wmisystem = Get-WmiObject Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction Stop | Select-Object model,manufacturer
  # $wmisystem = Get-CimInstance -ClassName 'Win32_ComputerSystem' -ComputerName $ComputerName -ErrorAction Stop | Select-Object -Property Model,Manufacturer
  $wmisystem = Get-CimInstance -ClassName 'Win32_ComputerSystem' -ComputerName $ComputerName -Property Model,Manufacturer -ErrorAction Stop  
  $ResultProps = @{
    ComputerName = $ComputerName
    BIOSVersion = $wmibios.Version
    SerialNumber = $wmibios.serialnumber
    Manufacturer = $wmisystem.manufacturer
    Model = $wmisystem.model
    IsVirtual = $false
    VirtualType = $null
    Host = 'Unknown host name'
  }
  if ($wmibios.SerialNumber -like '*VMware*') {
      $ResultProps.IsVirtual = $true
      $ResultProps.VirtualType = 'VMWare'
  } else {
    switch -wildcard ($wmibios.Version) {
      'VIRTUAL' {
        $ResultProps.IsVirtual = $true
        $ResultProps.VirtualType = 'Microsoft Hyper-V'
        $ResultProps.Host = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters' -Name HostName).HostName
      }
      'A M I' {
        $ResultProps.IsVirtual = $true
        $ResultProps.VirtualType = 'Virtual PC'
      }
      '*Xen*' {
        $ResultProps.IsVirtual = $true
        $ResultProps.VirtualType = 'Xen'
      }
    }
  }
  if (-Not $ResultProps.IsVirtual) {
    if ($wmisystem.manufacturer -like '*Microsoft*') {
      $ResultProps.IsVirtual = $true
      $ResultProps.VirtualType = 'Microsoft Hyper-V'
      $ResultProps.Host = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters' -Name HostName).HostName
    } elseif ($wmisystem.manufacturer -like '*VMWare*') {
      $ResultProps.IsVirtual = $true
      $ResultProps.VirtualType = 'VMWare'
    } elseif ($wmisystem.model -like '*Virtual*') {
      $ResultProps.IsVirtual = $true
      $ResultProps.VirtualType = 'Unknown Virtual Machine'
    }
  }
  return $ResultProps
} # end function Get-VirtualizationInfo

function Install-CsOnlineAdminTools {
  <#
      .SYNOPSIS
      Installs the required tools for administration of Skype for Business Online, as well as hybrid.

      .DESCRIPTION
      Installs the required tools for administration of Skype for Business Online, as well as hybrid.

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : N/A
      Function Dependencies : Write-Log, New-FileDownload, New-ProgramInstallation, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A 
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known 

      .EXAMPLE
      Install-CsOnlineAdminTools

      Description
      -----------
      Installs 'Microsoft Online Services Sign-in Assistant', 'Windows Azure Active Directory Module for Windows PowerShell', and 'Skype for Business Online, Windows PowerShell Module'

      .INPUTS
      None. You cannot pipe objects to this script.
  #>

  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [switch] $NoPrompt
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  if ($skype4b2019){
    Write-Log -Type Warn -Message 'This option is not available for Skype for Business Server 2019'
    Break
  }

  # Write-Log -Type Info -Message 'Online admin components'
  if (-Not $NoPrompt -and (-Not $IncludeOnlineAdminTools) -and (-Not (New-Popup -Message 'Install Skype for Business Online admin components? This is required if hybrid mode will be used.' -Title 'Install online admin components' -Buttons YesNo -Icon Question) -eq 6)){
    Write-Log -Type Warn -Message 'User chose NOT to install online admin components' -NoConsole -Indent 1
    Break
  }

  Write-Log -Type Info -Message 'User chose to install online admin components' -NoConsole -Indent 1
  if (-not ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet)){
    Write-Log -Type Error -Message 'No Internet access detected. Unable to install online tools'
    Break
  }
  <#
          Write-Log -Type Info -Message 'Microsoft Online Services Sign-in Assistant' -NoConsole -Indent 1            
          if (-Not (Test-Path -Path "$UninstallKey\$GUIDMsOnlineServicesSignInAssistant")){          
          New-FileDownload -SourceFile $URLMsOnlineServicesSignInAssistant
          Write-Log -Type Info -Message 'Installing "Microsoft Online Services Sign-in Assistant"' -NoConsole -Indent 1
          New-ProgramInstallation -InstallFile "$TargetFolder\$($URLMsOnlineServicesSignInAssistant | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForRegistryEntry "$UninstallKey\$GUIDMsOnlineServicesSignInAssistant"
          } else {
          Write-Log -Type Warn -Message '"Microsoft Online Services Sign-in Assistant" components already installed' -Indent 2
          }
          Write-Log -Type Info -Message '"Windows Azure Active Directory Module for Windows PowerShell"' -NoConsole -Indent 1
          if (-Not (Test-Path -Path "$UninstallKey\$GUIDAzureAdModule")){
          New-FileDownload -SourceFile $URLAzureAdModule
          Write-Log -Type Info -Message 'Installing "Windows Azure Active Directory Module for Windows PowerShell"' -NoConsole -Indent 1
          New-ProgramInstallation -InstallFile "$TargetFolder\$($URLAzureAdModule | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForRegistryEntry "$UninstallKey\$GUIDAzureAdModule"
          } else {
          Write-Log -Type Warn -Message '"Windows Azure Active Directory Module for Windows PowerShell" already installed.' -Indent 2
          }
      #>
  Write-Log -Type Info -Message 'Installing NuGet Package Provider' -Indent 1
  Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
  [string] $NuGetVersion = (Get-PackageProvider -Name NuGet).Version
  Write-Log -Type Info -Message "NuGet $NuGetVersion installed" -NoConsole -Indent 2
  $OriginalInstallationPolicy = (Get-PSRepository -Name PsGallery).InstallationPolicy
  Write-Log -Type Info -Message "Original Installation Policy is `'$OriginalInstallationPolicy`'" -NoConsole -Indent 1
      
  if ($OriginalInstallationPolicy -ne 'Trusted') {
    Write-Log -Type Info -Message "Temporarily setting InstallationPolicy for PsGallery to 'Trusted'" -NoConsole -Indent 1
    Set-PSRepository -Name PsGallery -InstallationPolicy Trusted
  }
  
  Write-Log -Type Info -Message 'Installing MSOnline module' -Indent 1
  Install-Module -Name MSOnline
  
  Write-Log -Type Info -Message 'Installing Azure AD module' -Indent 1
  Install-Module -Name AzureAD
  
  if ($OriginalInstallationPolicy -ne 'Trusted') {
    Write-Log -Type Info -Message "Setting InstallationPolicy back to original `'$OriginalInstallationPolicy`'" -NoConsole -Indent 1
    Set-PSRepository -Name PsGallery -InstallationPolicy $OriginalInstallationPolicy
  }

  Write-Log -Type Info -Message 'Checking for "Skype for Business Online, Windows PowerShell Module"' -NoConsole -Indent 1
  if (-Not (Test-Path -Path "$UninstallKey\$GUIDSkypeOnlineModule")){
    New-FileDownload -SourceFile $URLSkypeOnlineModule
    Write-Log -Type Info -Message 'Installing "Skype for Business Online, Windows PowerShell Module"' -NoConsole -Indent 1
    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLSkypeOnlineModule | Split-Path -leaf)" -InstallSwitches '/install /quiet /norestart' -WaitForProcessName $($URLSkypeOnlineModule | Split-Path -leaf).Substring(0,$($URLSkypeOnlineModule | Split-Path -leaf).Length -4) -LongInstall
  } else {
    Write-Log -Type Warn -Message '"Skype for Business Online, Windows PowerShell Module" already installed.' -Indent 2
  }

  try{
    if ($psversiontable.PSVersion -lt 5.1){
      Write-Log -Type Warn -Message "Microsoft Teams PowerShell module requires PowerShell 5.1 or later, which is not installed on this machine. The version installed on this machine is $($psversiontable.psversion)." -NoConsole
      Break
    }
    if (-Not (Get-Module -ListAvailable -Name MicrosoftTeams)){
      Write-Log -Type Info -Message 'Prompting uesr for Microsoft Teams module' -NoConsole
      if ((New-Popup -Message 'Install Microsoft Teams module? This is needed for PowerShell management of Teams' -Title 'Install Teams module' -Buttons YesNo -Icon Question) -eq 6){
        Write-Log -Type Info -Message 'User accepted Microsoft Teams PowerShell module' -NoConsole -Indent 1
        Write-Log -Type Info -Message 'Installing Microsoft Teams PowerShell module' -NoConsole -Indent 1
        Install-Module -Name MicrosoftTeams -SkipPublisherCheck -Force        
        [string] $TeamsVersion = (Get-Module -ListAvailable -Name MicrosoftTeams).Version
        Write-Log -Type Info -Message "Teams module $TeamsVersion installed" -NoConsole -Indent 1
      }else{
        Write-Log -Type Info -Message 'User declined to install Microsoft Teams module' -NoConsole -Indent 1
      }
    }else{
      Write-Log -Type Info -Message 'Microsoft Teams PowerShell module already installed' -NoConsole -Indent 1
    }
  }
  catch [Management.Automation.CommandNotFoundException] {
    Write-Log -Type Error -Message 'Installation of Teams PowerShell module failed!'
    Write-Log -Type Error -Message "The Microsoft Teams module requires PowerShell v5.1 or later to install. Please update your PowerShell version (current version: $PowerShellVersion) and try again."
  }
  catch{
    Write-Log -Type Error -Message 'Installation of Teams PowerShell module failed!'
    Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
  }

  Write-Log -Type Divider -NoConsole
} # end function Install-OnlineAdminTools

function Install-DotNet{
  <#
      .SYNOPSIS
      Installs the latest supported version of the .NET framework.

      .DESCRIPTION
      Installs the latest supported version of the .NET framework. If an existing version is already installed, it will be updated. Supportability of .NET framework matches that of Exchange Server. Exchange Server .

      .NOTES
      Version               : 1.1
      Wish list             : N/A
      Rights Required       : N/A
      Function Dependencies : Write-Log, New-FileDownload, New-ProgramInstallation
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A 
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A 
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known 

      .EXAMPLE
      Install-DotNet

      Description
      -----------
      Will install the latest version of .NET framework.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking .NET versions'
  $LatestSupportedDotNetVersion = $($URLdotnet | Split-Path -leaf).Substring(3,1) + '.' + $($URLdotnet | Split-Path -leaf).Substring(4,1) + '.' + $($URLdotnet | Split-Path -leaf).Substring(5,1)
  Write-Log -Type Info -Message "Installed .NET version is $InstalledDotNetVersion" -Indent 1
  Write-Log -Type Info -Message "Latest supported .Net version is $LatestSupportedDotNetVersion" -Indent 1
  if  ($InstalledDotNetVersion -lt $LatestSupportedDotNetVersion){
    Write-Log -Type Info -Message "Installing .NET version $LatestSupportedDotNetVersion"
    New-FileDownload -SourceFile $URLdotnet
    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLdotnet | Split-Path -leaf)" -InstallSwitches '/q /norestart' -WaitForProcessName $([IO.Path]::GetFileNameWithoutExtension($URLdotnet)) -ReallyLongInstall
    Write-Log -Type Warn -Message 'Updated .NET version info will not be visible until after system is rebooted.'
    $RebootRequired = $true
  }elseif ($InstalledDotNetVersion -gt $LatestSupportedDotNetVersion){
    Write-Log -Type Error -Message "Installed version of .NET, $InstalledDotNetVersion, is newer than the latest supported .NET version. While it's possible the version installed is now supported and this script hasn't been updated, you should verify this."
  }else{
    Write-Log -Type Info -Message ".NET version is $InstalledDotNetVersion and sufficient." -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Install-DotNet

function Install-Hotfix {
  <#
      .SYNOPSIS
      Installs the OS version specific hotfix for Skype for Business Server.

      .DESCRIPTION
      Installs the OS version specific hotfix for Skype for Business Server. Supported operating systems are Windows Server 2012 and Windows Server 2012 R2.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-FileDownload
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known
        
      .EXAMPLE
      Install-Hotfix

      Description
      -----------
      Installs the OS version specific hotfix for Skype for Business Server.

      .INPUTS
      None. You cannot pipe objects to this script.

      #Requires -Version 3.0
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  if ($skype4b -or $skype4b2019 -and (-Not ($IsSrv2016)) -and (-Not ($IsSrv2019))){    
    if ($IsSrv2012){
      Write-Log -Type Info -Message 'Checking for hotfix' -NoConsole
      if (-Not (Test-Path -Path $GUIDhotfix)){
        Write-Log -Type Info -Message 'Hotfix not detected - installing.' -NoConsole -Indent 1
        New-FileDownload -SourceFile $URLHotfix
        if (-Not (Test-Path -Path $TargetFolder\hotfix\*.msu)){          
          Write-Log -Type Info -Message 'Extracting hotfix' -NoConsole -Indent 1
          Add-Type -AssemblyName 'System.IO.Compression.FileSystem'
          [IO.Compression.ZipFile]::ExtractToDirectory("$TargetFolder\$($URLHotfix | Split-Path -leaf)", "$TargetFolder\hotfix")   
          Start-Sleep -Seconds 3
        }
      }
    }elseif ($IsSrv2012R2){
      # TODO: A properly updated 2012R2 server will already have this installed, but I haven't found a decent way to verify it's already installed. So we'll call the installer and let it exit gracefully if it's already installed.
      New-FileDownload -SourceFile $URLHotfix -DestFolder "$TargetFolder\Hotfix"
    }
    if (Get-Item -Path "$TargetFolder\hotfix\*" -ErrorAction SilentlyContinue){
      Get-Item -Path "$TargetFolder\hotfix\*" | ForEach-Object {
        Write-Log -Type Info -Message "Installing hotfix $($_.Name). This will take several minutes." -Indent 1
        WUSA ""$_.FullName /quiet /norestart""
        While (Wait-Process -Name wusa){Invoke-Spinner}
      }
    }else{
      Write-Log -Type Warn -Message 'No hotfix files found to install' -Indent 1
    }
  }
  Write-Log -Type Divider -NoConsole
} # end function Install-Hotfix

function Install-SilverLight {
  <#
      .SYNOPSIS
      Installs Microsoft SilverLight on the local machine.

      .DESCRIPTION
      Installs Microsoft SilverLight on the local machine.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-FileDownload, New-ProgramInstallation
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Install-Silverlight

      Description
      -----------
      Installs Silverlight on the local machine

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Microsoft Silverlight' -NoConsole
  Write-Log -Type Info -Message 'Checking if Silverlight is already installed' -NoConsole -Indent 1
  if (-Not (Test-Path -Path "$UninstallKey\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}")){
    Write-Log -Type Info -Message 'Silverlight is not installed' -NoConsole -Indent 1
    New-FileDownload -SourceFile $URLsilverlight
    Write-Log -Type Info -Message 'Installing Microsoft Silverlight' -Indent 1
    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLsilverlight | Split-Path -leaf)" -InstallSwitches '/q' -WaitForRegistryEntry "$UninstallKey\{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}"
    # remove pinned shortcut on desktop to 'c:\Program Files\Microsoft Silverlight\5.1.10411.0\Silverlight.Configuration.exe'
  } else {
    Write-Log -Type Warn -Message 'Silverlight already installed' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Install-SilverLight

function Install-SqlMgmtStudio {
  <#
      .SYNOPSIS
      Installs SQL Server 2012 Management Studio Express

      .DESCRIPTION
      Installs SQL Server 2012 Management Studio Express

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-FileDownload
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Install-SqlMgmtStudio

      Description
      -----------
      Installs SQL Server 2012 Management Studio Express in the default path

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking for SQL Server Management Studio'
  if (-Not (Test-Path -Path "$UninstallKey\$GUIDsqlmgmtstudioexpress")){
    if ($MenuOption -ne 8 -and (-Not ($IncludeSSMS))){
      Write-Log -Type Info -Message 'Prompting for SQL Server Management Studio Express' -NoConsole
      $intAnswer = (New-Popup -Message 'Do you want to include SQL Server Management Studio Express? It is not REQUIRED, but is recommended for troubleshooting.' -Title 'SQL Server 2012 Management Studio Express' -Buttons YesNo -Icon Question)
    }
    if (($intAnswer -eq 6) -or $IncludeSSMS) {
      Write-Log -Type Info -Message 'User agreed on installation of SQL Server Management Studio Express' -Indent 1 -NoConsole
      New-FileDownload -SourceFile $URLsqlmgmtstudio
      Write-Log -Type Info -Message "Installing SQL Server Management Studio Express to `"$SQLPath`"" -Indent 1
      Write-Log -Type Info -Message 'This will take several minutes' -Indent 1
      Push-Location
      Set-Location -Path $TargetFolder      
      if ($skype4b -or $skype4b2019){
        $ThisExpression = ".\$($URLsqlmgmtstudio | Split-Path -leaf) /Q /IAcceptSqlServerLicenseTerms /HideConsole /Action=Install /Features=SSMS,ADV_SSMS /InstallSqlDataDir=`"$SQLPath`""
      }else{
        $ThisExpression = ".\$($URLsqlmgmtstudio | Split-Path -leaf) /QUIETSIMPLE /IACCEPTSQLSERVERLICENSETERMS /HIDECONSOLE /ACTION=Install /FEATURES=SSMS,ADV_SSMS /INSTALLSQLDATADIR=`"$SQLPath`""
      }
      [DateTime] $SsmsInstallStartTime = Get-Date
      Invoke-Expression -Command $ThisExpression
      Start-Sleep -Seconds 3
      Write-Log -Type Info -Message 'Waiting for installation to finish. This can take several minutes.' -Indent 1
      do {Invoke-Spinner} while (Get-Process -Name $(($URLsqlmgmtstudio | Split-Path -leaf).Replace('.exe','')) -ErrorAction SilentlyContinue)
      Write-Host "`b `b" -NoNewline
      # check for installed .exe
      if ((Test-Path -Path "${env:ProgramFiles(x86)}\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\Ssms.exe") -or (Test-Path -Path "${env:ProgramFiles(x86)}\Microsoft SQL Server\120\Tools\Binn\ManagementStudio\Ssms.exe") -or (Test-Path -Path "${env:ProgramFiles(x86)}\Microsoft SQL Server\140\Tools\Binn\ManagementStudio\Ssms.exe")){
        [DateTime] $SsmsInstallEndTime = Get-Date
        $SsmsInstallElapsedTime = New-TimeSpan -Start $SsmsInstallStartTime -End $SsmsInstallEndTime
        $SsmsInstallTotalElapsedTime = '{0:D2}.{1:D2}:{2:D2}:{3:D2}' -f $SsmsInstallElapsedTime.Days,$SsmsInstallElapsedTime.Hours,$SsmsInstallElapsedTime.Minutes,$SsmsInstallElapsedTime.Seconds
        Write-Log -Type Info -Message "SQL Server Management Studio installed. Total elapsed time: $SsmsInstallTotalElapsedTime" -NoConsole -Indent 1
      } else {
        Write-Log -Type Error -message 'Failed!' -Indent 1
      }
      $RestartRequired = $true
      Pop-Location
    }
  } else {
    Write-Log -Type Warn -Message '"SQL Server Management Studio Express" already installed' -Indent 1
  }

  Write-Log -Type Divider -NoConsole
} # end function Install-SqlMgmtStudio

function Install-TelnetClient {
  <#
      .SYNOPSIS
      Installs the Telnet client windows feature.

      .DESCRIPTION
      Installs the Telnet client windows feature.

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Set-ModuleStatus
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [switch] $IgnorePrompt
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Set-ModuleStatus -Name ServerManager
  if (-Not (Get-WindowsFeature -Name Telnet-Client).Installed){
    if (-Not ($IncludeTelnet)){
      Write-Log -Type Info -Message 'Prompting user about telnet client' -NoConsole      
      if (-Not $IgnorePrompt){
        $IncludeTelnet = (New-Popup -Message 'Do you want to include Telnet client? It is not REQUIRED, but is recommended for troubleshooting.' -Title 'Telnet client' -Buttons YesNo -Icon Question)
      }else{
        $IncludeTelnet = $true
      }
    }
    if ($IncludeTelnet) {
      Write-Log -Type Info -Message 'User accepted telnet client installation' -NoConsole -Indent 1
      $RestartNeeded = (Add-WindowsFeature -Name Telnet-Client -WarningAction SilentlyContinue | Out-Null).RestartNeeded
      if ($RestartNeeded -eq 'Yes'){
        Write-Log -Type Info -Message 'Setting RestartRequired flag' -NoConsole
        $RestartRequired = $true
      }
      Write-Log -Type Info -Message 'Telnet installation completed' -NoConsole -Indent 1
    }
  }else{
    Write-Log -Type Warn -Message 'Telnet-client already installed' -NoConsole -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Install-TelnetClient

function Invoke-NicCheck {
  <#
      .SYNOPSIS
      Determined the number of Network Interface Cards (NICs) on a computer.

      .DESCRIPTION
      Determined the number of Network Interface Cards (NICs) on a computer.

      .NOTES
      Version               : 1.0
      Wish list             : None
      Rights Required       : None
      Function Dependencies : Write-Log, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com 	https://www.ucunleashed.com @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A 
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
    

      Description
      -----------
    

      .INPUTS
      System.String. You cannot pipe objects to this script.

      .OUTPUTS
      System.String
  #>

  [CmdletBinding()]
  param (
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking number of NICs'
  if (($NumberOfNics -gt 1) -and (-Not $DownloadAll) -and (-Not $DownloadOnly)){
    Write-Log -Type Error -Message "$NumberOfNics NICs detected. Displaying prompt" -NoConsole -Indent 1
    if ((New-Popup -Message "$NumberOfNics NICs detected. It is not recommended for this role to have more than 1 NIC. Are you sure you want to continue?" -Title 'Too many NICs detected' -Buttons YesNo -Icon Question) -eq 6){
      Write-Log -Type Info -Message 'User chose to continue' -NoConsole
    } else {
      Write-Log -Type Warn -Message 'User chose NOT to continue' -NoConsole
      Stop-Script
    }
  }else{
    Write-Log -Type Info -Message "Number of NICs: $NumberOfNics" -NoConsole -Indent 1
  }
  Write-Log -Type Divider -NoConsole
}# end function Invoke-NicCheck

function Invoke-Spinner {
  <#
      .SYNOPSIS
      Describe purpose of "Invoke-Spinner" in 1-2 sentences.

      .DESCRIPTION
      Add a more complete description of what the function does.    

      .NOTES
      Version               : 1.1
      Wish list             : 
      Rights Required       : None
      Function Dependencies : None
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .PARAMETER EndOfLine
      Describe parameter -EndOfLine.

      .PARAMETER Finished
      Describe parameter -Finished.

      .PARAMETER SleepTimer
      Describe parameter -SleepTimer.

      .EXAMPLE
      Invoke-Spinner -EndOfLine -Finished -SleepTimer Value
      Describe what this call does

      .INPUTS
      List of input types that are accepted by this function.

      .OUTPUTS
      List of output types produced by this function.
  #>

  [CmdletBinding()]
  param(
    [switch] $EndOfLine, 
    [switch] $Finished,
    [int] $SleepTimer = 100,
    [ValidateSet('Black', 'DarkMagenta', 'DarkRed', 'DarkBlue', 'DarkGreen', 'DarkCyan', 'DarkYellow', 'Red', 'Blue', 'Green', 'Cyan', 'Magenta', 'Yellow', 'DarkGray', 'Gray', 'White')]
    [string] $Color = 'Green'
  )

  $EscChar = "`r"
  # if($EndOfLine){ $EscChar = "`b" }
  # if($Finished){Write-Host "$EscChar"; return;}
  
  for($i=0; $i -lt 20; $i++){
    if(-Not $tickcounter){Set-Variable -Name 'tickcounter' -Scope global -Value 0 -Force -Option AllScope}
    switch($tickcounter){
      0 { Write-Host "$EscChar|" -NoNewline -ForegroundColor $Color }
      1 { Write-Host "$EscChar/" -NoNewline -ForegroundColor $Color }
      2 { Write-Host "$EscChar-" -NoNewline -ForegroundColor $Color }
      3 { Write-Host "$EscChar\" -NoNewline -ForegroundColor $Color }
    }
    Start-Sleep -Milliseconds $SleepTimer
    if($tickcounter -eq 3){ 
      $tickcounter = 0 
    } else{ 
      $tickcounter++ 
    }
  }
} # end function Invoke-Spinner

function Invoke-RestartQuery {
  <#
      .SYNOPSIS
    

      .DESCRIPTION
    

      .PARAMETER NoRunonce
    

      .EXAMPLE
      Invoke-RestartQuery -NoRunonce
    

      .NOTES
      Version               : 1.0
      Wish list             : 
      Rights Required       : None
      Function Dependencies : Write-Log, Test-IsRebootRequired, New-Popup, Set-RunOnce, Stop-Script
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known
    

      .LINK
      URLs to related sites
    

      .INPUTS
    

      .OUTPUTS
    
  #>

  [CmdletBinding(SupportsPaging)]
  param(
    [switch] $NoRunonce
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking if server restart is required.'
  if ((Test-IsRebootRequired) -and (-Not ($DownloadOnly)) -and (-Not ($DownloadAll))){
    Write-Log -Type Warn -Message 'Restart is required' -Indent 1
    $RestartRequired = $true
    Write-Log -Type Info -Message 'Prompting the user to restart.' -NoConsole
    if ((New-Popup -Message 'A server restart is required before other components can be installed. Once restarted, run the script again. Would you like to restart the server now?' -Title 'Server restart is required' -Buttons YesNo -Icon Question) -eq 6){
      Write-Log -Type Info -Message 'User chose to restart.' -NoConsole -Indent 1
      if (-Not($NoRunonce)){
        Set-RunOnce
      }
      Stop-Script -Reboot
    }else{
      Write-Log -Type Info -Message 'User chose NOT to restart.' -NoConsole -Indent 1
      Stop-Script
    }
  }else{
    Write-Log -Type Info -Message 'Restart is NOT required.' -Indent 1        
  }
  Write-Log -Type Divider -NoConsole
} # end function Invoke-RestartQuery

function Invoke-WinSourceCheck {
  [CmdletBinding(SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message "Checking for `"$WindowsSource\sources\sxs`"" -NoConsole
  if (-Not(Test-Path -Path "$WindowsSource\sources\sxs")){ # Give them a chance to specify a valid path
    Do {
      [string] $WindowsSource = Get-Folder -Message 'Please select the location of the Windows source files'
    } while (-Not(Test-Path -Path "$WindowsSource\sources\sxs") -and $WindowsSource -ne 'No folder specified')
    # TODO: Maybe redetect CD-ROM drive and test-path. This code below should work, but still fails when tested in the above WHILE
  }
  if (Test-Path -Path "$WindowsSource\sources\sxs"){
    Write-Log -Type Info -Message 'WindowsSource is valid' -NoConsole -Indent 1
    $ValidWinSource = $true
  }
  Write-Log -Type Divider -NoConsole
} # end function Invoke-WinSourceCheck

function New-FileDownload {
  <#
      .SYNOPSIS
      Downloads a file from a specified URL.

      .DESCRIPTION
      Downloads a file from a specified URL. First, it verifies the file does not exist locally. Then ensures Internet access is available, then downloads the file.

      .NOTES
      Version               : 1.7
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Test-IsProxyEnabled, Set-ModuleStatus, New-Popup, Stop-Script
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    # Complete path and file name (URL) to the file to be downloaded
    [parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $SourceFile,

    # The folder where the downloaded file should be placed. If not defined, it defaults to $TargetFolder.
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $DestFolder,

    # The file name the downloaded file should be changed to. If not defined, file maintains it's original name.
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $DestFile,

    # Whether to download even if a local copy exists. This is useful for files that are updated often and need to be redownloaded.
    [parameter(ValueFromPipelineByPropertyName)]
    [switch] $IgnoreLocalCopy,

    # When specified, will retrieve the size of the file first. This can be helpful when dealing with large files and a warning needs to be displayed.
    [parameter(ValueFromPipelineByPropertyName)]
    [switch] $GetSize
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  # We check for Internet access here so that inconsistencies in access may result in only SOME of the files not getting downloaded.
  [bool] $HasInternetAccess = ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet)
  
  # I should switch this to using a param block and pipelining from property name - just for consistency

  if (-Not ($DestFolder)){ # If we didn't explicitly define a destination folder, use the one the script is using.
    $DestFolder = $TargetFolder
  }  
  if (-Not ($DestFile)){ # If we didn't explicitly define a final filename, take it from the URL.
    Add-Type -AssemblyName System.Web
    [string] $DestFile = [Web.HttpUtility]::UrlDecode(($SourceFile | Split-Path -leaf))
    $DestFile = [Web.HttpUtility]::UrlDecode($DestFile)
  }
    
  # here is where actually have to do stuff
  # this stuff should only trigger if the file doesn't exist, and we need to download it
  if ((-not (Test-Path -Path "$DestFolder\$DestFile")) -or ((Test-Path -Path "$DestFolder\$DestFile") -and ($IgnoreLocalCopy))){ # We need to download the file
    Write-Log -Type Info -Message "File `"$DestFile`" does not exist in `"$DestFolder`"" -NoConsole
    if (Test-Path -Path $DestFolder){ # If the destination folder doesn't exist, create it.
      Write-Log -Type Info -Message "Target folder `"$DestFolder`" exists - no need to create" -NoConsole -Indent 1
    } else {
      Write-Log -Type Info -Message "Folder `"$DestFolder`" does not exist, creating..." -NoConsole
      $null = New-Item -Path $DestFolder -ItemType Directory
      Write-Log -Type Info -Message 'Done!' -NoConsole -Indent 1
    }
    if ($HasInternetAccess){
      Test-IsProxyEnabled
      Set-ModuleStatus -Name BitsTransfer
      Write-Log -Type Info -Message 'Internet access available' -NoConsole -Indent 1
      if ($IgnoreLocalCopy){
        Write-Log -Type Warn -Message "Forcing download of `"$DestFile`" to `"$DestFolder`"" -NoConsole
      }
      
      ########################################################################################################
      # NOTE: Default parameters may have been changed due to proxy settings. See Test-IsProxyEnabled function
      ########################################################################################################
      # determine file size before downloading
      
      if ($GetSize){
        try{
          $clnt = new-object -TypeName Net.WebClient
          $clnt.OpenRead($SourceFile) | Out-Null
          $dlfilesize = [int] $($clnt.ResponseHeaders['Content-Length']/1mb)
          $clnt.Dispose()
        }
        catch{
          Write-Log -Type Warn -Message 'Unable to determine file size.' -NoConsole
          Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
        }
      }
      [string] $URL = ([Uri] $SourceFile).Host
      
      if ($dlfilesize){
        Write-Log -Type Info -Message "Downloading `"$SourceFile`" `($dlfilesize MB`) to `"$DestFolder`"" -NoConsole -Indent 1
        Write-Log -Type Info -Message "Downloading `"$DestFile`" `($dlfilesize MB`) from $URL" -NoLog
        Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile `($dlfilesize MB`)" -ErrorAction SilentlyContinue
      }else{
        Write-Log -Type Info -Message "Downloading `"$SourceFile`" to `"$DestFolder`"" -NoConsole -Indent 1
        Write-Log -Type Info -Message "Downloading `"$DestFile`" from $URL" -NoLog
        Start-BitsTransfer -Source "$SourceFile" -Destination "$DestFolder\$DestFile" -Description "Downloading $DestFile" -ErrorAction SilentlyContinue
      }
      if (Test-Path -Path $DestFolder\$DestFile){
        if ($(((Get-Item -Path $DestFolder\$DestFile).VersionInfo).FileVersion)){
          Write-Log -Type Info -Message "Successfully downloaded $DestFolder\$DestFile `[version $(((Get-Item -Path $DestFolder\$DestFile).VersionInfo).FileVersion)`] ($([INT] ((Get-Item -Path $DestFolder\$DestFile).length / 1mb)) MB) from $URL" -NoConsole -Indent 2
        }else{
          Write-Log -Type Info -Message "Successfully downloaded $DestFolder\$DestFile ($([INT] ((Get-Item -Path $DestFolder\$DestFile).length / 1mb)) MB) from $URL" -NoConsole -Indent 2
        }
      } else {
        Write-Log -Type Error -message "Failed! File `"$DestFile`" not downloaded from $URL!" -Indent 2
        Write-Log -Type Info -Message 'Prompting user to abort/retry/ignore' -NoConsole
        switch (New-Popup -message "Download failure has occurred for `"$DestFile`". What would you like to do?" -Title 'Download error!' -Buttons 'AbortRetryIgnore' -Icon Exclamation){
          3{ # abort
            Write-Log -Type Info -Message 'User has chosen to abort script' -NoConsole -Indent 1
            Stop-Script
            exit
          }
          4{ # retry
            Write-Log -Type Info -Message "User has chosen to retry download of `"$DestFile`"" -NoConsole -Indent 1
            Write-Log -Type Info -Message 'Building retry expression' -NoConsole -Indent 2
            $parms=@{}
            if ($IgnoreLocalCopy){
              $DownloadRetry += ' -IgnoreLocalCopy'
              $parms['IgnoreLocalCopy']=$true
            }
            if ($DestFile){
              $DownloadRetry += " -DestFile `"$Destfile`""
              $parms['DestFile']=$Destfile
            }
            if ($DestFolder){
              $DownloadRetry += " -DestFolder `"$DestFolder`""
              $parms['DestFolder']=$DestFolder
            }
            $parms['SourceFile']=$SourceFile
            $DownloadRetryExp = "New-FileDownload -SourceFile `"$SourceFile`""+ $DownloadRetry
            Write-Log -Type Info -Message "Retry expression is $DownloadRetryExp" -NoConsole -Indent 2
            New-FileDownload @parms
          }
          5{ # ignore
            Write-Log -Type Info -Message 'User has chosen to ignore' -NoConsole -Indent 1
          }
        }
      }
    } else {
      # this message is broken up into chunks so that it shows up ok in the log file
      Write-Log -Type Warn -Message 'Internet access not detected.'
      Write-Log -Type Warn -Message 'This can be because there is no Internet connection,'
      Write-Log -Type Warn -Message 'there is no DNS resolution,'
      Write-Log -Type Warn -Message 'or a proxy is in place. Please resolve and try again.'
      Write-Log -Type Warn -Message "Alternatively, you can manually download the file ($SourceFile)"
      Write-Log -Type Warn -Message "and place it in `'$DestFolder`' and try again."
    }
  }else{ # We do not need to download the file    
    if ($(((Get-Item -Path $DestFolder\$DestFile).VersionInfo).FileVersion)){
      Write-Log -Type Info -Message "File `"$DestFile`" [version $(((Get-Item -Path $DestFolder\$DestFile).VersionInfo).FileVersion)] exists locally - no need to download" -NoConsole
    }else{
      Write-Log -Type Info -Message "File `"$DestFile`" exists locally - no need to download" -NoConsole
    }    
  }
  # Write-Log -Type Divider -NoConsole
} # end function New-FileDownload

function New-Pause {
  <#
      .SYNOPSIS
      Pauses execution until user presses a key.

      .DESCRIPTION
      Pauses execution until user presses a key.

      .NOTES
      Version               : 1.2
      Wish list             : None
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com 	https://www.ucunleashed.com @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/885
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A 
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      New-Pause

      Description
      -----------
      Pauses execution until user presses a key.

      .INPUTS
      System.String. You cannot pipe objects to this script.

      .OUTPUTS
      System.String
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/885')]
  param(
    # Text that is displayed as the prompt when paused.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $PausePrompt = 'Press any key to continue',
    
    # Color of the prompt.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet('Black', 'DarkMagenta', 'DarkRed', 'DarkBlue', 'DarkGreen', 'DarkCyan', 'DarkYellow', 'Red', 'Blue', 'Green', 'Cyan', 'Magenta', 'Yellow', 'DarkGray', 'Gray', 'White')]
    [string] $PauseColor = 'Green'
  )
  BEGIN{
    Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  }
  PROCESS{
    Write-Host $PausePrompt -ForegroundColor $PauseColor
    $null = $host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    Write-Host 'Continuing...'
  }
} # end function New-Pause

function New-PickList {
  <#
      .SYNOPSIS
      Runs a specified command, then displays the results in a list as asks for a choice.

      .DESCRIPTION
      Runs a specified command, then displays the results in a list as asks for a choice. The specified command can be any PowerShell command that returns objects.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [object] $data = (Get-NetAdapter | Sort-Object -Property Name).Name
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  # $data = Invoke-Expression -Command $data
  $i = 0
  foreach($entry in $data){
    $array += (,($i,$entry))
    $i++
  }
  foreach ($arrayentry in $array){
    if (-Not $arrayentry[0]){$arrayentry[0] = 0}
    # We have to use Write-Host because Write-Output would send to the pipeline instead (and we do not want that)
    Write-Host $("`t"+$arrayentry[0]+".`t"+$arrayentry[1])
  }

  $xPickListSelection = Read-Host -Prompt "`n`t`tEnter Option Number"
  return $array[$xPickListSelection][1]
} # end function New-PickList

function New-Popup {
  <#
      .Synopsis
      Display a Popup Message

      .Description
      This command uses the Wscript.Shell PopUp method to display a graphical message
      box. You can customize its appearance of icons and buttons. By default the user
      must click a button to dismiss but you can set a timeout value in seconds to
      automatically dismiss the popup.

      The command will write the return value of the clicked button to the pipeline:
      OK     = 1
      Cancel = 2
      Abort  = 3
      Retry  = 4
      Ignore = 5
      Yes    = 6
      No     = 7

      If no button is clicked, the return value is -1.

      .Example
      PS C:\> New-Popup -message 'The update script has completed' -title 'Finished' -time 5

      This will display a popup message using the default OK button and default
      Information icon. The popup will automatically dismiss after 5 seconds.

      .Notes
      Last Updated: April 8, 2013
      Version     : 1.0

      .Inputs
      None

      .Outputs
      integer

      Null   = -1
      OK     = 1
      Cancel = 2
      Abort  = 3
      Retry  = 4
      Ignore = 5
      Yes    = 6
      No     = 7
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  Param (
    # Message to be displayed in the popup message dialog box.
    [Parameter(Position = 0, Mandatory, HelpMessage = 'Enter a message for the popup')]
    [ValidateNotNullorEmpty()]
    [string] $Message,

    # Title of the popup dialog box.
    [Parameter(Position = 1, Mandatory, HelpMessage = 'Enter a title for the popup')]
    [ValidateNotNullorEmpty()]
    [string] $Title,

    # If defined, automatically dismisses the dialog box after the specified number of seconds. Defaults to 0, which requires a mouse click.
    [Parameter(Position = 2)]
    [ValidateScript({$_ -ge 0})]
    [int] $Time = 0,

    # Type of buttons to display.
    [Parameter(Position = 3)]
    [ValidateNotNullorEmpty()]
    [ValidateSet('OK','OKCancel','AbortRetryIgnore','YesNo','YesNoCancel','RetryCancel')]
    [string] $Buttons = 'OK',

    # Icon set to use in dialog box.
    [Parameter(Position = 4)]
    [ValidateNotNullorEmpty()]
    [ValidateSet('Stop','Question','Exclamation','Information' )]
    [string] $Icon = 'Information'
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  #convert buttons to their integer equivalents
  Switch ($Buttons) {
    'OK'               {$ButtonValue = 0}
    'OKCancel'         {$ButtonValue = 1}
    'AbortRetryIgnore' {$ButtonValue = 2}
    'YesNo'            {$ButtonValue = 4}
    'YesNoCancel'      {$ButtonValue = 3}
    'RetryCancel'      {$ButtonValue = 5}
  }

  #set an integer value for Icon type
  Switch ($Icon) {
    'Stop'        {$iconValue = 16}
    'Question'    {$iconValue = 32}
    'Exclamation' {$iconValue = 48}
    'Information' {$iconValue = 64}
  }

  #create the COM Object
  Try {
    $wshell = New-Object -ComObject Wscript.Shell -ErrorAction Stop
    #Button and icon type values are added together to create an integer value
    $wshell.Popup($Message,$Time,$Title,$ButtonValue+$iconValue)
  }

  Catch {
    #You should never really run into an exception in normal usage
    Write-Log -Type Warn -Message 'Failed to create Wscript.Shell COM object'
    Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
  }
} # end function New-Popup

function New-ProgramInstallation {
  <#
      .SYNOPSIS
      Runs silent installation of programs, including install switches.

      .DESCRIPTION
      Runs silent installation of programs, including install switches. Script can wait for processes and/or registry values to exist before continuing.

      .NOTES
      Version               : 1.6
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Invoke-Spinner
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      New-ProgramInstallation -InstallFile 'c:\installer.msi' -InstallSwitches '/qb'

      Description
      -----------
      Runs installer.msi with the /qb switches

      .EXAMPLE
      New-ProgramInstallation -InstallFile 'c:\installer.msi' -InstallSwitches '/qb' -WaitForProcessName 'MyProgramInstaller'

      Description
      -----------
      Runs installer.msi with the /qb switches, and waits for the process called MyProgramInstaller to stop before continuing

      .EXAMPLE
      New-ProgramInstallation -InstallFile 'c:\installer.msi' -InstallSwitches '/qb' -WaitForRegistryEntry "$UninstallKey\{90150000-1151-0000-1000-0000000FF1CE}"

      Description
      -----------
      Runs installer.msi with the /qb switches, and waits for the registry entry to be written before continuing

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
    # Complete path and file name of the file to be executed.
    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No installation file specified')]
    [ValidateNotNullOrEmpty()]
    [string] $InstallFile,

    # Any special command line switches to be used when executing the file.
    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [string] $InstallSwitches,

    # If defined, the function will wait until the named process ends
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $WaitForProcessName,

    # If defined, the function will wait until the named registry value exists
    [parameter(ValueFromPipelineByPropertyName)]
    [ValidatePattern('^HKLM:|^HKCU:')]
    [string] $WaitForRegistryEntry,

    # If defined, the function will wait until the named path exists
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $WaitForPath,

    # If specified, will display $LongInstallMessage to notify that this installation will take some time
    [parameter(ValueFromPipelineByPropertyName)]
    [switch] $LongInstall,

    # If specified, will display $LongInstallMessage to notify that this installation will take some time
    [parameter(ValueFromPipelineByPropertyName)]
    [switch] $ReallyLongInstall,

    # Text that is displayed if the installation will take a while.
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $LongInstallMessage = '(this may take several minutes)',
    
    # Text that is displayed if the installation will take an extended period of time.
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $ReallyLongInstallMessage = 'This installation can take a considerable amount of time. Please be patient.'
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  $error.clear()
  [DateTime] $ProgramInstallStartTime = Get-Date
  if (Test-Path -Path $InstallFile){
    Write-Log -Type Info -Message 'File exists' -NoConsole -Indent 1
    $DestFile = $($InstallFile | Split-Path -leaf)
    if (-Not $LongInstall){
      Write-Log -Type Info -Message "Installing `'$DestFile`'"
    }else{
      Write-Log -Type Info -Message "Installing `'$DestFile`' $LongInstallMessage"
    }
    if ($ReallyLongInstall){
      Write-Log -Type Warn -Message $ReallyLongInstallMessage
    }
    $Install = $InstallFile+' '+$InstallSwitches
    Write-Log -Type Info -Message "Installation command line: `'$install`'" -NoConsole -Indent 1

    # Invoke-Command might work here if we do not need to evaluate an expression

    Invoke-Expression -Command $Install
    # Start-Process -FilePath $InstallFile -ArgumentList $InstallSwitches -Wait

    if ($WaitForPath){
      Write-Log -Type Info -Message "Waiting for path `"$WaitForPath`" to exist" -NoConsole -Indent 1
      do {Invoke-Spinner} while (-Not (Test-Path -Path "$WaitForPath"))
      Write-Host "`b `b" -NoNewline
      Write-Log -Type Info -Message "Path `"$WaitForPath`" exists" -NoConsole -Indent 1
    }

    if ($WaitForRegistryEntry){
      Write-Log -Type Info -Message "Waiting for registry entry `"$WaitForRegistryEntry`" to be written" -NoConsole -Indent 1
      do {Invoke-Spinner} while (-Not (Test-Path -Path "$WaitForRegistryEntry"))
      Write-Host "`b `b" -NoNewline
      Write-Log -Type Info -Message "Registry entry `"$WaitForRegistryEntry`" has been written" -NoConsole -Indent 1
    }

    if ($WaitForProcessName){
      Start-Sleep -Seconds 1
      Write-Log -Type Info -Message "Waiting for process `"$WaitForProcessName`" to finish running" -NoConsole -Indent 1
      Do {Invoke-Spinner} While (Wait-Process -Name $WaitForProcessName)
      Write-Host "`b" -NoNewline
      Write-Log -Type Info -Message "Process `"$WaitForProcessName`" is no longer running" -NoConsole -Indent 1
    }

    if ($error){
      Write-Log -Type Error -Message 'Failed!' -Indent 1
      Write-Log -Type Error -Message $error
    } else {
      [DateTime] $ProgramInstallEndTime = Get-Date
      $ProgramInstallElapsedTime = New-TimeSpan -Start $ProgramInstallStartTime -End $ProgramInstallEndTime
      $ProgramInstallTotalElapsedTime = '{0:D2}.{1:D2}:{2:D2}:{3:D2}' -f $ProgramInstallElapsedTime.Days,$ProgramInstallElapsedTime.Hours,$ProgramInstallElapsedTime.Minutes,$ProgramInstallElapsedTime.Seconds
      Write-Log -Type Info -Message "Installed. Total elapsed time: $ProgramInstallTotalElapsedTime" -NoConsole -Indent 1
      # Write-Log -Type Info -Message 'Installed' -Indent 1
    }
  } else {
    Write-Log -Type Error -Message "$DestFile does not exist. Unable to proceed." -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function New-ProgramInstallation

function New-PsUpdateHelpScheduledTask {
  <#
      .SYNOPSIS
      Creates a scheduled task that runs daily to force PowerShell to update its help files, then cleans up the temp files created by the first part.

      .DESCRIPTION
      Creates a scheduled task that runs daily to force PowerShell to update its help files, then cleans up the temp files created by the first part.

      .NOTES
      Version               : 1.5
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/1731
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : Untested in Windows Server 2008 R2

      .EXAMPLE
      New-PsUpdateHelpScheduledTask

      Description
      -----------
      Creates new scheduled task to update help and remove associates temp files

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/1731')]
  param(
  ) # end of param block
  BEGIN{
    Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
    [string] $TaskProgram =  "$PSHOME\powershell.exe"
    #[string] $TaskArguments = '-NoProfile -Command "`& {Update-Help -Force; Start-Sleep -Seconds 5; Get-ChildItem $env:temp -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $True -and $_.GetFiles() -match '.cab'} | Remove-Item -Recurse -Force}"'
    [string] $TaskArguments = '-NoProfile -Command "& {Update-Help -Force; Start-Sleep -Seconds 5; Get-ChildItem $env:temp -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $True -and $_.GetFiles() -match ''.cab''} | Remove-Item -Recurse -Force}"'
  }
  PROCESS{
    Write-Log -Type Info -Message "Checking for scheduled task 'Update PowerShell help'" -NoConsole -Indent 1
    if (Get-ScheduledTask -TaskName 'Update PowerShell Help' -ErrorAction SilentlyContinue){
      Write-Log -Type Info -Message "Removing existing scheduled task 'Update PowerShell Help'" -NoConsole -Indent 1
      Unregister-ScheduledTask -TaskName 'Update PowerShell Help' -Confirm:$false
    }
    if (-Not (Get-ScheduledTask -TaskName 'Update PowerShell Help' -ErrorAction SilentlyContinue)){
      Write-Log -Type Info -Message "Creating scheduled task 'Update PowerShell help'" -NoConsole -Indent 1
      $TaskAction = New-ScheduledTaskAction -Execute $TaskProgram -Argument $TaskArguments
      $TaskTrigger = New-ScheduledTaskTrigger -Daily -At 19:00
      Register-ScheduledTask -TaskName 'Update PowerShell Help' -Action $TaskAction -Trigger $TaskTrigger -RunLevel Highest -User 'system' -Description 'Automatically updates PowerShell help.' | Out-Null
    }else{
      Write-Log -Type Warn -Message 'Update task already exists' -Indent 1
    }
    if (Get-ScheduledTask -TaskName 'Cleanup PowerShell Help' -ErrorAction SilentlyContinue){
      Write-Log -Type Info -Message "Removing existing scheduled task 'Cleanup PowerShell Help'" -NoConsole -Indent 1
      Unregister-ScheduledTask -TaskName 'Cleanup PowerShell Help' -Confirm:$false
    }
  }
  END {
    if ($TaskAction){Remove-Variable -Name TaskAction}
    if ($TaskTrigger){Remove-Variable -Name TaskTrigger}
    if ($TaskArguments){Remove-Variable -Name TaskArguments}
    if ($TaskProgram){Remove-Variable -Name TaskProgram}
    [gc]::Collect()
  }
} # end function New-PSUpdateHelpTask

function New-FeShare {
  <#
      .SYNOPSIS
      Creates the file store share for Lync Server/Skype for Business Server.

      .DESCRIPTION
      Creates the file store share for Lync Server/Skype for Business Server by first prompting for a share name, then a folder path, then creating the share, assigning NTFS and share rights.

      .NOTES
      Version               : 1.3
      Wish list             : 
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup, Get-Folder, Disable-Smbv1Protocol
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter		: pat@innervation.com 	https://www.ucunleashed.com @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : http://poshcode.org/6894 for the original example
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)    
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : Writing to event logs requires admin rights

      .EXAMPLE
      New-FeShare

      Description
      -----------
      Creates the file store share for Lync Server/Skype for Business Server by first prompting for a share name, then a folder path, then creating the share, assigning NTFS and share rights.

      .INPUTS
      System.String. You cannot pipe objects to this script.

      .OUTPUTS
      System.String
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking for file store share'
  if ($IncludeStandard){
    Write-Log -Type Info -Message 'This is a standard front end server' -Indent 1
    if ((New-Popup -Message 'Create standard edition file store share?' -Title 'Create share?' -Buttons 'YesNo' -Icon Question) -eq 6){
      Write-Log -Type Info -Message 'User accepted file store share' -Indent 1
      # https://docs.microsoft.com/en-us/rest/api/storageservices/naming-and-referencing-shares--directories--files--and-metadata
      Add-Type -AssemblyName Microsoft.VisualBasic | Out-Null
      Write-Log -Type Info -Message 'Prompting for share name' -Indent 1
      $SmbShareName = [Microsoft.VisualBasic.Interaction]::InputBox('Enter a valid share name', 'Front End File Share', '')
      if (-not($SmbShareName)){
        if ($skype4b2019){  
          $SmbShareName = 'SkypeShare'
        }
        if ($skype4b){
          $SmbShareName = 'SkypeShare'
        } 
        if ($lync2013){
          $SmbShareName = 'LyncShare'
        }
      }      
      $SmbShareName = $SmbShareName.Trim()
      $SmbShareName = $SmbShareName.ToLower()
      $SmbShareName = $SmbShareName.Replace('\', '')
      $SmbShareName = $SmbShareName.Replace('/', '')
      $SmbShareName = $SmbShareName.Replace('[', '')
      $SmbShareName = $SmbShareName.Replace(']', '')
      $SmbShareName = $SmbShareName.Replace(':', '')
      $SmbShareName = $SmbShareName.Replace('&', '')
      $SmbShareName = $SmbShareName.Replace('#', '')
      $SmbShareName = $SmbShareName.Replace('<', '')
      $SmbShareName = $SmbShareName.Replace('>', '')
      $SmbShareName = $SmbShareName.Replace('+', '')
      $SmbShareName = $SmbShareName.Replace('=', '')
      $SmbShareName = $SmbShareName.Replace(';', '')
      $SmbShareName = $SmbShareName.Replace('*', '')
      $SmbShareName = $SmbShareName.Replace('?', '')
      $SmbShareName = $SmbShareName.Replace(' ', '')
      $SmbShareName = $SmbShareName.Replace(',', '')
      if ($SmbShareName.Length -gt 80){
        $SmbShareName = $SmbShareName.substring(0,80)
      }
      
      Write-Log -Type Info -Message "SMB share name entered is `'$SmbShareName`'"
      if(-Not(Get-SmbShare -Name $SmbShareName -ErrorAction SilentlyContinue)){
        Write-Log -Type Info -Message "File store share `'$SmbShareName`' does not exist" -Indent 1
        Write-Log -Type Info -Message 'Prompting for file store share path' -Indent 1
      
        if (-Not($SmbSharePath)){
          Write-Log -Type Info -Message 'Prompting user for folder' -NoConsole -Indent 1
          $SmbSharePath = Get-Folder -Message 'Select the folder to be used for the file store share'
        }
        # Test if the specified path is a root drive, and if so, build a valid path.
        if (([IO.path]::GetPathRoot($SmbSharePath)) -eq $SmbSharePath){
          Write-Log -Type Info -Message "Root folder `'$SmbSharePath`' specified. This is not supported. Building correct folder path." -NoConsole -Indent 1
          $SmbSharePath += $SmbShareName          
        }
        Write-Log -Type Info -Message "Share path specified as `'$SmbSharePath`'" -NoConsole -Indent 1
        if (-Not (Test-Path -Path $SmbSharePath)) {
              Write-Log -Type Info -Message "Folder `'$SmbSharePath`' does not exist. Creating." -NoConsole -Indent 1
              $null = New-Item -Path $SmbSharePath -ItemType Directory
            }
        if (Test-Path -Path $SmbSharePath) {
          # We assign temporary NTFS rights here, ensuring that the user running this script will be able to publish the topology without running into rights issues on the share path. Publishing the topology will assign the rights required for Lync/Skype for Business.
          Write-Log -Type Info -Message "Assigning temporary NTFS rights to `'$SmbSharePath`'. Publishing the topology will assign relevant NTFS rights needed for Lync/Skype." -NoConsole -Indent 1

          $acl = Get-Acl -Path $SmbSharePath
              
          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for 'Domain Admins'" -Indent 2
          $acl.SetAccessRuleProtection($True, $False)

          # Set the permissions that you want to apply to the folder
          $permissions = 'Domain Admins', 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'
              
          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions
          $acl.AddAccessRule($rule)

          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for `'$env:UserDomain\$env:UserName`'" -Indent 2
          # Set the permissions that you want to apply to the folder
          $permissions = "$env:UserDomain\$env:UserName", 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'

          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions
          $acl.AddAccessRule($rule)

          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for 'Administrators'" -Indent 2
          # Set the permissions that you want to apply to the folder
          $permissions = 'Administrators', 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'

          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions

          # not sure why we had the original method as remove
          # $acl.RemoveAccessRule($rule)
          $acl.AddAccessRule($rule)

          Set-Acl -Path $SmbSharePath -AclObject $acl | Out-Null

          if ($skype4b2019){
            $SmbShareDescription = 'Skype for Business Server 2019 share'
          } 
          if ($skype4b){
            $SmbShareDescription = 'Skype for Business Server 2015 share'
          } 
          if ($lync2013){
            $SmbShareDescription = 'Lync Server 2013 share'
          }

          Write-Log -Type Info -Message "Creating `"$SmbShareName`" SMB share at `"$SmbSharePath`"" -NoConsole -Indent 1
          try {
            New-SmbShare -Description "$SmbShareDescription" -FullAccess 'everyone' -Name "$SmbShareName" -Path "$SmbSharePath" -ErrorAction Stop | Out-Null
            Write-Log -Type Warn -Message "Share `'$env:ComputerName\$SmbShareName`' created. This is what needs to be manually added to Topology Builder" -Indent 1
          }
          catch [Management.Automation.ValidationMetadataException] {
            # Parameter values aren't valid (could be empty)
            Write-Log -Type Error -Message 'Failed with validation exception'
          }
          catch {
            Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message.trimend())`'"
          }              
        } else {
          Write-Log -Type Warn -Message "`"$SmbSharePath`" does not exist"
        }
        Write-Log -Type Info -Message 'Prompting user to disable SMBv1' -NoConsole -Indent 1
        if ((New-Popup -Message 'Disable SMB v1 as a security measure? It is not required, but is recommended.' -Title 'Disable SMB v1' -Buttons YesNo -Icon Question) -eq 6){
          Write-Log -Type Info -Message 'User accepted disabling of SMBv1' -Indent 1 -NoConsole
          Disable-Smbv1Protocol
        }else{
          Write-Log -Type Info -Message 'User declined disabling of SMBv1' -Indent 1 -NoConsole
        }
      }else{
        Write-Log -Type Warn -Message "Share `'$SmbShareName`' already exists" -Indent 1
      }
    }else{
      Write-Log -Type Warn -Message 'User opted NOT to create file share' -Indent 1
    }
  }else{
    Write-Log -Type Warn -Message 'This is not a Standard front end' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function New-FeShare

function New-FeShare.old {
  <#
      .SYNOPSIS
      Creates the file store share for Lync Server/Skype for Business Server.

      .DESCRIPTION
      Creates the file store share for Lync Server/Skype for Business Server by first prompting for a folder, then creating the share, assigning NTFS and share rights.

      .NOTES
      Version               : 1.1
      Wish list             : 
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup, Get-Folder
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter		: pat@innervation.com 	https://www.ucunleashed.com @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : http://poshcode.org/6894
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)    
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : Writing to event logs requires admin rights

      .EXAMPLE
      New-FeShare

      Description
      -----------
      Creates the file store share for Lync Server/Skype for Business Server by first prompting for a folder, then creating the share, assigning NTFS and share rights.

      .INPUTS
      System.String. You cannot pipe objects to this script.

      .OUTPUTS
      System.String
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking for file store share'
  if ($IncludeStandard){
    Write-Log -Type Info -Message 'This is a standard front end server' -Indent 1
    
    if((-Not(Get-SmbShare -Name 'SkypeShare' -ErrorAction SilentlyContinue)) -and (-Not(Get-SmbShare -Name 'LyncShare' -ErrorAction SilentlyContinue))){
      Write-Log -Type Info -Message 'File store share does not exist' -Indent 1
      Write-Log -Type Info -Message 'Prompting for file store share' -Indent 1
      if ((New-Popup -Message 'Create file store share?' -Title 'Create share?' -Buttons 'YesNo' -Icon Question) -eq 6){
        Write-Log -Type Info -Message 'User accepted file store share' -Indent 1
        if (-Not($SmbSharePath)){
          Write-Log -Type Info -Message 'Prompting user for folder' -NoConsole -Indent 1
          $SmbSharePath = Get-Folder -Message 'Select the folder to be used for the file store share'
        }
        # Test if the specified path is a root drive, and if so, build a valid path.
        if (([IO.path]::GetPathRoot($SmbSharePath)) -eq $SmbSharePath){
          Write-Log -Type Info -Message "Root folder `'$SmbSharePath`' specified. This is not supported. Building correct folder path." -NoConsole -Indent 1
          if ($skype4b -or $skype4b2019){
            $SmbSharePath += 'SkypeShare'
          }elseif ($lync2013){
            $SmbSharePath += 'LyncShare'
          }
        }
        Write-Log -Type Info -Message "Share path specified as `'$SmbSharePath`'" -NoConsole -Indent 1
        if (-Not (Test-Path -Path $SmbSharePath)) {
              Write-Log -Type Info -Message 'Folder does not exist. Creating.' -NoConsole -Indent 1
              $null = New-Item -Path $SmbSharePath -ItemType Directory
            }
        if (Test-Path -Path $SmbSharePath) {
          # We assign temporary NTFS rights here, ensuring that the user running this script will be able to publish the topology without running into rights issues on the share path. Publishing the topology will assign the rights required for Lync/Skype for Business.
          Write-Log -Type Info -Message "Assigning temporary NTFS rights to `'$SmbSharePath`'. Publishing the topology will assign relevant NTFS rights needed for Lync/Skype." -NoConsole -Indent 1

          $acl = Get-Acl -Path $SmbSharePath
              
          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for 'Domain Admins'" -Indent 2
          $acl.SetAccessRuleProtection($True, $False)

          # Set the permissions that you want to apply to the folder
          $permissions = 'Domain Admins', 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'
              
          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions
          $acl.AddAccessRule($rule)

          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for `'$env:UserDomain\$env:UserName`'" -Indent 2
          # Set the permissions that you want to apply to the folder
          $permissions = "$env:UserDomain\$env:UserName", 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'

          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions
          $acl.AddAccessRule($rule)

          Write-Log -Type Info -Message "Setting 'FullControl' NTFS permissions for 'Administrators'" -Indent 2
          # Set the permissions that you want to apply to the folder
          $permissions = 'Administrators', 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'

          # Create a new FileSystemAccessRule object
          $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $Permissions

          # not sure why we had the original method as remove
          # $acl.RemoveAccessRule($rule)
          $acl.AddAccessRule($rule)

          Set-Acl -Path $SmbSharePath -AclObject $acl | Out-Null

          if ($skype4b2019){
            if (-not($SmbShareName)){
              $SmbShareName = 'SkypeShare'
            }
            $SmbShareDescription = 'Skype for Business Server 2019 share'
          } 
          if ($skype4b){
            if (-not($SmbShareName)){
              $SmbShareName = 'SkypeShare'
            }
            $SmbShareDescription = 'Skype for Business Server 2015 share'
          } 
          if ($lync2013){
            if (-not($SmbShareName)){
              $SmbShareName = 'LyncShare'
            }
            $SmbShareDescription = 'Lync Server 2013 share'
          }

          Write-Log -Type Info -Message "Creating `"$SmbShareName`" SMB share at `"$SmbSharePath`"" -NoConsole -Indent 1
          try {
            New-SmbShare -Description "$SmbShareDescription" -FullAccess 'everyone' -Name "$SmbShareName" -Path "$SmbSharePath" -ErrorAction Stop | Out-Null
            Write-Log -Type Warn -Message "Share `'$env:ComputerName\$SmbShareName`' created. This is what needs to be manually added to Topology Builder" -Indent 1
          }
          catch [Management.Automation.ValidationMetadataException] {
            # Parameter values aren't valid (could be empty)
            Write-Log -Type Error -Message 'Failed with validation exception'
          }
          catch {
            Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message.trimend())`'"
          }              
        } else {
          Write-Log -Type Warn -Message "`"$SmbSharePath`" does not exist"
        }
      }else{
        Write-Log -Type Info -Message 'User did NOT accept file store share prompt' -Indent 1
      }
    }else{
      Write-Log -Type Warn -Message 'Share already exists' -Indent 1
    }
  }else{
    Write-Log -Type Warn -Message 'This is not a Standard front end' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function New-FeShare

function New-Shortcut {
  <#
      .SYNOPSIS
      Creates Windows shortcut.

      .DESCRIPTION
      Creates Windows shortcut.

      .NOTES
      Version               : 1.2
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No shortcut name specified')]
    [ValidateNotNullOrEmpty()]
    [string] $Name,

    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No shortcut file specified')]
    [ValidateNotNullOrEmpty()]
    [string] $File,

    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No shortcut working directory specified')]
    [ValidateNotNullOrEmpty()]
    [string] $WorkingDir,

    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No shortcut description specified')]
    [ValidateNotNullOrEmpty()]
    [string] $Description,

    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [string] $Arguments
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  $error.clear()
  # AllUsers start menu = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
  if (-Not (Test-Path -Path $Name)){
    Write-Log -Type Info -Message "Creating shortcut for $Name" -Indent 1
    if (Get-Item -Path $File){
      $wshshell = New-Object -ComObject WScript.Shell
      if (($Name.Substring($Name.Length - 4, 4) -ne '.lnk') -and ($Name.Substring($Name.Length - 4, 4) -ne '.url')){
        $Name += '.lnk'
      }
      $lnk = $wshshell.CreateShortcut($Name)
      $lnk.TargetPath = $File
      #maps to Start in: on GUI
      $lnk.WorkingDirectory = $WorkingDir
      #corresponds to the Comment field on the shortcut tab.
      $lnk.Description = $Description
      if ($Arguments){
        $lnk.Arguments = $Arguments
      }
      $lnk.Save()
      if ($error){
        Write-Log -Type Error -message 'failed!' -Indent 1
      } else {
        Write-Log -Type Info -Message "Shortcut for $Name created!" -Indent 1
      }
    }
  }else{
    Write-Log -Type Warn -Message "$Name already exists"
  }
} # end function New-Shortcut

function New-SqlInstance {
  <#
      .SYNOPSIS
      Installs a SQL Express named instance.

      .DESCRIPTION
      Installs a SQL Express named instance.

      .NOTES
      Version               : 1.2
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-FileDownload, Invoke-Spinner, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    # Name of the SQL instance to install.
    [ValidateSet('RTCLocal', 'LyncLocal', 'RTC')]
    [ValidateNotNullOrEmpty()]
    [string] $Instance
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  # adapted from http://blogs.technet.com/b/lyncativity/archive/2012/12/06/preinstalling-sql-express-2012-sp1-for-lync-server-2013.aspx

  Write-Log -Type Info -Message "Checking for SQL Instance `"$Instance`"" -NoConsole
  if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -Name "$Instance" -ErrorAction SilentlyContinue)){
    Write-Log -Type Info -Message "SQL instance `"$Instance`" does NOT exist" -NoConsole -Indent 1
    Write-Log -Type Info -Message "Installing `"$Instance`" SQL instance to `"$SQLPath`"" -Indent 1
    Write-Log -Type Info -Message 'This will take several minutes' -Indent 1
    New-FileDownload -SourceFile $URLsqlexpress
    if (Test-Path -Path "$TargetFolder\$(Split-Path -Path $URLsqlexpress -Leaf)"){
      [DateTime] $SqlInstallStartTime = Get-Date
      Push-Location
      Set-Location -Path $TargetFolder
      Write-Log -Type Info -Message "Starting installation of SQL instance `"$Instance`"" -Indent 1
      if ($skype4b -or $skype4b2019){
        .\SqlExpr_x64_ENU.exe /Q /IAcceptSqlServerLicenseTerms /UpdateEnabled=0 /HideConsole /Action=Install /Features=SQLEngine,Tools /InstallSqlDataDir="$SQLPath" /InstanceDir="$SQLPath" /InstanceName="$Instance" /TcpEnabled=1 /SqlSvcAccount="NT Authority\NetworkService" /SqlSysAdminAccounts="Builtin\Administrators" /BrowserSvcStartupType="Automatic" /AgtSvcAccount="NT Authority\NetworkService" /SqlSvcStartupType="Automatic"
      }else{
        .\SqlExpr_x64_ENU.exe /QUIETSIMPLE /IACCEPTSQLSERVERLICENSETERMS /HIDECONSOLE /ACTION=Install /FEATURES=SQLEngine,Tools /INSTALLSQLDATADIR="$SQLPath" /INSTANCEDIR="$SQLPath" /INSTANCENAME="$Instance" /TCPENABLED=1 /SQLSVCACCOUNT="NT AUTHORITY\NetworkService" /SQLSYSADMINACCOUNTS="Builtin\Administrators" /BROWSERSVCSTARTUPTYPE="Automatic" /AGTSVCACCOUNT="NT AUTHORITY\NetworkService" /SQLSVCSTARTUPTYPE="Automatic"
      }
      Start-Sleep -Seconds 3 # This is just to ensure the process has started before we wait for it to finish. Mostly a lab safeguard.
      do {Invoke-Spinner} while (Get-Process -Name SQLEXPR_x64_ENU -ErrorAction SilentlyContinue)
      Write-Host "`b `b" -NoNewline
      if (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -Name "$Instance" -ErrorAction SilentlyContinue){
        [DateTime] $SqlInstallEndTime = Get-Date
        $SqlInstallElapsedTime = New-TimeSpan -Start $SqlInstallStartTime -End $SqlInstallEndTime
        $SqlInstallTotalElapsedTime = '{0:D2}.{1:D2}:{2:D2}:{3:D2}' -f $SqlInstallElapsedTime.Days,$SqlInstallElapsedTime.Hours,$SqlInstallElapsedTime.Minutes,$SqlInstallElapsedTime.Seconds
        Write-Log -Type Info -Message "SQL instance `"$Instance`" installed. Total elapsed time: $SqlInstallTotalElapsedTime" -NoConsole -Indent 1
      } else {
        Write-Log -Type Error -message 'Failed!' -Indent 1
      }
      Write-Log -Type Divider -NoConsole
      $RestartRequired = $true
      Pop-Location
      if ($instance -eq 'rtclocal' -and $MenuOption -eq 3 -and (Get-Service -Name mpssvc).Status -eq 'Running' -and (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -Name "$Instance" -ErrorAction SilentlyContinue)){
        Write-Log -Type Info -Message 'Checking for Get-CsConnections firewall rules'
        if (-Not $IncludeFW){
          Write-Log -Type Info -Message 'Prompting for firewall exceptions for Get-CsConnections.ps1' -NoConsole
          $FWRules = New-Popup -message 'Create firewall exceptions for Get-CsConnections.ps1 script?' -Title 'Firewall Exceptions' -Buttons 'YesNo' -Icon Question
        }
        if ($FWRules -eq 6 -or $IncludeFW) {
          Write-Log -Type Info -Message 'User accepted creating firewall exceptions for Get-CsConnections.ps1' -NoConsole -Indent 1
          Write-Log -Type Info -Message 'Creating firewall exceptions for Get-CsConnections.ps1'
          if (-Not (Get-NetFirewallRule -Name 'SQL Browser (udp-in)' -ErrorAction SilentlyContinue)){
            Write-Log -Type Info -Message 'Creating firewall rule for port UDP\1434 for SQL Browser' -Indent 1
            New-NetFirewallRule -DisplayName 'SQL Browser (udp-in)' -Action Allow -Description 'Created for Get-CsConnections.ps1. For more information, see https://ucunleashed.com/269' -Direction Inbound -LocalPort 1434 -Name 'SQL Browser (udp-in)' -Profile Domain -Protocol UDP | Out-Null
          } else {
            Write-Log -Type Warn -Message 'SQL Browser (udp-in) rule already exists'
          }

          if (-Not (Get-NetFirewallRule -Name 'SQL RTCLOCAL Dynamic Port (tcp-in)' -ErrorAction SilentlyContinue)){
            [int]$DynamicPort = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\RTCLOCAL\MSSQLServer\SuperSocketNetLib\Tcp' -Name TcpPort).TcpPort
            if ($DynamicPort){
              Write-Log -Type Info -Message "Creating firewall rule for dynamic port TCP\$DynamicPort" -Indent 1
              New-NetFirewallRule -DisplayName 'SQL RTCLOCAL Dynamic Port (tcp-in)' -Action Allow -Description 'Created for Get-CsConnections.ps1. For more information, see https://ucunleashed.com/269' -Direction Inbound -LocalPort $DynamicPort -Name 'SQL RTCLOCAL Dynamic Port (tcp-in)' -Profile Domain -Protocol TCP | Out-Null
            }else{
              Write-Log -Type Error -Message 'Unable to determine dynamic port'
            }
          } else {
            Write-Log -Type Warn -Message 'SQL RTCLOCAL Dynamic Port (tcp-in) rule already exists'
          }
        } # user chose not to create FW exceptions.
      } elseif ($instance -eq 'rtclocal' -and $MenuOption -eq 3) { # FW may be disabled
        Write-Log -Type Warn -Message 'Firewall exception not added. Firewall may be disabled, or rtclocal SQL instance may not be installed.' -Indent 1
      }else{
        Write-Log -Type Info -Message "Firewall exceptions not needed for `"$instance`" SQL instance." -NoConsole -Indent 1
      }
      Write-Log -Type Divider -NoConsole
    }
  } else {
    Write-Log -Type Warn -Message "SQL instance `"$Instance`" already installed" -Indent 1
    Write-Log -Type Divider -NoConsole
  }
} # end function New-SqlInstance

function New-Tile {
  <#
      .SYNOPSIS


      .DESCRIPTION


      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $ShortcutTitle,

    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $ShortcutPath,

    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $ShortcutTargetPath,

    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [int] $ShortcutIcon,

    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $ShortcutIconLibrary,

    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $ShortcutArguments
  ) # end of param block
  $Shell = New-Object -ComObject Shell.Application
  $Desktop = $Shell.NameSpace(0X0)
  $WshShell = New-Object -comObject WScript.Shell

  Write-Log -Type Info -Message "Creating `"$ShortcutTitle`" tile on Start menu"
  $Shortcut = $WshShell.CreateShortcut($ShortCutPath)
  $Shortcut.TargetPath = $ShortcutTargetPath
  if ($ShortcutArguments){
    $Shortcut.Arguments = $ShortcutArguments
  }
  $Shortcut.Save()

  Write-Log -Type Info -Message "Changing the default icon of `"$ShortcutTitle`" shortcut" -NoConsole -Indent 1
  $Lnk = $Desktop.ParseName($ShortCutPath)
  $LnkPath = $Lnk.GetLink
  if (-Not $ShortcutIconLibrary){
    $ShortcutIconLibrary = "$env:SystemRoot\System32\SHELL32.dll"
  }
  $LnkPath.SetIconLocation($ShortcutIconLibrary,$ShortcutIcon)
  $LnkPath.Save()

  Write-Log -Type Info -Message "Pinning `"$ShortcutTitle`" shortcut to Windows Start screen" -NoConsole -Indent 1
  $Verbs = $Lnk.Verbs()
  Foreach ($Verb in $Verbs)  {
    If ($Verb.Name.Replace("`&",'') -match 'Pin to Start') {
      $Verb.DoIt()
    }
  }

  If(Test-Path -Path $ShortCutPath)  {
    Write-Log -Type Info -Message "Created `"$ShortcutTitle`" tile successfully" -NoConsole -Indent 1
  }  Else {
    Write-Log -Type Error -message "Failed to create `"$ShortcutTitle`" tile" -NoConsole -Indent 1
  }
} # end function New-Tile

function Remove-NicGateway {
  <#
      .SYNOPSIS
      Removes the configured gateway from a specified network adapter.

      .DESCRIPTION
      Removes the configured gateway from a specified network adapter.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE


      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $NicName
  ) # end of param block
  # $Adapter = Get-WmiObject -Class Win32_NetworkAdapter -Filter "NetConnectionID='$NicName'"
  $Adapter = Get-CimInstance -ClassName 'Win32_NetworkAdapter' -Filter "NetConnectionID='$NicName'"
  # $Nic = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "Index=$($Adapter.Index)"
  $Nic = Get-WmiObject -Class 'Win32_NetworkAdapterConfiguration' -Filter "Index=$($Adapter.Index)"
  $NicIP = $Nic.IpAddress[0]
  $NicMask = $Nic.IpSubnet[0]
  Write-Log -Type Info -Message "Current IP address config: $NicIP $NicMask" -NoConsole -Indent 1
  Write-Log -Type Warn -Message 'Connectivity to this computer will temporarily stop' -Indent 1
  # we have to use the variable method here to suppress output. Piping it to Out-Null caused it to fail.
  Write-Log -Type Info -Message "Setting $NicName to DHCP temporarily to remove the existing config" -NoConsole -Indent 1
  # $dhcp = $Nic.EnableDhcp()
  $null = $Nic.EnableDhcp()
  Write-Log -Type Info -Message "Setting $NicName interface to static config of $NicIP $NicMask" -NoConsole -Indent 1
  # we have to use the variable method here to suppress output. Piping it to Out-Null caused it to fail.
  # $static = $Nic.EnableStatic($NicIp,$NicMask)
  $null = $Nic.EnableStatic($NicIp,$NicMask)

  # change will not be visible until reboot
  $RestartRequired = $true
} # end function Remove-NicGateway

function Remove-DynamicDnsRegistration {
  <#
      .SYNOPSIS
      Disabled dynamic DNS registration on a specified network adapter.

      .DESCRIPTION
      Disabled dynamic DNS registration on a specified network adapter.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE


      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $AdapterName
  ) # end of param block

  # switching to Get-CimInstance breaks this. Get-CimInstance throws a 'does not contain a method named 'Getrelated'' exception
  $ExternalAdapter = Get-WMIObject -Class Win32_NetworkAdapter -filter "NetConnectionID = '$AdapterName'"
  # $ExternalAdapter = Get-CimInstance -ClassName 'Win32_NetworkAdapter' -filter "NetConnectionID = '$AdapterName'"
  $config = $ExternalAdapter.Getrelated('Win32_NetworkAdapterConfiguration')
  # display current settings for DNS registration
  # $config | Select-Object DomainDNSRegistrationEnabled, FullDNSRegistrationEnabled
  # disable DNS registration
  $null = $config | ForEach-Object {$_.SetDynamicDNSRegistration($false,$false)}
} # end function Remove-DynamicDnsRegistration

function Set-AutoUpdateConfig {
  <#
      .SYNOPSIS
      Disables automatic Windows updates on the local machine.

      .DESCRIPTION
      Disables automatic Windows updates on the local machine.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [switch] $IgnorePrompt
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking if Automatic Updates are disabled on this server'
  if ((Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -ErrorAction SilentlyContinue).NoAutoUpdate -ne 1){
    Write-Log -Type Info -Message 'Automatic Updates are NOT disabled on this server' -NoConsole -Indent 1
    Write-Log -Type Info -Message 'Prompting user to disable Automatic Updates' -NoConsole -Indent 1
    if (($IgnorePrompt -or $DisableAutoUpdates) -or ((New-Popup -Message 'Updating Lync/Skype for Business servers via Automatic Updates is not supported due to complexities required during patching. Would you like to disable Automatic Updates?' -Title 'Disable Automatic Update' -Buttons YesNo -Icon Question) -eq 6)){
      Write-Log -Type Info -Message 'User chose to disable Automatic Updates' -NoConsole -Indent 1
      $null = New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows' -Name WindowsUpdate -ErrorAction SilentlyContinue
      if (-Not (Test-Path -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU')){
        $null = New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name AU -ErrorAction SilentlyContinue
      }
      if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -ErrorAction SilentlyContinue)){
        $null = New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -Value 1
      }
      if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -ErrorAction SilentlyContinue).NoAutoUpdate -eq 1){
        Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -Value 1
      }
      if ((Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate).NoAutoUpdate -eq 1){
        Write-Log -Type Info -Message 'Automatic Updates disabled' -NoConsole -Indent 1
      } else {
        Write-Log -Type Error -Message 'Failed setting Automatic Updates to disabled' -Indent 1
      }
    } else {
      Write-Log -Type Info -Message 'User chose NOT to disable Automatic Updates' -NoConsole -Indent 1
    }
  } else {
    Write-Log -Type Warn -Message 'Automatic Updates are already disabled on this server' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Set-AutoUpdateConfig

function Set-ElapsedTime {
  <#
      .SYNOPSIS
      Determines how long the script has been running, and writes that information to the log file.

      .DESCRIPTION
      Determines how long the script has been running, and writes that information to the log file.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  $EndTime = Get-Date
  $ElapsedTime = New-TimeSpan -Start $StartTime -End $EndTime
  $TotalElapsedTime = '{0:D2}.{1:D2}:{2:D2}:{3:D2}' -f $ElapsedTime.Days,$ElapsedTime.Hours,$ElapsedTime.Minutes,$ElapsedTime.Seconds
  Write-Log -Type Info -Message "Total elapsed time: $TotalElapsedTime" -NoConsole
} # end function Set-ElapsedTime

function Set-HighPower {
  <#
      .SYNOPSIS
      Sets the Power Plan on the local machine to High Performance.

      .DESCRIPTION
      Sets the Power Plan on the local machine to High Performance. User is prompted for confirmation on the desired change.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup, Set-PowerPlan
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Info -Message 'Checking power plan configuration' -NoConsole
  if ($PowerLevel -ne 'High Performance'){
    Write-Log -Type Warn -Message 'Power plan is not set to High Peformance' -NoConsole -Indent 1
    if (($IncludeHighPower) -or ((New-Popup -message "Set power plan to `"High Performance`"?" -Title 'Power Plan' -Buttons 'YesNo' -Icon Question) -eq 6)){
      Set-PowerPlan -PreferredPlan 'High Performance'
    }
  } else {
    Write-Log -Type Warn -Message "Power plan already set to `"High Performance`"" -Indent 1
  }
  Write-Log -Type Divider -NoConsole
} # end function Set-HighPower

function Set-ModuleStatus {
  <#
      .SYNOPSIS
      Imports a specified PowerShell module, with error checking.

      .DESCRIPTION
      Imports a specified PowerShell module, with error checking.

      .NOTES
      Version               : 1.6
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : None
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/938
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/938')]
  param  (
    [parameter(ValueFromPipeline, ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'No module name specified!')]
    [ValidateNotNullOrEmpty()]
    [string] $Name
  ) # end of param block
  PROCESS{
    # Executes once for each pipeline object
    # the $_ variable represents the current input object
    if (-Not (Get-Module -name "$name")) {
      if (Get-Module -ListAvailable | Where-Object Name -eq "$name") {
        Import-Module -Name "$name"
        # module was imported
        # return $true
      } 
    }
  } # end PROCESS
} # end function Set-ModuleStatus

function Set-NicConfig {
  <#
      .SYNOPSIS
      Sets specific network configuration for edge server NICs.

      .DESCRIPTION
      Sets specific network configuration for edge server NICs.

      .NOTES
      Version               : 1.6
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log, New-PickList, Remove-NicGateway, Remove-DynamicDnsRegistration
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : Setting bindings on NICs
                              http://techgenix.com/using-powershell-disable-network-adapter-bindings/
                            : PowerShell for Netsh
                              http://windowsitpro.com/powershell/powershell-netsh
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Set-NicConfig

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  Write-Log -Type Info -Message 'Finding available network adapters' -NoConsole
  Write-Output -InputObject "`n"
  Write-Log -Type Info -Message 'Please choose the interface that will be used for INTERNAL traffic'
  $InternalNic = New-PickList -Data $(Get-NetAdapter | Sort-Object -Property Name).Name  
  if ($InternalNic){
    Write-Log -Type Info -Message "Network adapter to be used for internal network is `'$InternalNic`'" -NoConsole -Indent 1
    
    <#
        try{
        Write-Log -Type Info -Message 'Checking status of the Windows firewall' -Indent 1
        if (((Get-Service -Name mpssvc).Status -eq 'Running') -and ($PublicFW) -and ($PrivateFW)){
        Write-Log -Type Info -Message 'Firewall is running for both public and private networks' -Indent 1
        $profiles = (Get-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP').Profile
        Write-Log -Type Info -Message "RDP firewall rule currently enabled for $profiles" -Indent 1 -NoConsole
        if ($profiles -NotMatch 'Private'){
          # TODO: We really should prompt for this:
          Write-Log -Type Info -Message "Setting RDP firewall rule to also work for `'Private`' network profile" -Indent 1
          Set-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP' -Profile $profiles,Public,Private -ErrorAction Stop
        }
        if (-Not(Get-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP').Enabled){
          Write-Log -Type Info -Message "Enabling RDP firewall rule" -Indent 1
          Set-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP' -Enabled True -ErrorAction Stop
        }
        if ((Get-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP').Action -ne 'Allow'){
          Write-Log -Type Info -Message "Setting RDP firewall rule to also allow traffic" -Indent 1
          Set-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP' -Action Allow -ErrorAction Stop
        }
        }else{
        Write-Log -Type Info -Message 'Public firewall profile is NOT enabled for both public and private networks' -NoConsole -Indent 1
        }
        }
        catch{
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
        Write-Log -Type Error -Message "failed setting firewall rule for profile with `"$ErrorMessage`'"
        }

        try{
        If ((Get-NetConnectionProfile -InterfaceAlias $InternalNic).NetworkCategory -ne 'Private'){
        Write-Log -Type Info -Message "Setting `'$InternalNic`' to `'Private`' network category" -Indent 1
        Set-NetConnectionProfile -InterfaceAlias $InternalNic -NetworkCategory Private -ErrorAction Stop
        }else{
        Write-Log -Type Info -Message "`'$InternalNic`' is already set to `'Private`' network category" -Indent 1
        }
        }
        catch{
        Write-Log -Type Error -Message "Error setting `'$InternalNic`' to `'Private`'" -Indent 1
        }
    #>   

    $Gateway = ((Get-NetIPConfiguration -Detailed | Where-Object {$_.InterfaceAlias -eq "$InternalNic"}).IPv4DefaultGateway).nexthop
    if (-Not ($Gateway)){
      Write-Log -Type Info -Message "No gateway currently set on `'$InternalNic`'. Prompting user for gateway address" -NoConsole -Indent 1
      do {$Gateway = Read-Host -Prompt "Enter valid gateway address for `'$InternalNic`'. This will be used for static routes."} while ($Gateway -NotMatch '^(([01]?\d\d?|2[0-4]\d|25[0-5])\.){3}([01]?\d\d?|25[0-5]|2[0-4]\d)$')
      Write-Log -Type Info -Message "User entered `'$Gateway`' as a gateway for `'$InternalNic`'" -NoConsole -Indent 1
    }else{
      $HardcodedGateway = $true
      Write-Log -Type Info -Message "Gateway currently configured on `'$InternalNic`' is $Gateway" -NoConsole -Indent 1
    }
    Write-Log -Type Divider -NoConsole

    Write-Log -Type Info -Message "Creating static routes using `'$InternalNic`'" -NoConsole
    $DefaultRoutes = '10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'
    $SelectedRoutes = $DefaultRoutes | Out-GridView -PassThru -Title 'Pick which networks should have static routes to the INTERNAL NIC. It is recommended that all private IP ranges not routed to the external NIC be routed to the internal NIC. To skip creating static routes, select Cancel.'
    if ($SelectedRoutes){
      Write-Log -Type Info -Message "Selected networks for static routes: $SelectedRoutes" -NoConsole -Indent 1
      $SelectedRoutes | ForEach-Object {
        if (-Not (Get-NetRoute -DestinationPrefix "$_" -InterfaceAlias "$InternalNic" -NextHop $Gateway -ErrorAction SilentlyContinue)){
          Write-Log -Type Info -Message "Setting static route for $_ to `'$InternalNic`' using $Gateway" -NoConsole -Indent 1
          New-NetRoute -DestinationPrefix "$_" -InterfaceAlias "$InternalNic" -NextHop $Gateway | Out-Null
        }else{
          Write-Log -Type Warn -Message "Network route for $_ already exists" -NoConsole -Indent 1
        }
      }
      Write-Log -Type Info -Message "Completed static routes for `'$InternalNic`'" -NoConsole -Indent 1
      Write-Log -Type Divider -NoConsole

      if ($HardcodedGateway){
        Write-Log -Type Warn -Message "A gateway ($gateway) is already hard coded on `'$InternalNic`'. Now that the static routes are created, this script will remove the hardcoded gateway. Only the external interface should have a gateway assigned."
        Write-Log -Type Info -Message "Removing hardcoded gateway $gateway on `'$InternalNic`'" -NoConsole -Indent 1
        Write-Output -InputObject "`n"
        Remove-NicGateway -NicName "$InternalNic"
        $RestartRequired = $true
        Write-Log -Type Divider -NoConsole
      }

      if ($InternalNic){
        Write-Log -Type Info -Message "Resetting DNS config on `'$InternalNic`'" -NoConsole
        if (-Not ((Get-CimInstance -ClassName 'Win32_ComputerSystem').PartOfDomain)){          
          Set-DnsClientServerAddress -InterfaceAlias "$InternalNic" -ResetServerAddresses          
        }else{
          Write-Log -Type Info -Message 'Server is part of a domain. No need to adjust the public firewall profile' -NoConsole -Indent 1
        }
      }
    }else{
      Write-Log -Type Info -Message 'No networks selected for static routes' -NoConsole -Indent 1
    }

    # Write-Log -Type Info -Message "Disabling power management on `'$InternalNic`'" -Indent 1
    # Disable-NetAdapterPowerManagement -Name $InternalNic
  }else{
    Write-Log -Type Error -Message 'No internal network adapter defined' -Indent 1
  }
  Write-Output -InputObject ' '
  Write-Log -Type Divider -NoConsole
  Write-Log -Type Info -Message 'Please choose the interface that will be used for EXTERNAL traffic'
  
  
  $ExternalNic = New-PickList -Data $(Get-NetAdapter | Where-Object {$_.name -ne $InternalNic} | Sort-Object -Property name).name
  if ($ExternalNic){
    Write-Log -Type Info -Message "Network adapter to be used for external network is `'$ExternalNic`'" -NoConsole -Indent 1
    
    
    <#
        try{
        If ((Get-NetConnectionProfile -InterfaceAlias $ExternalNic).NetworkCategory -ne 'Public'){
        Write-Log -Type Info -Message "Setting `'$ExternalNic`' to `'Public`' network category" -Indent 1
        Set-NetConnectionProfile -InterfaceAlias $ExternalNic -NetworkCategory Public -ErrorAction Stop
        }else{
        Write-Log -Type Info -Message "`'$ExternalNic`' is already set to `'Public`' network category" -Indent 1
        }
        }
        catch{
        Write-Log -Type Error -Message "Error setting `'$ExternalNic`' to `'Public`'" -Indent 1
        } 
    #>    
    Write-Log -Type Divider -NoConsole  
    if ($DisableFPSharing -or ((New-Popup -Message "Disable File and Printer Sharing on `'$ExternalNic`'? This is not required, but is recommended." -Title 'Microsoft File and Printer Sharing' -Buttons YesNo -Icon Question) -eq 6)){
      Write-Log -Type Info -Message "User agreed to disable File and Printer Sharing on `'$ExternalNic`'" -NoConsole
      try{
        if ((Get-NetAdapterBinding -Name $ExternalNic | Where-Object {$_.ComponentID -eq 'ms_server'}).Enabled){
          Write-Log -Type Info -Message "Removing `'Microsoft File and Printer Sharing`' from `'$ExternalNic`'" -Indent 1      
          Disable-NetAdapterBinding -Name $ExternalNic -ComponentID ms_server
        }else{
          Write-Log -Type Info -Message "`'Microsoft File and Printer Sharing`' already disabled on `'$ExternalNic`'" -Indent 1      
        }
      }
      catch {
        Write-Log -Type Info -Message "Error removing `'Microsoft File and Printer Sharing`' from `'$ExternalNic`'" -Indent 1
      }
    }
    Write-Log -Type Divider -NoConsole
    Write-Log -Type Info -Message "Disabling dynamic DNS registration for `'$ExternalNic`'"
    Write-Output -InputObject "`n"        
    Remove-DynamicDnsRegistration -AdapterName $ExternalNic

    # Write-Log -Type Info -Message "Disabling power management on `'$ExternalNic`'" -Indent 1
    # Disable-NetAdapterPowerManagement -Name $ExternalNic

    $script:RestartRequired = $true
  }else{
    Write-Log -Type Error -Message 'No external network adapter defined' -Indent 1
  }
  Write-Log -Type Divider -NoConsole
  Write-Log -Type Info -Message 'Prompting to disable LMHosts' -NoConsole
  if ($DisableLmHosts -or ((New-Popup -Message 'Disable LMHosts lookup on this server?' -Title 'LMHosts' -Buttons YesNo -Icon Question) -eq 6)){
    Write-Log -Type Info -Message 'Disabling LMHosts lookup - this will affect all adapters' -Indent 1
    $nics = [wmiclass]'Win32_NetworkAdapterConfiguration'
    $nics.enablewins($false,$false) | Out-Null
    $script:RestartRequired = $true
  }
  Write-Log -Type Divider -NoConsole

  Write-Log -Type Info -Message 'Prompting to disable NetBIOS over TCP/IP' -NoConsole
  if ($DisableNetBios -or ((New-Popup -Message 'Disable NetBIOS over TCP/IP on this server?' -Title 'NetBIOS over TCP/IP' -Buttons YesNo -Icon Question) -eq 6)){
    Write-Log -Type Info -Message 'Disabling NetBIOS over TCP/IP - this will affect all adapters' -Indent 1
    $nics = Get-WmiObject -Class Win32_NetworkAdapterConfiguration
    # $nics = Get-CimInstance -ClassName 'Win32_NetworkAdapterConfiguration'
    # 0 = default
    # 1 = Enable NetBIOS over TCP/IP
    # 2 = Disable NetBIOS over TCP/IP
    $nics.settcpipnetbios(2) | Out-Null
    $script:RestartRequired = $true
    Write-Log -Type Divider -NoConsole
  }
} # end function Set-NicConfig

function Set-NicPowerManagement {
  <#
      .SYNOPSIS
      

      .DESCRIPTION
      

      .PARAMETER Enable
      

      .PARAMETER Disable
      

      .EXAMPLE
      Set-NicPowerManagement -Enable
      

      .EXAMPLE
      Set-NicPowerManagement -Disable
      

      .NOTES
      Version               : 1.0
      Wish list             : 
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .LINK
      

      .INPUTS
      

      .OUTPUTS
      
  #>
  
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, DefaultParameterSetName = 'Disable', HelpUri = 'http://support.microsoft.com/kb/2740020')]
  param(
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Enable')]
    [switch] $Enable,
    
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'Disable')]
    [switch] $Disable
  )
  
  # Find physical adapters that are OK and are enabled
  $NICs = Get-WmiObject -Class 'Win32_NetworkAdapter' | Where-Object {$_.AdapterTypeId -eq 0 -and $_.PhysicalAdapter -and $_.ConfigManagerErrorCode -eq 0 -and $_.ConfigManagerErrorCode -ne 22}
  
  # Cycle through the array of NICs and take action
  ForEach ($NIC in $NICs) {
    $PNPDeviceID = ($NIC.PNPDeviceID).ToUpper()
    $NICPowerMgt = Get-WmiObject -Class 'MSPower_DeviceEnable' -Namespace 'root\wmi' | Where-Object {$_.InstanceName -match [regex]::escape($PNPDeviceID)}
    
    switch ($PsCmdlet.ParameterSetName) {
      enable{
        Write-Log -Type Info -Message "Enabling power management on $($NIC.Name) ($PNPDeviceID)"
        $NICPowerMgt.Enable = $true
        $NICPowerMgt.psbase.Put() | Out-Null
        if ($NICPowerMgt.Enable) {
          Write-Log -Type Info -Message "Enabled power management on $($NIC.Name) ($PNPDeviceID)"          
        } else {
          Write-Log -Type Error -Message "Problem enabling power management on $($NIC.Name) ($PNPDeviceID)"
        }
      }
      disable{
        Write-Log -Type Info -Message 'Disabling power management on network interface cards (NICs)'
        $NICPowerMgt.Enable = $false
        $NICPowerMgt.psbase.Put() | Out-Null
        if ($NICPowerMgt.Enable -eq $false) {
          Write-Log -Type Info -Message "Disabled power management on $($NIC.Name) ($PNPDeviceID)"          
        } else {
          Write-Log -Type Error -Message "Problem disabling power management on $($NIC.Name) ($PNPDeviceID)"
        }
      }
    }    
    # return $NICPowerMgt.Enable
  }
} # end function Set-NicPowerManagement

function Set-PinnedApp {
  <#
      .SYNOPSIS


      .DESCRIPTION


      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, DefaultParameterSetName = 'PinnedAppToTaskbarAdd')]
  param(
    # The path and filename that should be pinned/unpinned
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $file,

    # When specified, pins the defined file to the taskbar. Cannot be used with -unpin
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'PinnedAppToTaskbarAdd')]
    [switch] $pin,

    # When specified, unpins the defined file to the taskbar. Cannot be used with -Pin
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'PinnedAppToTaskbarRemove')]
    [switch] $unpin
  ) # end of param block

  switch ($PsCmdlet.ParameterSetName) {
    PinnedAppToTaskbarAdd{
      [string]$PinVerb = 'Pin to Taskbar'
    }
    PinnedAppToTaskbarRemove{
      [string]$PinVerb = 'Unpin from Taskbar'
    }
  }
  if (Test-Path -Path $file -ErrorAction SilentlyContinue){
    $path = ($file | Split-Path -Parent) +'\'
    $shell = New-Object -ComObject 'Shell.Application'
    $folder = $shell.Namespace($path)
    $item = $folder.ParseName($file.SubString($file.Length-($file.Split('\')[$file.Split('\').Count-1].Length)))
    $verbs = $item.Verbs()
    foreach ($v in $verbs){
      if ($v.Name.Replace("`&",'') -match $PinVerb){
        $v.DoIt()
      }
    }
  } else {
    Write-Log -Type Error -message "$file does not exist" -Indent 1
  }
} # end function Set-PinnedApp

function Set-PowerPlan {
  <#
      .SYNOPSIS
      Configures the Power Plan on the local machine. Called from Set-HighPower.

      .DESCRIPTION
      Configures the Power Plan on the local machine. Called from Set-HighPower.

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/2558
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : Powercfg Command-Line Options
                              https://technet.microsoft.com/en-us/library/cc748940%28v=ws.10%29.aspx?f=255&MSPPError=-2147217396
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Set-PowerPlan -PreferredPlan 'High Performance'

      Description
      -----------
      Sets the preferred power plan on the computer to 'High Performance'

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/2558')]
  param (
    # Defines the power plan the set the computer to
    [ValidateSet('High performance', 'Balanced', 'Power saver')]
    [ValidateNotNullOrEmpty()]
    [string] $PreferredPlan = 'High Performance'
  ) # end of param block
  Write-Log -Type Info -Message "Setting power plan to `'$PreferredPlan`'" -Indent 1  
  $guid = (Get-CimInstance -ClassName 'Win32_PowerPlan' -Namespace 'root\cimv2\power' -Filter "ElementName='$PreferredPlan'").InstanceID.ToString()
  $regex = [regex]'{(.*?)}$'
  $plan = $regex.Match($guid).groups[1].value

  & "$env:windir\system32\powercfg.exe" -Setactive $plan  
  $Output = "Power plan set to `'" + ((Get-CimInstance -ClassName 'Win32_PowerPlan' -Namespace 'root\cimv2\power' -Filter "IsActive='$True'").ElementName) + "`'"
  Write-Log -Type Info -Message $Output -NoConsole -Indent 1
  Write-Log -Type Info -Message 'Disabling hibernation' -NoConsole -Indent 1
  & "$env:windir\system32\powercfg.exe" -Hibernate off
} # end function Set-PowerPlan

function Set-PrimaryDnsSuffix {
  <#
      .SYNOPSIS
      Sets the primary DNS name for non-domain joined edge servers.

      .DESCRIPTION
      Sets the primary DNS name for non-domain joined edge servers.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup, Set-RunOnce, Stop-Script
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Set-PrimaryDnsSuffix

      Description
      -----------
      Will prompt for the desired primary DNS suffix, and then configure it on the local machine.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  if ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -Name Domain).Domain -NotMatch '([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$'){
    if (-Not($DomainSuffix) -or ($DomainSuffix -and ($DomainSuffix -NotMatch '([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$'))){
      Add-Type -AssemblyName Microsoft.VisualBasic | Out-Null
      Do {
        Write-Log -Type Info -Message 'Prompting for primary DNS suffix' -NoConsole -Indent 1
        # format is message, title, default value
        $DomainSuffix = [Microsoft.VisualBasic.Interaction]::InputBox('Enter primary domain suffix', 'Computer name/domain changes', '')
      }While(
        $DomainSuffix -NotMatch '([A-Za-z0-9-]{2,63}\.\w{2,63}\.\w{2,63}|\w{2,63}\.\w{2,63})$'
      )
    }
    if ($DomainSuffix){
      Write-Log -Type Info -Message "Domain suffix submitted is `'$DomainSuffix`'" -NoConsole -Indent 1
      Write-Log -Type Info -Message "Adding `'$DomainSuffix`' domain suffix to $env:ComputerName" -NoConsole -Indent 1
      Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -Name 'Domain' -Value $DomainSuffix
      $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -Name 'NV Domain' -Value $DomainSuffix
      Write-Log -Type Info -Message "Domain suffix `'$DomainSuffix`' configured, but requires a server reboot to become active. Reboot this server before installing Lync/Skype for Business Server." -Indent 1
      $RestartRequired = $true
    }
  }else{
    Write-Log -Type Info -Message 'Primary DNS suffix already configured'
  }
} # end function Set-PrimaryDnsSuffix

function Set-RunningStatus {
  <#
      .SYNOPSIS
      Sets a registry value that the script is running.

      .DESCRIPTION
      Sets a registry value that the script is running. This can be queried to see if any user currently logged in, is running the script. This is important to help reduce issues when the script has to restart after restarting, and a different user manages to log in first.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Set-RunningStatus -Running

      Description
      -----------
      Sets the registry value to show that the script is running.

      .EXAMPLE
      Set-RunningStatus -Stopped

      Description
      -----------
      Sets the registry value to show that the script is no longer running. This is set when the script gracefully exits.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, DefaultParameterSetName = 'running')]
  param(
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'running')]
    [switch] $Running,
    [Parameter(ValueFromPipelineByPropertyName, ParameterSetName = 'stopped')]
    [switch] $Stopped
  ) # end of param block
  switch ($PsCmdlet.ParameterSetName) {
    'running'  {$StatusRegValue = 1}
    'stopped'  {$StatusRegValue = 0}
  }
  if (-Not (Test-Path -Path 'HKLM:\SOFTWARE\Innervation')){
    $null = New-Item -Path 'HKLM:\SOFTWARE' -Name 'Innervation'
  }
  if (-Not (Test-Path -Path $RunOnceRoot)){
    Write-Log -Type Info -Message "Creating root registry key for $ThisScriptName" -NoConsole
    $null = New-Item -Path 'HKLM:\SOFTWARE\Innervation' -Name $ThisScriptName
  }
  $null = New-ItemProperty -Path $RunOnceRoot -Name running -Value $StatusRegValue -PropertyType 'DWord' -Force
} # end function Set-RunningStatus

function Set-RunOnce {
  <#
      .SYNOPSIS
      Sets registry keys to restart the script after a server reboot.

      .DESCRIPTION
      Sets registry keys to restart the script after a server reboot. It takes into account various parameters that the script will need.

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, New-Popup
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Set-RunOnce

      Description
      -----------
      Sets the appropriate registry values based on parameters used to call the script, plus any other values determined to be necessary by the running script.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    # [int] $InitialMenuOption
  ) # end of param block
  if (-Not $SkipAutoStart){
    Write-Log -Type Info -Message 'Setting registry entries for RunOnce' -NoConsole
    if (-Not (Test-Path -Path 'HKLM:\SOFTWARE\Innervation')){
      Write-Log -Type Info -Message 'Creating registry root key to store data about my scripts'
      $null = New-Item -Path 'HKLM:\SOFTWARE' -Name 'Innervation'
    }
    if (-Not (Test-Path -Path $RunOnceRoot)){
      Write-Log -Type Info -Message "Creating registry `"$ThisScriptName`" key to store data for this specific script"
      $null = New-Item -Path 'HKLM:\SOFTWARE\Innervation' -Name $ThisScriptName
    }
    if ($WindowsSourceIso){$WindowsSource = $WindowsSourceIso}
    if (Test-Path -Path $RunOnceRoot){
      Write-Log -Type Info -Message "Setting registry `"SQLPath`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'SQLPath' -Value "$SQLPath" -Force
      Write-Log -Type Info -Message "Setting registry `"TargetFolder`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'TargetFolder' -Value "$TargetFolder" -Force
      Write-Log -Type Info -Message "Setting registry `"WindowsSource`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'WindowsSource' -Value "$WindowsSource" -Force
    }

    if ($InitialMenuOption){$MenuOption = $InitialMenuOption}  
    $RegistryCommand = "$ScriptPathAndName -GetInfoFromRegistry"
    # Commented out the following 'if' logic to resolve the issue where a 2nd reboot wouldn't call the InitialMenuOption. In theory, this function won't get called if InitialMenuOption isn't at play, so we're safe. In fact, we should do some detection to ensure that InitialMenuOption *IS* set before restarting. Otherwise, it boots into the menu during runonce.
  
    if ($MenuOption){
      Write-Log -Type Info -Message "Setting registry `"InitialMenuOption`" key to match MenuOption" -NoConsole -Indent 1
      $RegistryCommand += " -InitialMenuOption $MenuOption"
    }elseif ($InitialMenuOption) {
      Write-Log -Type Info -Message "Setting registry `"InitialMenuOption`" key to match InitialMenuOption" -NoConsole -Indent 1
      $RegistryCommand += " -InitialMenuOption $InitialMenuOption"
    }
    if ($IncludeSSMS){
      Write-Log -Type Info -Message "Setting registry `"IncludeSSMS`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeSSMS' -Value 1 -Force
    }
    if ($IncludeTelnet){
      Write-Log -Type Info -Message "Setting registry `"IncludeTelnet`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeTelnet' -Value 1 -Force
    }
    if ($IncludeFW){
      Write-Log -Type Info -Message "Setting registry `"IncludeFW`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeFW' -Value 1 -Force
    }
    if ($IncludeHighPower){
      Write-Log -Type Info -Message "Setting registry `"IncludeHighPower`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeHighPower' -Value 1 -Force
    }
    if ($IncludeOnlineAdminTools){
      Write-Log -Type Info -Message "Setting registry `"IncludeOnlineAdminTools`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeOnlineAdminTools' -Value 1 -Force
    }
    if ($IncludeStandard){
      Write-Log -Type Info -Message "Setting registry `"IncludeStandard`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeStandard' -Value 1 -Force
    }
    if ($DisableWAC){
      Write-Log -Type Info -Message "Setting registry `"DisableWac`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'DisableWac' -Value 1 -Force
    }
    if ($IncludeLanguagePack){
      Write-Log -Type Info -Message "Setting registry `"IncludeLanguagePack`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeLanguagePack' -Value 1 -Force
    }
    if ($tail){
      $RegistryCommand += ' -Tail'
    }
    if ($Skype4B){
      $RegistryCommand += ' -Skype4b'
    }
    if ($skype4b2019){
      $RegistryCommand += ' -Skype4b2019'
    }
    if ($SkipEdgeNicConfig){
      Write-Log -Type Info -Message "Setting registry `"SkipEdgeNicConfig`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'SkipEdgeNicConfig' -Value 1 -Force
    }
    if ($DisableAutoUpdates){
      Write-Log -Type Info -Message "Setting registry `"DisableAutoUpdates`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'DisableAutoUpdates' -Value 1 -Force
    }
    
    if ($DisableFPSharing){
      Write-Log -Type Info -Message "Setting registry `"DisableFPSharing`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'DisableFPSharing' -Value 1 -Force
    }
    if ($DisableLmHosts){
      Write-Log -Type Info -Message "Setting registry `"DisableLmHosts`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'DisableLmHosts' -Value 1 -Force
    }
    if ($DisableNetBios){
      Write-Log -Type Info -Message "Setting registry `"DisableNetBios`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'DisableNetBios' -Value 1 -Force
    }
    if ($IncludeTrustedCerts){
      Write-Log -Type Info -Message "Setting registry `"IncludeTrustedCerts`" key" -NoConsole -Indent 1
      Set-ItemProperty -Path $RunOnceRoot -Name 'IncludeTrustedCerts' -Value 1 -Force
    }

    $RunOnceRegValue = "$PSHOME\powershell.exe -NoProfile -Command `"$RegistryCommand`""
    if ($RunOnceRegValue.Length -gt 255){
      Write-Log -Type Error -Message "RunOnce registry value of $($RunOnceRegValue.Length) characters is too long"  -NoConsole -Indent 1
    }else{
      Write-Log -Type Info -Message "RunOnce registry value is $($RunOnceRegValue.Length) characters long. Max is 250." -NoConsole -Indent 1
    }
    Write-Log -Type Info -Message "Setting runonce value of `"$RunOnceRegValue`"" -NoConsole -Indent 1

    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce' -Name 'Set-CsFeatures.ps1' -Value "$PSHOME\powershell.exe -NoProfile -Command `"$RegistryCommand`""

    if ((New-Popup -Message 'This server will now reboot. Once you login, the script will automatically continue. NOTE: IT CAN TAKE A WHILE BEFORE YOU SEE THE SCRIPT WORKING. THIS IS DUE TO POWERSHELL INITIALIZING AFTER THE REBOOT AND IS NOT A PROBLEM WITH THE SCRIPT!' -Title 'Restart is required' -Buttons Ok -Icon Question) -eq 1){
      Write-Log -Type Info -Message 'User acknowledged PowerShell initialization warning.' -NoConsole
    }
  } else {
    Write-Log -Type Warn -Message 'User specified SkipAutoStart switch. RunOnce config NOT being defined. User will need to manually run script again after reboot.' -NoConsole
  }
  # Write-Log -Type Divider -NoConsole
} # end function Set-RunOnce

function Set-UacStatus {
  <#
      .SYNOPSIS
      Enables or disables User Account Control (UAC) on a computer.

      .DESCRIPTION
      Enables or disables User Account Control (UAC) on a computer.

      .NOTES
      Version               : 1.0
      Rights Required       : Local admin on server
                            : ExecutionPolicy of RemoteSigned or Unrestricted
      Function Dependencies : Write-Log, New-Popup, Set-RunOnce, Stop-Script
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/1026
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known
      
      .EXAMPLE
      Set-UacStatus -Enabled [$true|$false]

      Description
      -----------
      Enables or disables UAC for the local computer.

      .EXAMPLE
      Set-UacStatus -Computer [computer name] -Enabled [$true|$false]

      Description
      -----------
      Enables or disables UAC for the computer specified via -Computer.

      .INPUTS
      None. You cannot pipe objects to this script.

      #Requires -Version 2.0
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'https://ucunleashed.com/1026')]
  param(
    [parameter(ValueFromPipelineByPropertyName)]
    [string] $Computer = $env:ComputerName,
    
    [parameter(ValueFromPipelineByPropertyName, Mandatory, HelpMessage = 'Specify whether enabled')]
    [bool] $enabled = $false
  ) # end of param block
  [string] $RegistryValue = 'EnableLUA'
  [string] $RegistryPath = 'Software\Microsoft\Windows\CurrentVersion\Policies\System'
  $OpenRegistry = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,$Computer)
  $Subkey = $OpenRegistry.OpenSubKey($RegistryPath,$true)
  $Subkey.ToString() | Out-Null
  if ($enabled -eq $true){
    $Subkey.SetValue($RegistryValue, 1)
  }else{
    $Subkey.SetValue($RegistryValue, 0)
  }
  $UACStatus = $Subkey.GetValue($RegistryValue)
  $UACStatus
  if ((New-Popup -Message "Setting this requires a reboot of $Computer. Would you like to reboot $Computer`?" -Title 'Disable UAC' -Buttons YesNo -Icon Question) -eq 6){
    Write-Log -Type Info -Message 'User chose to reboot' -NoConsole
    Set-RunOnce
    Stop-Script -Reboot
  }else{
    Write-Output -InputObject "Please restart $Computer when convenient"
  }
} # end function Set-UacStatus

function Stop-Script {
  <#
      .SYNOPSIS
      Performs all tasks required when exiting the script.

      .DESCRIPTION
      Performs all tasks required when exiting the script. This includes calling other functions to set running status, calculating elapsed time, writing to the log file, etc. It can also call for a reboot if specified.

      .NOTES
      Version               : 1.2
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Set-ElapsedTime, Set-RunningStatus
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Stop-Script

      Description
      -----------
      Takes appropriate actions to gracefully stop script, including setting runonce registry values (if needed), calculating elapsed running time, and any needed cleanup.

      .EXAMPLE
      Stop-Script -Reboot

      Description
      -----------
      Same as without the reboot switch, but also restarts the computer.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param(
    [parameter(ValueFromPipelineByPropertyName)]
    [switch] $Reboot
  ) # end of param block
  Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  Write-Log -Type Divider -NoConsole
  if ($WindowsSourceIso){
    Write-Log -Type Info -Message "Dismounting Windows server ISO from $WindowsSource" -NoConsole
    Dismount-DiskImage -ImagePath $WindowsSourceIso
  }
  Set-ElapsedTime
  Set-RunningStatus -Stopped
  if ($reboot){
    Write-Log -Type Info -Message 'Restarting server' -NoConsole
    Write-Log -Type Info -Message "v$ScriptVersion script end" -EventLogName Application -EventId 1 -NoConsole
    Restart-Computer -force
    exit
  }else{    
    if ($PowerShellTailId.count -eq 1){
      try {
        Stop-Process -Id $PowerShellTailId -ErrorAction Stop
        # Stop-Process -Id $PowerShellTailId
      }    
      catch {
        Write-Log -Type Warn -Message 'Unable to close tail window. May have been closed previously.' -NoConsole
        Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
      }
    }
    Write-Log -Type Info -Message "v$ScriptVersion script end" -EventLogName application -EventId 1 -NoConsole
    exit
  }
} # end function Stop-Script

function Test-InvalidCert {
  <#
      .SYNOPSIS
      Checks root and intermediate certificate stores for certificates in the wrong store & moves them to the correct store.

      .DESCRIPTION
      Checks root and intermediate certificate stores for certificates in the wrong store & moves them to the correct store. Certificates in the wrong store can be very problematic for Lync Server and Skype for Business Server.

      .NOTES
      Version               : 1.3
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : https://ucunleashed.com/3903
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\Test-InvalidCerts.ps1

      Description
      -----------
      Checks root and intermediate store for certs in the wrong store & moves them to the proper store.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging, HelpUri = 'https://ucunleashed.com/3903')]
  param(
    # When specified, will automatically resolve issues in the Trusted Root Certification Authorities Store
    [Parameter(ValueFromPipelineByPropertyName)]
    [switch] $FixRootStore,
    
    # When specified, will automatically resolve issues in the Intermediate Certification Authorities Store
    [Parameter(ValueFromPipelineByPropertyName)]
    [switch] $FixIntermediateStore
  ) # end of param block
  BEGIN{
    Write-Log -Type Info -Message "Calling `'$((Get-PSCallStack).FunctionName[0])`' with `'$((Get-PSCallStack).Arguments[0])`' from line $((Get-PSCallStack).ScriptLineNumber[1])" -NoConsole
  }
  PROCESS{
    Write-Log -Type Info -Message 'Checking for improper certs in Trusted Root Certification Authorities Store' -NoConsole
    $InvalidCertsInRoot = Get-Childitem -Path cert:\LocalMachine\root -Recurse | Where-Object {$_.Issuer -ne $_.Subject}

    if ($InvalidCertsInRoot){        
      Write-Log -Type Warn -Message ('{0} invalid certificate(s) detected in Trusted Root Certification Authorities Store' -f $InvalidCertsInRoot.count) -NoConsole -Indent 1
      if ($FixRootStore){
        Write-Log -Type Info -Message 'Attempting to resolve issues in Trusted Root Certification Authorities Store' -NoConsole -Indent 1
        ForEach ($cert in $InvalidCertsInRoot){
          Write-Log -Type Info -Message "Moving $($cert.subject) to Intermediate Certification Authorities Store" -NoConsole -Indent 1
          Move-Item -Path $cert.PSPath -Destination Cert:\LocalMachine\CA -Force
        }
      }
    }else{
      Write-Log -Type Info -Message 'No invalid certs found in Trusted Root Certification Authorities Store' -NoConsole -Indent 1
    }
    Write-Log -Type Info -Message 'Checking for improper certs in Intermediate Certification Authorities Store' -NoConsole
    $InvalidCertsInInt = Get-Childitem -Path cert:\LocalMachine\Ca -Recurse | Where-Object {$_.Issuer -eq $_.Subject}
    if ($InvalidCertsInInt){
      Write-Log -Type Warn -Message ('{0} invalid certificate(s) detected in Intermediate Certification Authorities Store' -f $InvalidCertsInInt.count) -NoConsole -Indent 1
      if ($FixIntermediateStore){
        Write-Log -Type Info -Message 'Attempting to resolve issues in Intermediate Certification Authorities Store' -NoConsole -Indent 1
        ForEach ($cert in $InvalidCertsInInt){
          Write-Log -Type Info -Message "Moving $($cert.subject) to Trusted Root Certificate Store" -NoConsole -Indent 1
          Move-Item -Path $cert.PSPath -Destination Cert:\LocalMachine\Root -Force
        }
      }
    }else{
      Write-Log -Type Info -Message 'No invalid certs found in Intermediate Certification Authorities Store' -NoConsole -Indent 1
    }
  }
  END {
    Write-Log -Type Divider -NoConsole
  }
} # end function Test-InvalidCert

function Test-IsAdmin {
  <#
      .SYNOPSIS
      Determines if the user running the script is a local admin.

      .DESCRIPTION
      Determines if the user running the script is a local admin.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging)]
  param(
  ) # end of param block
  $principal = New-Object -TypeName System.Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
  $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
} # end function Test-IsAdmin

function Test-IsProxyEnabled {
  <#
      .SYNOPSIS
      Determines (the best it can) if a proxy is in place for Internet access.

      .DESCRIPTION
      Determines (the best it can) if a proxy is in place for Internet access. If so, other functions that download files can better handle downloads.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  Write-Log -Type Info -Message 'Checking if a proxy is enabled' -NoConsole -Indent 1
  # If this registry key does not exist at all, it's because IE has never been launched. We need to create it here so that download attempts and proxy checks do not throw a silent error
  if ((Get-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings').Property -NotContains 'ProxyEnable'){
    Write-Log -Type Info -Message 'Internet Explorer has never been opened. Proxy registry values have yet to be set. Setting it to 0 now.' -NoConsole -Indent 1
    $null = New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0
  }
  if ((Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -ErrorAction SilentlyContinue).ProxyEnable -ne 0){
    Write-Log -Type Info -Message 'A proxy is required' -NoConsole -Indent 2
    [string]$ProxyServer = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyServer).ProxyServer
    Write-Log -Type Info -Message "Configured proxy: `"$ProxyServer`"" -NoConsole -Indent 2

    if (-Not ($PSDefaultParameterValues.ContainsKey('Start-BitsTransfer:ProxyAuthentication'))){
      Write-Log -Type Info -Message 'Prompting for credentials' -NoConsole -Indent 2
      $ProxyCredentials = Get-Credential -Message "Enter Proxy authentication credentials for $ProxyServer" -UserName "${env:USERDOMAIN}\${env:UserName}"
      if ($ProxyCredentials){
        Write-Log -Type Info -Message 'Credentials entered' -NoConsole -Indent 2
        Write-Log -Type Info -Message 'Adding default values for Start-BitsTransfer' -NoConsole -Indent 2
        Write-Log -Type Info -Message "Adding default value for ProxyAuthentication - `"Basic`"" -NoConsole -Indent 2
        $PSDefaultParameterValues.Add('Start-BitsTransfer:ProxyAuthentication','Basic')
        $ProxyUserName = $ProxyCredentials.username
        Write-Log -Type Info -Message "Adding default value for ProxyCredential - `"$ProxyUserName`"" -NoConsole -Indent 2
        $PSDefaultParameterValues.Add('Start-BitsTransfer:ProxyCredential',$ProxyCredentials)
        # Write-Log -Type Info -Message "Adding default value for ProxyList - `"$ProxyServer`"" -NoConsole -Indent 1
        # $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyList",$ProxyServer)
        # Write-Log -Type Info -Message "Adding default value for ProxyUsage - `"AutoDetect`"" -NoConsole -Indent 1
        # $PSDefaultParameterValues.Add("Start-BitsTransfer:ProxyUsage","AutoDetect")
      } else {
        Write-Log -Type Error -message 'Credentials NOT entered. Following commands will likely fail' -NoConsole -Indent 2
      }
    }
  } else {
    Write-Log -Type Info -Message 'Proxy is not enabled' -NoConsole -Indent 2
    # Clear the error queue in case the proxy registry key did not exist at all and threw an error.
    $error.clear()
  }
} # end function Test-IsProxyEnabled

function Test-IsRebootRequired  { # http://technet.microsoft.com/en-us/library/cc164360(v=EXCHG.80).aspx
  <#
      .SYNOPSIS
      Looks for key indicators that a restart is required on the local machine.

      .DESCRIPTION
      Looks for key indicators that a restart is required on the local machine. This is done by checking known registry keys, as well as some variables set within the script itself. It returns a true/false.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : http://mickitblog.blogspot.com/2017/07/pending-reboot-reporting.html
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Test-IsRebootRequired

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging)]
  param(
  ) # end of param block
  # Checks if File rename operations are taking place and require a reboot for the operation to take effect
  $PendingFileRenameOperations = $(Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)

  # Checks if the RebootPending key is present. It is created when changes are made to the component store that require a reboot to take place
  $ComponentBasedReboot = $(Test-Path -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' -ErrorAction SilentlyContinue)

  # Checks if the registry key RebootRequired is present. It is created when Windows Updates are applied and require a reboot to take place
  $WUAU = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update' -Name RebootRequired -ErrorAction SilentlyContinue)

  # domain join
  try{
    Write-Log -Type Info -Message 'Checking for domain membership change that would require a reboot.' -NoConsole
    $JoinDomain = $(Get-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\JoinDomain' -ErrorAction Stop)
    $AvoidSpnSet = $(Get-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\AvoidSpnSet' -ErrorAction Stop)
  }
  catch [Management.Automation.ItemNotFoundException] {
    Write-Log -Type Info -Message 'Checking for domain membership changes threw an error that we expect. It is no big deal.' -NoConsole -Indent 1
  }
  catch { # catchall
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning -Message "Unexpected failure with `"$ErrorMessage`'"
  }

  #Performs a WMI query of the configuration manager service to check if a reboot is pending
  $ConfigurationManagerReboot = Invoke-WmiMethod -Namespace 'ROOT\ccm\ClientSDK' -Class CCM_ClientUtilities -Name DetermineIfRebootPending -ErrorAction SilentlyContinue | Select-Object -ExpandProperty 'RebootPending'

  if ($PendingFileRenameOperations -or $ComponentBasedReboot -or $WUAU -or $JoinDomain -or $AvoidSpnSet -or $ConfigurationManagerReboot -or $RestartRequired){    
    $RestartNeeded = $true
    return $true
  }else{
    return $false
   }
} # end function Test-IsRebootRequired

function Test-IsRebootRequired.Old  { # http://technet.microsoft.com/en-us/library/cc164360(v=EXCHG.80).aspx
  <#
      .SYNOPSIS
      Looks for key indicators that a restart is required on the local machine.

      .DESCRIPTION
      Looks for key indicators that a restart is required on the local machine. This is done by checking known registry keys, as well as some variables set within the script itself. It returns a true/false.

      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : Write-Log
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging)]
  param(
  ) # end of param block
  if ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) -or (Test-Path -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' -ErrorAction SilentlyContinue) -or (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update' -Name rebootrequired -ErrorAction SilentlyContinue) -or $RestartRequired){
    $RestartNeeded = $true
    return $true
  }
} # end function Test-IsRebootRequired

function Test-IsServerCore {
  <#
      .SYNOPSIS
      Determines in the local machine is running Windows Server Core (without a GUI) or not.

      .DESCRIPTION
      Determines in the local machine is running Windows Server Core (without a GUI) or not. This can be key in some scripts. This works in Server 2012 R2, Server 2016, and Server 2019 (Preview)

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
      Function Dependencies : Write-Log, Set-ModuleStatus
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : Michel de Rooij's method of checking registry instead of using Get-WindowsFeature (yes, I do look at other                        people's scripts for ideas!)
                              https://github.com/michelderooij/Install-Exchange15
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      Test-IsServerCore

      Description
      -----------
      Returns $true or $false depending on if the underlying OS is Server Core.

      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging)]
  param (
  ) # end of param block
  Write-Log -Type Info -Message 'Testing for server core'
  Set-ModuleStatus -Name ServerManager | Out-Null
  # return ((Get-WindowsFeature -Name Server-Gui-Shell).Installed -eq $false)
  return (Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion' -Name 'InstallationType').InstallationType -eq 'Server Core'
} # end function Test-IsServerCore

function Test-IsSigned {
  <#
      .SYNOPSIS
      Checks to see if the file containing this function is signed with a code signing certificate.

      .DESCRIPTION
      Checks to see if the file containing this function is signed with a code signing certificate.

      .NOTES
      Version               : 1.1
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server
                            : If script is not signed, ExecutionPolicy of RemoteSigned or Unrestricted
                            : If script is signed, ExecutionPolicy of AllSigned, RemoteSigned, or Unrestricted
      Function Dependencies : None
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Blog Post   : https://ucunleashed.com/1697
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!    
      Limitations           : None known

      .EXAMPLE
      PS C:\>

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this function.

      .OUTPUTS
      Boolean output
  #>
  [CmdletBinding(SupportsPaging, HelpUri = 'https://ucunleashed.com/1697')]
  param (
    [Parameter(Position = 0, ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [IO.FileInfo[]] $FilePath = $MyInvocation.ScriptName
  ) # end of param block

  PROCESS{
    if ((Get-AuthenticodeSignature -FilePath $FilePath).Status -eq 'Valid'){
      return $true
    } else {
      return $False
    }
  } # end PROCESS
} # end function Test-IsSigned

function Test-IsUriWeb { # http://powershell.com/cs/media/p/394.aspx
  <#
      .SYNOPSIS


      .DESCRIPTION


      .NOTES
      Version               : 1.0
      Wish list             : Better error trapping
      Rights Required       : None
      Function Dependencies : None
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter    : pat@innervation.com  https://ucunleashed.com  @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : N/A
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : N/A
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned, or Unrestricted (not recommended)
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : None known

      .EXAMPLE
      .\

      Description
      -----------


      .INPUTS
      None. You cannot pipe objects to this script.
  #>
  [CmdletBinding(SupportsPaging)]
  [OutputType('System.Boolean')]
  param (
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $address
  ) # end of param block
  $uri = $address -as [uri]
  return (($null -ne $uri.AbsoluteURI) -and ($uri.Scheme -match '[http|https]'))
} # end function Test-IsUriWeb

function Write-Log {
  <#
      .SYNOPSIS
      Extensive function to write data to either the console screen, a log file, and/or a Windows event log.

      .DESCRIPTION
      Extensive function to write data to either the console screen, a log file, and/or a Windows event log. Data can be written as info, warning, error, and includes indentation, time stamps, etc.

      .NOTES
      Version               : 3.6
      Wish list             : Better error trapping
      Rights Required       : Local administrator on server if writing to event log(s)
      Function Dependencies : None
      Sched Task Required   : No
      Lync/Skype4B Version  : N/A
      Author/Copyright      : © Pat Richard, Office Apps and Services (Skype for Business/Teams) MVP - All Rights Reserved
      Email/Blog/Twitter		: pat@innervation.com 	https://www.ucunleashed.com @patrichard
      Donations             : https://www.paypal.me/PatRichard
      Dedicated Post        : http://poshcode.org/6894
      Disclaimer            : You running this script/function means you will not blame the author(s) if this breaks your stuff. This
                              script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied warranties
                              including, without limitation, any implied warranties of merchantability or of fitness for a particular
                              purpose. The entire risk arising out of the use or performance of the sample scripts and documentation
                              remains with you. In no event shall author(s) be held liable for any damages whatsoever (including, 
                              without limitation, damages for loss of business profits, business interruption, loss of business
                              information, or other pecuniary loss) arising out of the use of or inability to use the script or
                              documentation. Neither this script/function, nor any part of it other than those parts that are explicitly
                              copied from others, may be republished without author(s) express written permission. Author(s) retain the
                              right to alter this disclaimer at any time. For the most up to date version of the disclaimer, see 
                              https://ucunleashed.com/code-disclaimer.
      Acknowledgements      : Based on an original function by Any Arismendi, along with updates by others
                              http://poshcode.org/2566                            
                            : Test for log names and sources
                              http://powershell.com/cs/blogs/tips/archive/2013/06/10/testing-event-log-names-and-sources.aspx   
                            : Writing to different event logs and sources registered to a single event log
                              http://social.technet.microsoft.com/Forums/en-US/winserverpowershell/thread/e172f039-ce88-4c9f-b19a-0dd6dc568fa0/
      Assumptions           : ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)    
      Known issues          : None yet, but I'm sure you'll find some!
      Limitations           : Writing to event logs requires admin rights

      .EXAMPLE
      Write-Log -Type Info -Message 'The disk is full'

      Description
      -----------
      Adds the specified information to the log file. If the log file doesn't exist, it will automatically be created.

      .EXAMPLE
      Write-Log -Type Divider -NoConsole

      Description
      -----------
      Adds the divider to the logfile, but doesn't display it to the screen.

      .INPUTS
      System.String. You cannot pipe objects to this script.

      .OUTPUTS
      System.String
  #>
  [CmdletBinding(SupportsShouldProcess, SupportsPaging, HelpUri = 'http://poshcode.org/6894')]
  param(
    # The type of message to be logged. Alias is 'type'.
    [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [ValidateSet('Error', 'Warn', 'Info', 'Verbose', 'Divider')]
    [ValidateNotNullOrEmpty()]
    [string] $Type = 'Info',

    # The message to be logged. This is required for all types except for 'divider'
    [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
    [string] $Message,

    # Specifies that $message should not the sent to the log file.
    [Parameter(ValueFromPipelineByPropertyName)]
    [switch] $NoLog,

    # Specifies to not display the message to the console.
    [Parameter(ValueFromPipelineByPropertyName)]
    [switch] $NoConsole,

    # The number of spaces to indent the message in the log file.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateRange(1,30)]
    [ValidateNotNullOrEmpty()]
    [int] $Indent = 0,

    # Specifies what color the text should be be displayed on the console. Ignored when switch 'NoConsoleOut' is specified.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateSet('Black', 'DarkMagenta', 'DarkRed', 'DarkBlue', 'DarkGreen', 'DarkCyan', 'DarkYellow', 'Red', 'Blue', 'Green', 'Cyan', 'Magenta', 'Yellow', 'DarkGray', 'Gray', 'White')]
    [ValidateNotNullOrEmpty()]
    [String] $ConsoleForeground = 'White',

    # Existing log file is deleted when this is specified. Alias is 'Overwrite'.
    [Parameter(ValueFromPipelineByPropertyName)]
    [Switch] $Clobber,

    # The name of the system event log, e.g. 'Application'. The Skype for Business log is still called 'Lync Server'. Note that writing to the system event log requires elevated permissions.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateSet('Application', 'System', 'Security', 'Lync Server', 'Microsoft Office Web Apps')]
    [ValidateNotNullOrEmpty()]
    [String] $EventLogName,

    # The name to appear as the source attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [String] $EventSource = $([IO.FileInfo] $MyInvocation.ScriptName).Name,

    # The ID to appear as the event ID attribute for the system event log entry. This is ignored unless 'EventLogName' is specified.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateRange(1,65535)]
    [ValidateNotNullOrEmpty()]
    [int] $EventID = 1,

    # The text encoding for the log file. Default is ASCII.
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateSet('Unicode','Byte','BigEndianUnicode','UTF8','UTF7','UTF32','ASCII','Default','OEM')]
    [ValidateNotNullOrEmpty()]
    [String] $LogEncoding = 'ASCII',
        
    # Destination folder for log files
    # [Parameter(ValueFromPipelineByPropertyName)]
    # [ValidateNotNullOrEmpty()]
    # [string] $LogPath = "$TargetFolder\logs\$env:ComputerName" + ' {0:yyyy-MM-dd hh-mmtt}.log' -f (Get-Date),
    
    # Divider line to be used to separate sections in the log file
    [Parameter(ValueFromPipelineByPropertyName)]
    [ValidateNotNullOrEmpty()]
    [string] $LogDivider = '+------------------------------+'
  ) # end of param block
  BEGIN{
    [string]$LogFolder = Split-Path -Path $LogPath -Parent
    if (-not (Test-Path -Path $LogFolder)){
      $null = New-Item -Path $LogFolder -ItemType Directory
    }
  } # end BEGIN
  PROCESS{
    try {
      $Message = $($Message.trim())
      if ($type -ne 'divider'){
        $msg = '{0} : {1} : {2}{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), ($type.ToUpper()).PadRight(5,' '), ('  ' * $Indent), $Message
      }else{
        $msg = '{0} : {1} : {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), '-----', $LogDivider
      }
      if (-not ($NoConsole)){
        switch ($type) {
          'Error' {$Host.UI.WriteErrorLine("$Message")}
          'Warn' {Write-Warning -Message $Message}
          'Info' {Write-Host $Message -ForegroundColor $ConsoleForeground}
          'Verbose' {Write-Verbose -Message $Message}
          'Divider' {Write-Host $Message -ForegroundColor $ConsoleForeground}
        }
      }
      if (-not ($NoLog)){
        if ($Clobber) {
          $msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Force
        } else {
          $msg | Out-File -FilePath $LogPath -Encoding $LogEncoding -Append
        }
      }
      if ($EventLogName) {
        if (-not $EventSource) {
          [string] $EventSource = $([IO.FileInfo] $MyInvocation.ScriptName).Name
        }

        if(-not [Diagnostics.EventLog]::SourceExists($EventSource)) {
          [Diagnostics.EventLog]::CreateEventSource($EventSource, $EventLogName)
        }

        switch ($type) {
          'Error' {$EntryType = 'Error'}
          'Warn'  {$EntryType = 'Warning'}
          'Info'  {$EntryType = 'Information'}
          'Verbose' {$EntryType = 'Information'}
          'Divider'  {$EntryType = 'Information'}
        }
        if ($type -ne 'Divider'){
          Write-EventLog -LogName $EventLogName -Source $EventSource -EventId 1 -EntryType $EntryType -Message $Message
        }
      }
      $msg = ''
    } # end try
    catch {
      Throw "Failed to create log entry in: '$LogPath'. The error was: `'$($_.Exception.Message)`'."
    } # end catch
  } # end PROCESS
  END{} # end END
} # end function Write-Log
#endregion Functions

#region GetInfoFromRegistry
# This is data written to the $RunOnceRoot registry key to control how the script starts after a reboot.
if ($GetInfoFromRegistry){
  $SQLPath = $(Get-ItemProperty -Path $RunOnceRoot -Name SQLPath -ErrorAction SilentlyContinue).SQLPath
  $TargetFolder = $(Get-ItemProperty -Path $RunOnceRoot -Name TargetFolder -ErrorAction SilentlyContinue).TargetFolder
  $WindowsSource = $(Get-ItemProperty -Path $RunOnceRoot -Name WindowsSource -ErrorAction SilentlyContinue).WindowsSource
  
  #IncludeTelnet
  $IncludeTelnet = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeTelnet -ErrorAction SilentlyContinue).IncludeTelnet -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeTelnet -ErrorAction SilentlyContinue
  
  #IncludeSSMS
  $IncludeSSMS = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeSSMS -ErrorAction SilentlyContinue).IncludeSSMS -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeSSMS -ErrorAction SilentlyContinue
  
  #IncludeFW
  $IncludeFW = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeFW -ErrorAction SilentlyContinue).IncludeFW -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeFW -ErrorAction SilentlyContinue

  #IncludeStandard
  $IncludeStandard = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeStandard -ErrorAction SilentlyContinue).IncludeStandard -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeStandard -ErrorAction SilentlyContinue
  
  #IncludeHighPower
  $IncludeHighPower = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeHighPower -ErrorAction SilentlyContinue).IncludeHighPower -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeHighPower -ErrorAction SilentlyContinue

  #IncludeOnlineAdminTools
  $IncludeOnlineAdminTools = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeOnlineAdminTools -ErrorAction SilentlyContinue).IncludeOnlineAdminTools -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeOnlineAdminTools -ErrorAction SilentlyContinue

  #SkipeEdgeNicConfig
  $SkipeEdgeNicConfig = $(Get-ItemProperty -Path $RunOnceRoot -Name SkipeEdgeNicConfig -ErrorAction SilentlyContinue).SkipeEdgeNicConfig -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name SkipeEdgeNicConfig -ErrorAction SilentlyContinue

  #DisableAutoUpdates
  $DisableAutoUpdates = $(Get-ItemProperty -Path $RunOnceRoot -Name DisableAutoUpdates -ErrorAction SilentlyContinue).DisableAutoUpdates -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name DisableAutoUpdates -ErrorAction SilentlyContinue
  
  #DisableWac
  $DisableWac = $(Get-ItemProperty -Path $RunOnceRoot -Name DisableWac -ErrorAction SilentlyContinue).DisableWac -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name DisableWac -ErrorAction SilentlyContinue

  #IncludeLanguagePack
  $IncludeLanguagePack = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeLanguagePack -ErrorAction SilentlyContinue).IncludeLanguagePack -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeLanguagePack -ErrorAction SilentlyContinue

  #DisableFPSharing
  $DisableFPSharing = $(Get-ItemProperty -Path $RunOnceRoot -Name DisableFPSharing -ErrorAction SilentlyContinue).DisableFPSharing -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name DisableFPSharing -ErrorAction SilentlyContinue
  
  #DisableLmHosts
  $DisableLmHosts = $(Get-ItemProperty -Path $RunOnceRoot -Name DisableLmHosts -ErrorAction SilentlyContinue).DisableLmHosts -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name DisableLmHosts -ErrorAction SilentlyContinue
  
  #DisableNetBios
  $DisableNetBios = $(Get-ItemProperty -Path $RunOnceRoot -Name DisableNetBios -ErrorAction SilentlyContinue).DisableNetBios -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name DisableNetBios -ErrorAction SilentlyContinue
  
  #IncludeTrustedCerts
  $IncludeTrustedCerts = $(Get-ItemProperty -Path $RunOnceRoot -Name IncludeTrustedCerts -ErrorAction SilentlyContinue).IncludeTrustedCerts -eq 1
  Remove-ItemProperty -Path $RunOnceRoot -Name IncludeTrustedCerts -ErrorAction SilentlyContinue

  $SkipCoreCheck = $true
  $SkipUpdateCheck = $true
  if ($SQLPath -and $TargetFolder -and $WindowsSource){
    Remove-ItemProperty -Path $RunOnceRoot -Name SQLPath -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $RunOnceRoot -Name TargetFolder -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $RunOnceRoot -Name $WindowsSource -ErrorAction SilentlyContinue
  }
}
# need error checking here.
#endregion GetInfoFromRegistry

#region Variables
# this has to be defined here in order for the tail function to work (as opposed to defining it in the write-log function)
[string] $LogPath = "$TargetFolder\logs\$env:ComputerName" + ' {0:yyyy-MM-dd hh-mmtt}.log' -f (Get-Date)
Write-Log -Type Info -Message "v$ScriptVersion script start" -EventLogName Application -EventId 1 -NoConsole
[bool] $FipsEnabled = (Get-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy' -Name Enabled).Enabled

if (-Not($DownloadOnly) -and (-Not($DownloadAll))){
  Write-Log -Type Info -Message 'Checking domain membership' -NoLog
  [bool] $IsDomainMember = (Get-CimInstance -ClassName 'Win32_ComputerSystem').PartOfDomain
}

[string] $UninstallKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
[string] $ScriptPathAndName = $MyInvocation.MyCommand.Definition
[int] $NumberOfNics = (Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -ErrorAction Stop -Verbose:$false | Where-Object {$_.IPEnabled} | Measure-Object).count

if ($WindowsSource -match '.iso$'){
  $WindowsSourceIso = $WindowsSource
  Mount-DiskImage -ImagePath $WindowsSource
  $WindowsSource = (Get-DiskImage -ImagePath $WindowsSource | Get-Volume).DriveLetter + ':'
}
$WindowsSource = $WindowsSource -replace ('\\$')
if (Test-Path -Path $WindowsSource){
  [bool] $ValidWinSource = $true
} else {
  [bool] $ValidWinSource = $false
}

if (-Not($DownloadOnly) -and (-Not($DownloadAll))){
  Write-Log -Type Info -Message 'Getting OS info' -NoLog
  $OSVersion = Get-CimInstance -ClassName 'Win32_OperatingSystem'
  $OSName = $(Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion' -Name ProductName).ProductName
}

# $VirtualizationInfo = Get-VirtualizationInfo
if ((-Not ($DownloadOnly)) -and (-Not ($DownloadAll))){
  $VirtualizationInfo = Get-VirtualizationInfo
  Write-Log -Type Info -Message 'Getting Visual C++ config' -NoLog
  #Visual C++ 2012
  [string] $VC12PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\11.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version
  #Visual C++ 2013
  [string] $VC13PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\12.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version
  #Visual C++ 2014
  # fixed from typo 2017-12-11
  #[string] $VC14PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version
  [string] $VC14PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\13.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version
  #Visual C++ 2015
  [string] $VC15PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version

  # TODO: Need path for Visual C++ 2017, as it appears to conflict with above.
  #Visual C++ 2017
  [string] $VC17PlusPlus = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum' -Name Version -ErrorAction SilentlyContinue).Version

  [bool] $IsSrv2016 = $OSName -match 'Windows Server 2016'
}

[bool] $IsPi = $(Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion' -Name InstallationType).InstallationType -match 'IoTUAP'
[bool] $IsSrv2012R2 = $OSName -imatch 'Windows Server 2012 R2'
[bool] $IsSrv2012 = $OSVersion.Version -match '^6.2.920'
[bool] $IsSrv2008R2 = $OSName -imatch 'Windows Server 2008 R2'

# This really needs to be better
# Russian seems to be: 'Майкрософт Windows Server 2019 Standard'
# [bool] $IsSrv2019 = $OSVersion.Caption -imatch '^Microsoft Windows Server 2019'
[bool] $IsSrv2019 = $OSVersion.Caption -imatch 'Windows Server 2019' # submitted via feedback. Seems to work ok.

[bool] $IsSrvCore = ($IsSrv2016 -or $IsSrv2019) -and $(Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion' -Name InstallationType).InstallationType -match 'Server Core'

#info on status: https://stackoverflow.com/questions/33649043/powershell-how-to-get-antivirus-product-details
[string] $AvSolution = (Get-CimInstance -ClassName 'AntiVirusProduct' -Namespace 'root/SecurityCenter2' -ErrorAction SilentlyContinue).DisplayName
if ($IsSrv2016 -or $IsSrv2019){
  try {
    $ProtectionInfo = Get-CimInstance -Namespace 'root\microsoft\securityclient' -ClassName 'protectionTechnologyStatus' -ErrorAction Stop
  }
  catch{
    Write-Log -Type Error -Message "Failed retieving protectionTechnologyStatus config with `'$($_.Exception.Message)`'"
  }
  if ($ProtectionInfo.Name -eq 'Antimalware') {
    $AvSolution = 'Windows Defender'
  }
  if (-Not($ProtectionInfo)){
    $AvSolution = 'None detected'
  }
}
[string] $LastBootTime = (Get-WinEvent -FilterHashtable @{LogName = 'system'; ID = 27} -MaxEvents 1).TimeCreated
[bool] $IsSSL3Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
[bool] $IsSSL2Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
[bool] $IsRc4Enabled = ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0) -or ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0) -or ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0)

[string] $PowerShellVersion = [string] $($PSVersionTable.PSVersion.Major) + '.' + [string] $($PSVersionTable.PSVersion.Minor)
[int] $LmCompatibilityLevel = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\' -Name LmCompatibilityLevel -ErrorAction SilentlyContinue).LmCompatibilityLevel
[string] $PowerLevel = $(Get-CimInstance -ClassName 'Win32_PowerPlan' -Namespace 'root\cimv2\power' -Filter "IsActive='$true'" -Verbose:$false).ElementName
[string] $RebootWarning = @'
┌──────────────────────────────────────────────────────────┐
│            REBOOT REQUIRED BEFORE CONTINUING             │
│            ---------------------------------             │
│    A previous installation requires a reboot before      │
│    continuing. Please reboot this server and then run    │
│    the script again.                                     │
│                                                          │
│    Hint: Use 'Restart-Computer' in PowerShell            │
└──────────────────────────────────────────────────────────┘
'@

[string] $OSMismatchWarning = @'
┌──────────────────────────────────────────────────────────┐
│            INVALID OPERATING SYSTEM DETECTED             │
│            ---------------------------------             │
│    This script cannot be run on this operating system.   │
│    It is designed for Skype for Business 2015 on         │
│    Windows Server 2012, Server 2012 R2, and Windows      │
│    Server 2016 only.                                     │
│                                                          │
│    Only Skype for Business 2019 is supported on          │
│    Windows Server 2019.                                  │
└──────────────────────────────────────────────────────────┘
'@

[string] $OSMismatchWarning2016 = @'
┌──────────────────────────────────────────────────────────┐
│            INVALID OPERATING SYSTEM DETECTED             │
│            ---------------------------------             │
│    Skype for Business Server 2019 cannot run on this     │
│    operating system. It is designed for Microsoft        │
│    Windows Server 2016 and Windows Server 2019 only.     │
└──────────────────────────────────────────────────────────┘
'@

# This has been replaced by the pop-up, and can probably be removed.
[string] $PrereqRebootWarning = @"
┌──────────────────────────────────────────────────────────┐
│            REBOOT REQUIRED BEFORE CONTINUING             │
│            ---------------------------------             │
│    A reboot is required before the remaining components  │
│    can be installed. Please reboot the server, run the   │
│    script again, and choose the same option.             │
│                                                          │
│    Hint: Use 'Restart-Computer' in PowerShell            │
└──────────────────────────────────────────────────────────┘
"@

[string] $Win2012SourceWarningshort = "│    $WindowsSource\sources\sxs does not exist."
do {$Win2012SourceWarningshort += ' '} while ($Win2012SourceWarningshort.length -le 58)
$Win2012SourceWarningshort += '│'

[string] $Win2012SourceWarning = @'
┌──────────────────────────────────────────────────────────┐
│          WINDOWS SERVER SOURCE FILES NOT FOUND           │
│          -------------------------------------           │
'@
$Win2012SourceWarning += @"

$Win2012SourceWarningshort
│    Run the script again, specifying -WindowsSource       │
│    and a valid root path.                                │
└──────────────────────────────────────────────────────────┘
"@

[string] $Win2012CoreWarning = @'
┌──────────────────────────────────────────────────────────┐
│            WINDOWS Server Core Not Supported             │
│            ---------------------------------             │
│    This server has been detected as Server Core,         │
│    and not the required GUI. Skype for Business          │
│    Server cannot be installed on this server.            │
└──────────────────────────────────────────────────────────┘
'@

[string] $VisualCMissingError = @"
┌──────────────────────────────────────────────────────────┐
│        Visual C++ 2012 Runtime Not Installed             │
│        -------------------------------------             │
│     `"Microsoft Visual C++ 2012 x64 Minimum Runtime -    │
│    11.0.50727`" not installed. This is common if Lync    │
│    Server 2013 is not yet installed. Please install Lync │
│    Server and try this options again.                    │
└──────────────────────────────────────────────────────────┘
"@

[string] $VisualC2013MissingError = @"
┌──────────────────────────────────────────────────────────┐
│        Visual C++ 2013 Runtime Not Installed             │
│        -------------------------------------             │
│    `"Microsoft Visual C++ 2013 x64 Minimum Runtime -      │
│    12.0.21005`" (or later) not installed. This is         │
│    common if Skype for Business Server 2015 is not       │
│    yet installed. Please install Skype for Business      │
│    Server 2015 and try this option again.                │
└──────────────────────────────────────────────────────────┘
"@

[string] $DotNetWarning = @'
┌──────────────────────────────────────────────────────────┐
│             Unsupported .Net Installation                │
│             -----------------------------                │
│    This server has detected an unsupported               │
│    version of the .Net framework. Please remove          │
│    it and install a supported version. For info          │
│    from Microsoft on the issue, please see               │
│    see http://bit.ly/1Pvgp90. For info on removing       │
│    an unsupported version of .NET Framework, see         │
│    http://bit.ly/2f6LDcX                                 │
└──────────────────────────────────────────────────────────┘
'@

[string] $NanoWarning = @'
┌──────────────────────────────────────────────────────────┐
│                Nano Server Not Supported                 │
│                -------------------------                 │
│    Sorry, Sport, but Nano Server is not supported for    │
│    Lync Server or Skype for Business Server. Come        │
│    back with a real Operating System. Script will        │
│    now exit.                                             │
└──────────────────────────────────────────────────────────┘
'@

[string] $BugReportShort = "│    $LogPath"
do {$BugReportShort += ' '} while ($BugReportShort.length -le 58)
$BugReportShort += '│'

[string] $BugReport = @"
┌──────────────────────────────────────────────────────────┐
│           How To Report a Bug For This Script            │
│           -----------------------------------            │
│    Sorry that you've experienced a problem. I take       │
│    great care in trying to write trouble free code.      │
│    Please send an email to the address in the header,    │
│    and PLEASE include the log file. The log file for     │
│    for this script can be found at                       │
"@
$BugReport += @"

$BugReportShort
└──────────────────────────────────────────────────────────┘
"@

# http://www.expta.com/2016/02/how-to-uninstall-net-framework-461.html

[string] $PrereqRebootPromptWarning = 'A reboot is required before the remaining components can be installed. Please reboot the server, the script will automatically run again and complete the remaining tasks for this option. Reboot now?'

[object] $ComputerInfo = Get-CimInstance -ClassName 'Win32_ComputerSystem'
if ($ComputerInfo.Model -eq 'Virtual Machine'){
  <#
      $KeyName = 'SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters'
      $ValueName = 'PhysicalHostName'
      $BaseKeyObj = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $env:ComputerName)
      $KeyObj = $BaseKeyObj.OpenSubKey($KeyName)
      $VirtualHost = $KeyObj.GetValue($ValueName)
      Write-Log -Type Info -Message "Virtual         : True (Host: $VirtualHost)" -NoConsole
  #>
  $VmHost = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters' -Name HostName).HostName
}else{ 
    $VmHost = $false
}

[int16] $ram = ($ComputerInfo | Select-Object -Property @{Name='TotalPhysicalMemory';Expression={($_.TotalPhysicalMemory/1gb).ToString('N0')}}).TotalPhysicalMemory


# .NET detection
[int] $DotNetVersion = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\NET Framework Setup\NDP\v4\Full\' -Name Release).Release

$DotNetVersionHashtable = @{
  378389 = '4.5';
  378675 = '4.5.1'; # Win 8
  378758 = '4.5.1';
  379893 = '4.5.2';
  393295 = '4.6'; # Win 10
  393297 = '4.6';
  394254 = '4.6.1';
  394271 = '4.6.1';
  394802 = '4.6.2'; # Win 10
  394806 = '4.6.2';
  460798 = '4.7'; # Win 10
  460805 = '4.7';
  461308 = '4.7.1'; # Win 10
  461310 = '4.7.1';
  461808 = '4.7.2'; # Win 10
  461814 = '4.7.2'; # Also default on WS2019
}
[string] $InstalledDotNetVersion = $DotNetVersionHashtable.Get_Item($DotNetVersion)

# following adjusted to support prelim work on WS2019
# TODO: need better tracking of the latest version number
if ($InstalledDotNetVersion -gt '4.7.2' -and (-Not $IsSrv2019) -and (-Not($DownloadOnly)) -and (-Not($DownloadAll))){
  Write-Log -Type Error -Message 'This version of .Net Framework is not supported. You must remove it and install a supported version.' -NoConsole
  Write-Log -Type Error -Message $DotNetWarning -NoLog
  Stop-Script
}
if ((Get-Service -Name 'mpssvc').Status -eq 'Running') {
  try {[bool] $DomainFW = $(Get-NetFirewallProfile -Name Domain).Enabled}
  catch{
    Write-Log -Type Error -Message "Failed retrieving domain firewall config with `'$($_.Exception.Message)`'"
  }
  try {[bool] $PublicFW = $(Get-NetFirewallProfile -Name Public).Enabled}
  catch{
    Write-Log -Type Error -Message "Failed retrieving public firewall config with `'$($_.Exception.Message)`'"
  }
  try {[bool] $PrivateFW = $(Get-NetFirewallProfile -Name Private).Enabled}
  catch{
    Write-Log -Type Error -Message "Failed retrieving private firewall config with `'$($_.Exception.Message)`'"
  }
} else {
  [string] $DomainFW = 'Firewall service not running'
  [string] $PublicFW = 'Firewall service not running'
  [string] $PrivateFW = 'Firewall service not running'
}
[bool] $RecommendedUpdates = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\7971f918-a847-4430-9279-4a52d1efe18d' -Name RegisteredWithAu -ErrorAction SilentlyContinue).RegisteredWithAu -eq 1

[string] $DownloadOnlyWarning = 'DOWNLOAD ONLY option selected. No configuration will be performed.'
#endregion Variables

#region RunningStatus
if ($ClearRunningStatus){
  Write-Log -Type Warn -Message "ClearRunningStatus switch specified. Script will set registry value to 'stopped' value and then exit. Run the script as normal after that."
  Stop-Script
}

Get-RunningStatus
Set-RunningStatus -Running
#endregion RunningStatus

#region ScriptMode - Figure out what mode the script needs to run in.
if (-Not $Skype4b -and (-Not $skype4b2019) -and (-Not $GetInfoFromRegistry)){
  Write-Log -Type Warn -Message 'No mode specified - prompting user.' -NoConsole
  $title = 'Please choose a version'
  $VersionMessage = 'What version are you installing? This is critical to ensure the proper features and components are installed.'

  $yes = New-Object -TypeName System.Management.Automation.Host.ChoiceDescription -ArgumentList '&Lync 2013', 'Lync Server 2013'
  $no = New-Object -TypeName System.Management.Automation.Host.ChoiceDescription -ArgumentList '&Skype4b 2015', 'Skype for Business Server 2015'
  $maybe = New-Object -TypeName System.Management.Automation.Host.ChoiceDescription -ArgumentList 'S&kype4b 2019', 'Skype for Business Server 2019'

  $options = [Management.Automation.Host.ChoiceDescription[]]($yes, $no, $maybe)

  $result = $host.ui.PromptForChoice($title, $VersionMessage, $options, 1) 
  switch ($result) {
    0 {
      Write-Log -Type Info -Message "v$Version script started in `"Lync Server 2013`" mode by $env:UserDomain\$env:UserName" -EventLogName Application -EventId 1 -NoConsole -NoLog
    }
    1 {
      Write-Log -Type Info -Message "v$Version script started in `"Skype for Business Server 2015`" mode by $env:UserDomain\$env:UserName" -EventLogName Application -EventId 1 -NoConsole -NoLog
      [bool] $Skype4b = $true
    }
    2 {
      Write-Log -Type Info -Message "v$Version script started in `"Skype for Business Server 2019`" mode by $env:UserDomain\$env:UserName" -EventLogName Application -EventId 1 -NoConsole -NoLog
      [bool] $Skype4b2019 = $true
    }
  }  
}
[bool] $Lync2013 = (-Not($Skype4b) -and (-Not($Skype4b2019)))
#endregion ScriptMode

#region Tail - this is a Linux type tail function that lets you watch the log file while the script runs
try{
  if ($Tail){
    $PowerShellID = (Get-Process -Name PowerShell).id
    $exeFile = "$PSHOME\powershell.exe"
    $command = @"
    Start-Process -FilePath "$exeFile" -ArgumentList '-NoProfile -NoLogo -Command "& {Get-Content -Path ''$LogPath'' -Wait}"'
"@
    Invoke-Expression -Command $command
    if ($PowerShellId.count -eq 1){
      [int] $PowerShellTailId = (Get-Process -Name PowerShell | Where-Object {$_.id -ne $PowerShellID}).id
    }else{
      Write-Log -Type Warn -Message "Unable to determine PowerShellTailId because there are $($PowerShellID.count) sessions open" -NoConsole -Indent 1
      Write-Log -Type Warn -Message 'This is not serious, but the script will not be able to automatically close the tail window when it exits.' -NoConsole -Indent 1
    }
  }
}
catch{
  Write-Log -Type Error -Message $_
}

#endregion tail

#region DownloadURLsInstalledGUIDs - all of the URLs for the various files, and the GUID to query to see if it's installed
# Adoption portal
if ($skype4b){
  [uri] $URLAdoptionPortal = 'http://download.microsoft.com/download/0/5/F/05F806A2-1399-42FC-B8CD-7D17E6136F25/SkypeforBusinessAdoptionPortal.zip'
}

# ASP.net MVC - For Lync Room System
if ($lync2013){
  [uri] $URLaspnetmvc4 = 'http://download.microsoft.com/download/2/F/6/2F63CCD8-9288-4CC8-B58C-81D109F8F5A3/AspNetMVC4Setup.exe'
}
# Bandwidth Calculator 2.70 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=19011
[uri] $URLBandwidthCalulator = 'https://download.microsoft.com/download/9/8/6/98607EA5-63DD-448B-83ED-6EBCFF0AEA9A/Skype%20for%20Business%20BW%20Calc%20-%20Version%202%2070.xlsm'
[uri] $URLBandwidthCalulatorReleaseNotes = 'https://download.microsoft.com/download/9/8/6/98607EA5-63DD-448B-83ED-6EBCFF0AEA9A/Skype%20for%20Business%20BW%20Calc%20-%20Version%202%2070%20-%20RELEASE%20NOTE.txt'
[uri] $URLBandwidthCalulatorUserGuide = 'https://download.microsoft.com/download/9/8/6/98607EA5-63DD-448B-83ED-6EBCFF0AEA9A/Skype_for_Business_BW_Calc_Version_2.70_User%20Guide.pdf'

# Basic client
if ($skype4b2019){
  # waiting for valid URL
}
if ($Skype4b){
  # SfB 2015 Basic client v16.0.4417.1000 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=49440
  [uri] $URLBasicClient64 = 'https://download.microsoft.com/download/8/7/E/87E24B50-9C85-4B1D-A581-94AA037803F8/lyncentry_4417-1000_x64_en-us.exe'
  [uri] $URLBasicClient32 = 'https://download.microsoft.com/download/8/7/E/87E24B50-9C85-4B1D-A581-94AA037803F8/lyncentry_4417-1000_x86_en-us.exe'
}
if ($lync2013){
  # Lync Basic client v15.0.4420.1017 (Verified 09/18/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=35451
  [uri] $URLBasicClient64 = 'https://download.microsoft.com/download/4/5/3/45367500-0EEB-458F-9BD5-F43778C9F841/lyncentry.exe'
  [uri] $URLBasicClient32 = 'https://download.microsoft.com/download/F/E/3/FE380515-C80B-4B2E-A3C6-61A4E1781374/lyncentry.exe'
}

# Best practices analyzer 8308.0 (Verified 09/17/2018)
if ($lync2013){
  # https://www.microsoft.com/en-us/download/details.aspx?id=35455
  [uri] $URLbpa = 'http://download.microsoft.com/download/2/E/4/2E4CF74C-B323-4912-9ADD-C684E6346A6F/rtcbpa.msi'
  [string] $GUID2013bpa = '{597568A4-CECE-4179-99DA-C8D27382C2DB}'
}

# Call Quality Dashboard 2046.19 (Verified 11/12/2018)
if ($skype4b2019){ 
  # https://www.microsoft.com/en-in/download/details.aspx?id=57510
  [uri] $URLcqd = 'https://download.microsoft.com/download/0/9/8/0984354A-C40B-4900-9904-1777DDB5E80C/CallQualityDashboard.msi'
}
# Call Quality Dashboard 9319.28 (Verified 09/17/2018)
if ($skype4b){
  # https://www.microsoft.com/en-us/download/details.aspx?id=46916 
  [uri] $URLcqd = 'https://download.microsoft.com/download/1/B/1/1B161A2C-12B0-4CF6-B5C7-805D53C21714/CallQualityDashboard.msi'
}

# Cloud Center Edition 2.1.0 (Verified 09/17/2018)
if ($Skype4B){
  # https://www.microsoft.com/en-us/download/details.aspx?id=52963 
  [uri] $URLCce = 'https://download.microsoft.com/download/E/D/7/ED79E40E-E0AC-490D-8667-7C68546FD810/CloudConnector.msi'
}

# Connectivity Analyzer 8308.582 - no longer updated (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=36535
  [uri] $URLconnectivityanalyzer = "https://ucunleashed.com/downloads/$article/LyncConnectivityAnalyzer.msi"
  [string] $GUID2013connectivityanalyzer = '{B942730E-C0EF-48E7-8E93-CA05ADFFD026}'

# Cumulative update (latest)
if ($skype4b2019){
  # https://www.microsoft.com/en-us/download/details.aspx?id=58347 (verified 06/13/2019)
  [uri] $URLlatestcu = 'https://download.microsoft.com/download/5/E/F/5EFD61E4-1BCB-46DF-A02E-B8A9AD79EDAE/SkypeServerUpdateInstaller.exe'
}
if ($Skype4B){ 
  # https://www.microsoft.com/en-us/download/details.aspx?id=47690 (Verified 09/17/2018)
  [uri] $URLlatestcu = 'https://download.microsoft.com/download/F/B/C/FBC09794-2DB9-415E-BBC7-7202E8DF7072/SkypeServerUpdateInstaller.exe'    
}
if ($lync2013){ 
  # https://www.microsoft.com/en-us/download/details.aspx?id=36820 (Verified 09/17/2018)
    [uri] $URLlatestcu = 'http://download.microsoft.com/download/B/E/4/BE44AC91-C665-4522-BA93-CE72B0934DAF/LyncServerUpdateInstaller.exe'
}

# Debugging tools
if ($skype4b2019){
  [uri] $URLdebuggingtools = 'https://download.microsoft.com/download/D/8/3/D83648F4-56A9-4094-A1B4-F67196499416/SkypeForBusinessDebugTools.msi'
  [string] $GUIDdebuggingtools = '{28AD6D73-F01E-404F-B5B0-92437B7D3BE6}'
}
if ($Skype4B){ # v6.0 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/confirmation.aspx?id=47263 
  [uri] $URLdebuggingtools = 'https://download.microsoft.com/download/A/6/0/A603FC51-2C03-48B2-A072-587FA1D3DFAF/SkypeForBusinessDebugTools.msi'
  [string] $GUIDdebuggingtools = '{28AD6D73-F01E-404F-B5B0-92437B7D3BE6}'
}
if ($lync2013){ # v8308.577 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=35453
  [uri] $URLdebuggingtools = 'http://download.microsoft.com/download/C/4/6/C465D12C-60A2-47EC-B1AD-02046941B653/LyncDebugTools.msi'
  [string] $GUIDdebuggingtools = '{5043B30E-AD39-4251-8807-A2B8184E48B7}'
}

# Digicert® certificate utility (Verified 09/17/2018)
[uri] $URLDigicertUtil = 'https://www.digicert.com/util/DigiCertUtil.zip'

# Disable RC4 patch
if (-Not($IsSrv2016) -and (-Not($IsSrv2019))){
  [uri] $URLdisablerc4patch = 'https://download.microsoft.com/download/5/2/0/52068EE3-2CF1-486F-B52F-751001484555/Windows8-RT-KB2868725-x64.msu'
}

# Help chm file August2015 (Verified 09/17/2018)
if ($lync2013){
  # https://www.microsoft.com/en-us/download/details.aspx?id=35405
  [uri] $URLchm = 'http://download.microsoft.com/download/F/5/9/F59AECFE-007B-4B16-A2E2-47AD2252EC54/LyncServer2013_ITPro.exe'
}

# Microsoft.IdentityModel.Extention.dll v2.0.1224.0 - for OOS
# https://greiginsydney.com/microsoft-updates-wac-oos-pre-reqs/
# https://docs.microsoft.com/en-us/officeonlineserver/deploy-office-online-server
[uri] $URLIdentityModel = 'http://download.microsoft.com/download/0/1/D/01D06854-CA0C-46F1-ADBA-EBF86010DCC6/MicrosoftIdentityExtensions-64.msi'
[string] $GUIDIdentityModel = '{F99F24BF-0B90-463E-9658-3FD2EFC3C991}'

# IIS Crypto 2 build 11 (Verified 09/17/2018)
[uri] $URLiiscrypto = 'https://www.nartac.com/Downloads/IISCrypto/IISCrypto.exe'

# Key Health Indicators for Lync Server 2013 and Skype for Business Server 2015/2019 2046.22 (Verified 11/14/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=57519
[uri] $URLkhi = 'https://download.microsoft.com/download/0/4/4/04411363-B7BB-401C-B97A-1E7E0B194E0E/KHI_Resources.zip'

# LRS Admin Portal 8308.846 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=40329
if ($lync2013){
  [uri] $URLlrsadminportal = 'http://download.microsoft.com/download/8/7/8/878DA290-F608-4297-B1C7-4A5FC8245EA3/LyncRoomAdminPortal.exe'
}

# .Net Framework
if ($skype4b2019 -or $skype4b){ # .NET 4.7.2
  [uri] $URLdotnet = 'https://download.microsoft.com/download/6/E/4/6E48E8AB-DC00-419E-9704-06DD46E5F81D/NDP472-KB4054530-x86-x64-AllOS-ENU.exe'
}
if ($lync2013){ # .NET 4.5.2
  [uri] $URLdotnet = 'http://download.microsoft.com/download/E/2/1/E21644B5-2DF2-47C2-91BD-63C560427900/NDP452-KB2901907-x86-x64-AllOS-ENU.exe'
}

# Meeting Migration Tool 8308.986 (both 32 and 64 bit versions) (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=51659
[uri] $URLMeetingMigrationTool32 = 'https://download.microsoft.com/download/5/6/B/56B72282-D252-407C-88AA-2E95D12A0509/SkypeforBusinessMeetingUpdate.msi'
[uri] $URLMeetingMigrationTool64 = 'https://download.microsoft.com/download/9/B/9/9B9ECCF2-2AE3-4CF8-B15B-0D9A1C0B76F1/SkypeforBusinessMeetingUpdate.msi'

# Message Analyzer 1.4 64bit build 4.0.8112.0 (Verfied 09/17/2018)
[uri] $URLmessageanalyzer = 'https://download.microsoft.com/download/2/8/3/283DE38A-5164-49DB-9883-9D1CC432174D/MessageAnalyzer64.msi'
[string] $GUIDMessageAnalyzer = '{93AA1795-974B-4F77-A498-D070EE66A764}'
[uri] $URLmessageanalyzerknownissuesdoc = 'https://download.microsoft.com/download/2/8/3/283DE38A-5164-49DB-9883-9D1CC432174D/Microsoft%20Message%20Analyzer%20v1.4%20Known%20Issues.docx'

# Skype for Business Network Assessment Tool 1.2.0.0 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=53885
[uri] $URLNetworkAssessmentTool = 'https://download.microsoft.com/download/D/D/6/DD65CA90-94CF-4B10-88A2-67432D8EB78F/MicrosoftSkypeForBusinessNetworkAssessmentTool.exe'
[string] $GUIDNetworkAssessmentTool = '{354AE709-9D05-4835-9EE2-11390E7C9F6E}'

# Office Online Server (Verified 09/17/2018)
  [uri] $URLwacimage = 'http://download.microsoft.com/download/7/7/F/77F250DC-F7A3-47AF-8B20-DDA8EE110AB4/en_office_online_server_last_updated_november_2017_x64_dvd_100181876.iso'
  [string] $GUIDwacimage = '{90160000-1151-0000-1000-0000000FF1CE}'

  # TESTING 16.0.10338.20039 (Verified 12/23/2018)
  [uri] $URLwacimage = 'http://download.microsoft.com/download/7/7/F/77F250DC-F7A3-47AF-8B20-DDA8EE110AB4/en_office_online_server_last_updated_november_2018_x64_dvd_1b5ae10d.iso'
  [string] $GUIDwacimage = '{90160000-1151-0000-1000-0000000FF1CE}'

# Office Online Server English Pack - 11/2017 - 16.0.8431.1018 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=51963
[string] $GUIDwacenglishlanguagepack = '{90160000-1157-0409-1000-0000000FF1CE}'
[uri] $URLwacenglishlanguagepack = 'https://download.microsoft.com/download/6/D/7/6D75C9CB-FFEE-48B0-9AA6-D03C74E3939E/wacserverlanguagepack.exe'

# TESTING 16.0.10338.20039 (Verified 12/23/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=51963
[uri] $URLwacenglishlanguagepack = 'https://download.microsoft.com/download/6/D/7/6D75C9CB-FFEE-48B0-9AA6-D03C74E3939E/wacserverlanguagepack.exe'
[string] $GUIDwacenglishlanguagepack = '{90160000-1153-0409-1000-0000000FF1CE}'


# Office Online Server: May 2018 - Update for Microsoft Office Online Server (KB4011025) (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=56929 
# https://support.microsoft.com/en-us/help/4011025/may-8-2018-update-for-office-online-server-kb4011025
# Disabling since this is older than current full OOS build.
#[uri] $URLwacCU = 'https://download.microsoft.com/download/6/B/D/6BD1D664-1212-4AB2-9BE8-447731F2CA0E/wacserver2016-kb4011025-fullfile-x64-glb.exe'
#[string] $GUIDwacCU = '{90160000-1151-0000-1000-0000000FF1CE}_Office16.WacServer_{5689B45F-30F5-4A0A-8F7D-DD1C815C7848}'

# OS hotfixes
if ($skype4b -or $skype4b2019){ 
  if ($IsSrv2012R2){
    # $URLhotfix = 'http://hotfixv4.microsoft.com/Windows 8.1/Windows Server 2012 R2/sp1/Fix514814/9600/free/478232_intl_x64_zip.exe'
    # $GUIDhotfix = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\Package_1_for_KB2982006~31bf3856ad364e35~amd64~~6.3.1.0'
    
    # https://www.microsoft.com/en-us/download/details.aspx?id=45141
    $URLhotfix = 'https://download.microsoft.com/download/D/6/1/D6129EA3-CA55-47C8-9276-1F482A4C3CB3/Windows8.1-KB3013769-x64.msu'
  }elseif ($IsSrv2012){
    $URLhotfix = 'http://hotfixv4.microsoft.com/Windows 8/Windows Server 2012 RTM/nosp/Fix518527/9200/free/477495_intl_x64_zip.exe'
    $GUIDhotfix = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\Package_1_for_KB2858668~31bf3856ad364e35~amd64~~6.2.3.0'
  }
}

# PChat resource kit 8308.420 (Verified 09/17/2018)
if ($lync2013){
  # https://www.microsoft.com/en-us/download/details.aspx?id=36827
  [uri] $URLpchatresourcekit = 'http://download.microsoft.com/download/8/1/1/81154753-E849-46C9-A4D3-47E11838109C/PersistentChatResKit.msi'
  [string] $GUID2013pchatresourcekit = '{BBC8C4B9-D90B-4277-A9F9-3A7A2421548C}'
}

# Portqry and custom config file
# Portqry 2.0 
# TODO: Check if we need to also download this
# https://www.microsoft.com/en-us/download/details.aspx?id=17148
# https://download.microsoft.com/download/0/d/9/0d9d81cf-4ef2-4aa5-8cea-95a935ee09c9/PortQryV2.exe

# Portqryui 1.0 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=24009
[uri] $URLportqry = 'http://download.microsoft.com/download/3/f/4/3f4c6a54-65f0-4164-bdec-a3411ba24d3a/PortQryUI.exe'
if ($skype4b -or $skype4b2019){ 
  [uri] $URLportqryconfig = "https://ucunleashed.com/downloads/$Article/Skype Portquery config.zip"
}else{
  [uri] $URLportqryconfig = "https://ucunleashed.com/downloads/$Article/Lync Portquery config.zip"
}

# Post Move Cleanup Tool (Verified 09/17/2018)
# https://support.microsoft.com/en-us/help/3070789/clean-up-user-data-after-a-user-move-by-using-the-skype-for-business-s
[uri] $URLSkypePostMoveCleanupTool = 'https://download.microsoft.com/download/C/8/6/C869BF97-E3A6-46BD-A722-68CD7E1D9EB6/PostMoveCleanup.exe'

# PowerShell 4
  [uri] $URLpowershell4releasenotes = 'https://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20Management%20Framework%204%200%20Release%20Notes.docx'
  [uri] $URLpowershell4dscquickpdf = 'http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20PowerShell%20Desired%20State%20Configuration%20Quick%20Reference%20for%20Windows%20Management%20Framework%204.0.pdf'
  [uri] $URLpowershell4dscquickpptx = 'http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows%20PowerShell%20Desired%20State%20Configuration%20Quick%20Reference%20for%20Windows%20Management%20Framework%204.0.pptx'
  [uri] $URLpowershell4 = 'http://download.microsoft.com/download/3/D/6/3D61D262-8549-4769-A660-230B67E15B25/Windows8-RT-KB2799888-x64.msu'

# RASK (Rollout and Adoption Success Kit) 1.0 (Updated 09/17/2018)
if ($lync2013){
  # https://www.microsoft.com/en-us/download/details.aspx?id=37032
  [uri] $URLraskusereducation = 'http://download.microsoft.com/download/3/7/1/3717BF87-D7BD-4381-A22C-7908A3CF2270/RASK_Training_Resources.zip'
  # https://www.microsoft.com/en-us/download/details.aspx?id=42067
  # [uri] $URLraskcoreplanning = 'http://download.microsoft.com/download/5/9/4/59410DF8-0FFA-40C9-ADBD-1E27959DFD8E/RASK_Core_Planning_Resources.zip'
  [uri] $URLraskcoreplanning = 'https://download.microsoft.com/download/C/7/8/C78C7A83-28AE-45C5-B6AD-3DAEFDCD4B46/RASK_Core_Planning_Resources.zip'
}

# Resource kit
if ($Skype4b2019){
  # waiting for valid URL
}
if ($Skype4B){ # 9319.263 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=52631
  [uri] $URLresourcekit = 'https://download.microsoft.com/download/4/6/9/469BFE52-9F8B-4398-8998-D3460619D2B2/OCSReskit.msi'
  [string] $GUID2013resourcekit = '{AB30E3C1-9100-418D-9848-9A2891DCEAC5}'
}
if ($lync2013){ # 8308.577 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=36821
  [uri] $URLresourcekit = 'http://download.microsoft.com/download/C/6/0/C60A878E-22AD-4C88-A4A1-F01BD71BA8BA/OCSReskit.msi'
  [string] $GUID2013resourcekit = '{72C84263-9F4D-4475-937E-1AEA029FE256}'
}

# SCOM Watcher node
if ($skype4b2019){ # 2046.19 (Verified 11/12/2018) 
  # https://www.microsoft.com/en-in/download/details.aspx?id=57511
  [uri] $URLwatchernode = 'https://download.microsoft.com/download/E/A/2/EA2467CC-0E44-4D14-B214-F9108990656E/WatcherNode.msi'
  [uri] $URLscommgmtpack = 'https://download.microsoft.com/download/E/A/2/EA2467CC-0E44-4D14-B214-F9108990656E/SkypeForBusiness2019ManagementPacks.msi'
  # TODO: Need uninstall GUID
}
if ($skype4b){ # 9319.273 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=47364
  [uri] $URLwatchernode = 'https://download.microsoft.com/download/2/E/F/2EFDDE89-71CB-45B6-A7D2-D6018DB4F285/WatcherNode.msi'
  [uri] $URLscommgmtpack = 'https://download.microsoft.com/download/2/E/F/2EFDDE89-71CB-45B6-A7D2-D6018DB4F285/SkypeForBusiness2015ManagementPacks.msi'
  # TODO: Need uninstall GUID
}
if ($lync2013){ # 8308.956 (Updated 09/17/2018)
  [uri] $URLwatchernode = 'http://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/WatcherNode.msi'
  [uri] $URLscommgmtpack = 'http://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/LS2013ManagementPacks.msi'
  [uri] $URLscommgmtpackdoc = 'https://download.microsoft.com/download/9/A/0/9A06CE65-26AC-47EB-AC78-25A433CE7515/Lync%20Server%202013%20Management%20Pack%20Guide.doc'
  # TODO: Need uninstall GUID 
}

# SDN version 2.4.1 (Verified 09/17/2018)
# https://www.microsoft.com/en-us/download/details.aspx?id=51195
[uri] $URLsdninstallationguide = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/Skype_for_Business_SDN_Interface.pdf'
[uri] $URLsdnschema = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/Skype_for_Business_SDN_Interface.Schema.C.xsd'
[uri] $URLsdnschemad = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/Skype_for_Business_SDN_Interface.Schema.D.xsd'
[uri] $URLsdnchm = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/Skype_for_Business_SDN_Interface_schema.chm'
[uri] $URLsdnreleasenotes = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/Skype_for_Business_SDN_ReleaseNotes.pdf'

# Must be a FE before installing
[uri] $URLsdnlistener = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/SkypeForBusinessDialogListener.msi'
[string] $GUIDsdnlistener = '{640967B9-CD8D-455F-BAB1-463EBFC51C38}'
[uri] $URLsdnmgr = 'https://download.microsoft.com/download/1/1/6/1162D4D6-DEB0-491A-B2D5-D203D09A632E/SkypeForBusinessSDNManager.msi'
[string] $GUIDsndmgr = '{60A580F2-7B7A-4665-9696-07BE5D9AF15F}'

# Silverlight® version 5.1.50907.0 (verified 09/17/2018)
[uri] $URLsilverlight = 'https://download.microsoft.com/download/F/D/0/FD0B0093-DE8A-4C4E-BDC4-F0C56D72018C/50907.00/Silverlight_x64.exe'

# Skype for Business Server 2015 - 180 day eval .iso
[uri] $URLSfBEval = 'https://download.microsoft.com/download/6/6/5/665C9DD5-9E1E-4494-8709-4A3FFC35C6A0/SfB-E-9319.0-enUS.ISO'

# Skype for Business Online, Windows PowerShell Module 7.0.1994.0 (verified 09/17/2018)
if ($Skype4b){
  [uri] $URLSkypeOnlineModule = 'https://download.microsoft.com/download/2/0/5/2050B39B-4DA5-48E0-B768-583533B42C3B/SkypeOnlinePowershell.exe'
    [string] $GUIDSkypeOnlineModule = '{EB403D8D-2861-42BF-A85C-3D7728E94ECC}'
}

# Microsoft Skype Room System Administrative Web Portal for Skype for Business Server 2015 v1525.1 (verified 09/17/2018)
if($skype4b){
  [uri] $URLSkypeRoomSystemAdminPortal = 'https://download.microsoft.com/download/E/4/D/E4DF23FA-08D4-4E8F-A820-16B2C9114EAE/MeetingRoomPortalInstaller.msi'
}

# Sql Server Express
if ($Skype4b2019){
  # Microsoft® SQL Server® 2016 Express Service Pack 1 13.0.4001.0
  # [uri] $URLsqlexpress = 'https://download.microsoft.com/download/9/0/7/907AD35F-9F9C-43A5-9789-52470555DB90/ENU/SQLEXPR_x64_ENU.exe'
  
  # Microsoft® SQL Server® 2016 Express Service Pack 2 13.2.5026.0
  # https://www.microsoft.com/en-us/download/details.aspx?id=56840
  [uri] $URLsqlexpress = 'https://download.microsoft.com/download/4/1/A/41AD6EDE-9794-44E3-B3D5-A1AF62CD7A6F/sql16_sp2_dlc/en-us/SQLEXPR_x64_ENU.exe'
}
if ($Skype4b){
  # Microsoft® SQL Server 2014 Express 12.0.5000.0
  [uri] $URLsqlexpress = 'https://download.microsoft.com/download/2/A/5/2A5260C3-4143-47D8-9823-E91BB0121F94/SQLEXPR_x64_ENU.exe'
  
  # rolled back because Feature Pack isn't available yet. See comment from Mike S.
  # Microsoft® SQL Server 2014 Express SP3 - 12.6.6024.0 - https://www.microsoft.com/en-us/download/details.aspx?id=57473
  # [uri] $URLsqlexpress = 'https://download.microsoft.com/download/3/9/F/39F968FA-DEBB-4960-8F9E-0E7BB3035959/SQLEXPR_x64_ENU.exe'  
  # [uri] https://download.microsoft.com/download/6/7/8/67858AF1-B1B3-48B1-87C4-4483503E71DC/ENU/x86/SQLSysClrTypes.msi
}
if ($lync2013){
  # Microsoft® SQL Server® 2012 Express Service Pack 2 11.0.5058.0 (296MB)
  [uri] $URLsqlexpress = 'http://download.microsoft.com/download/0/1/E/01E0D693-2B4F-4442-9713-27A796B327BD/SQLEXPR_x64_ENU.exe'
}

# SQL Management Studio
if ($skype4b -or $skype4b2019){  
  # Microsoft® SQL Server® 2017 Management Studio 17.5 (14.0.17224.0)
  # [uri] $URLsqlmgmtstudio = 'https://download.microsoft.com/download/8/8/3/883FD1FA-FE61-4E83-85F9-FA46D4A5B866/SSMS-Setup-ENU.exe'
  # [string] $GUIDsqlmgmtstudioexpress = '{0BF524B0-77C8-406B-998A-0AC0F92146F3}' # {2505505B-176A-41B3-91CA-99F2D59DAC4F}' # {9BBE717B-128F-4470-9032-F373273DD237}

  # Microsoft® SQL Server® 2017 Management Studio 17.8.1 (14.0.17277.0) - 2018-07-31
  #[uri] $URLsqlmgmtstudio = 'https://download.microsoft.com/download/0/5/B/05B2AF8F-906F-4C57-A58E-5780F64F9D62/SSMS-Setup-ENU.exe'
  #[string] $GUIDsqlmgmtstudioexpress = '{945B6BB0-4D19-4E0F-AE57-B2D94DA32313}' # {C81F2AD3-1D19-4834-8C35-CC18DAF20E56}
  
  # Microsoft® SQL Server® 2017 Management Studio 17.9 - (14.0.17285.0) - 2018-11-11
  [uri] $URLsqlmgmtstudio = 'https://download.microsoft.com/download/B/8/3/B839AD7D-DDC7-4212-9643-28E148251DC1/SSMS-Setup-ENU.exe'
  [string] $GUIDsqlmgmtstudioexpress = '{00BE2F31-85B3-414F-8BAD-01E24FB17541}' # {C1350829-89AE-4566-ADF6-E7587D0C6B78}
}else{
  # Microsoft® SQL Server® 2012 Management Studio Express SP2 11.0.5058.0 (950.2MB)
  [uri] $URLsqlmgmtstudio = 'http://download.microsoft.com/download/0/1/E/01E0D693-2B4F-4442-9713-27A796B327BD/SQLManagementStudio_x64_ENU.exe'
  [string] $GUIDsqlmgmtstudioexpress = '{26BFF1F1-5C03-4C55-9C7C-FD65889AFA70}'
}

# SQL Native Client
[uri] $URLsqlnativeclient = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi'

# StatsMan 2046.22 (verified 11/14/2018) - https://www.microsoft.com/en-us/download/details.aspx?id=57518
[uri] $URLStatsManPerfAgent = 'https://download.microsoft.com/download/2/B/6/2B65E035-E20A-4C95-823F-DEA4D72012C3/StatsManPerfAgent.msi'
[uri] $URLStatsManListener = 'https://download.microsoft.com/download/2/B/6/2B65E035-E20A-4C95-823F-DEA4D72012C3/StatsManPerfAgentListener.msi'
[uri] $URLStatsManWebSite = 'https://download.microsoft.com/download/2/B/6/2B65E035-E20A-4C95-823F-DEA4D72012C3/StatsManWebSite.msi'
[uri] $URLStatsManUpdate = 'https://download.microsoft.com/download/2/B/6/2B65E035-E20A-4C95-823F-DEA4D72012C3/Update-StatsMan.ps1'

<#
    if ($skype4b){
    [uri] $URLStatsManPerfAgent = 'https://download.microsoft.com/download/9/E/9/9E9DA9D3-5E28-414D-9F1C-4852055BC5B4/StatsManPerfAgent.msi'
    [uri] $URLStatsManListener = 'https://download.microsoft.com/download/9/E/9/9E9DA9D3-5E28-414D-9F1C-4852055BC5B4/StatsManPerfAgentListener.msi'
    [uri] $URLStatsManWebSite = 'https://download.microsoft.com/download/9/E/9/9E9DA9D3-5E28-414D-9F1C-4852055BC5B4/StatsManWebSite.msi'
    [uri] $URLStatsManUpdate = 'https://download.microsoft.com/download/9/E/9/9E9DA9D3-5E28-414D-9F1C-4852055BC5B4/Update-StatsMan.ps1'
    }
#>

# Stress and performance tool - requires .Net 4.5!
if ($Skype4B){ # 9319.113 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=50367
  [uri] $URLstressandperformancetool = 'http://download.microsoft.com/download/4/7/3/4736BB77-B204-4D53-AAC1-C2ADFE8D00FE/CapacityPlanningTool.msi'
  [string] $GUIDstressperformancetool = '{94FD6E73-38F6-4DBE-AA3B-E403678868C9}'
}
if ($lync2013){ # 8308.299 (Verified 09/17/2018)
  # https://www.microsoft.com/en-us/download/details.aspx?id=36819
  [uri] $URLstressandperformancetool = 'http://download.microsoft.com/download/B/7/F/B7FD1DAB-F00A-4FD6-BA49-2A599B242A63/CapacityPlanningTool.msi'
  [string] $GUIDstressperformancetool = '{94FD6E73-38F6-4DBE-AA3B-E403678868C9}'  
}

# UCMA runtime
[uri] $URLucmaruntime = 'http://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe'

# Visual C++ 2010 (v10.x)
[string] $GUIDvcplusplus2010 = '{1D8E6291-B0D5-35EC-8441-6616F567A0F7}'

# Visual C++ (v11.0.50727)
[string] $GUIDvcplusplus2012 = '{A2CB1ACB-94A2-32BA-A15E-7D80319F7589}'

# Visual C++ 2013 (12.0.21005)
# {A749D8E6-B613-3BE3-8F5F-045C84EBA29B}

# Visual C++ 12
[uri] $URLvc12plusplus = 'http://download.microsoft.com/download/0/5/6/056dcda9-d667-4e27-8001-8a0c6971d6b1/vcredist_x64.exe'
[string] $GUIDvc12plusplus = '{CB0836EC-B072-368D-82B2-D3470BF95707}'

# Visual C++ 2015 - for debugging tools
[uri] $URLVc15plusplus = 'https://download.microsoft.com/download/9/3/F/93FCF1E7-E6A4-478B-96E7-D4B285925B00/vc_redist.x64.exe'
[string] $GUIDVc15plusplus = '{0D3E9E15-DE7A-300B-96F1-B4AF12B96488}'

# Visual C++ 2017 - 14.11.25325.0 (there is a newer version on the installation media) (verified 09/17/2018)
[uri] $URLVc17plusplus = 'https://download.visualstudio.microsoft.com/download/pr/11100230/15ccb3f02745c7b206ad10373cbca89b/VC_redist.x64.exe'
[string] $GUIDVc17plusplus = '{B0037450-526D-3448-A370-CACBD87769A0}'

# Visual C++ 2017 (v14.12.25810) (verified 09/17/2018)
# [string] $GUIDVc17plusplus = '{C99E2ADC-0347-336E-A603-F1992B09D582}'

# Web platform installer (for ARR 3.0)
# TODO: Investigate if this is the same thing: https://www.microsoft.com/en-us/download/details.aspx?id=6164
[uri] $URLWebPlatformInstaller = 'http://download.microsoft.com/download/F/4/2/F42AB12D-C935-4E65-9D98-4E56F9ACBC8E/wpilauncher.exe'

# Windows Azure Active Directory Module for Windows PowerShell v1.0 1.1.166.0
# TODO: Graph API https://docs.microsoft.com/en-us/office365/enterprise/powershell/connect-to-office-365-powershell 
# http://connect.microsoft.com/site1164/Downloads/DownloadDetails.aspx?DownloadID=59185
[uri] $URLAzureAdModule = "https://ucunleashed.com/downloads/$article/AdministrationConfig_3.msi"
[string] $GUIDAzureAdModule = '{581D5E88-A626-403D-94A2-B53C01E5896F}'

# WireShark v2.2.12
[uri] $URLwireshark = 'https://www.wireshark.org/download/win64/all-versions/Wireshark-win64-2.2.12.exe'
[uri] $URLwiresharkInstall = "https://ucunleashed.com/downloads/$Article/WireShark_2.2.12-install.exe"
[uri] $URLwiresharkConfig = "https://ucunleashed.com/downloads/$Article/WireShark_2.2.12-config.exe"
[uri] $URLwiresharkPlugin = "https://ucunleashed.com/downloads/$Article/Lync-Skype4B-Plugin2.00.lua"
#endregion DownloadURLsInstalledGUIDs

#region Menus - all of the various menus displayed in the script
[string] $Menu = @'

  ┌─────────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Features script   │
  └─────────────────────────────────────────────────────────────┘

  1)  Director prerequisites
  2)  Edge prerequisites
  3)  Front-End prerequisites
  4)  Mediation prerequisites
  5)  Office Online Server (prereqs, OOS, EN lang pack, updates)
  6)  Persistent Chat prerequisites
  7)  SCOM Watcher Node prerequisites
  8)  Application Request Routing (ARR) prerequisites  
  
  20) Microsoft tools menu    -->
  30) Third Party Apps menu   -->
  40) Misc reports menu       -->
  50) Misc server config menu -->
  60) Desktop shortcuts menu  -->
  70) Taskbar shortcuts menu  -->
  80) Downloads only menu     -->
  90) Security menu           -->

  95) Check for updates to this script
  96) Report a bug/problem with this script
  97) Visit website for this script
  98) Restart this server
  99) Exit

Select an option.. [1-99]?
'@

[string] $MsMenu = @'

  ┌─────────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - MS Tools and Apps │
  └─────────────────────────────────────────────────────────────┘

  1) Lync/SfB Resource Kit
  2) Persistent Chat Resource Kit (Lync Server only)
  3) Lync/SfB Debugging Tools
  4) Lync/SfB Stress and Performance Tool
  5) Best Practices Analyzer (Lync Server only)
  6) Lync Server Connectivity Analyzer
  7) Microsoft Message Analyzer
  8) SQL Server Management Studio
  9) Network Assessment Tool
  10) Install/Update .NET Framework

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $ThirdPartyMenu = @'

  ┌─────────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Third Party Tools │
  └─────────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1) WireShark (install and configure)  
  2) Custom PortQryUI

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $DesktopMenu = @'

  ┌─────────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Desktop Shortcuts │
  └─────────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1)  Logoff
  2)  Restart
  3)  Shutdown
  4)  Windows Update
  5)  Lync/SfB Management Shell
  6)  Lync/SfB Deployment Wizard
  7)  Lync/SfB Control Panel
  8)  Exchange UM Integration Utility (OcsUmUtil)
  9)  Snooper
  10) OCSLogger/CLSLogger Logging Tool
  11) Lync/SfB Topology Builder
  12) Certificate Management (local machine)
  13) Active Directory Users and Computers (ADUC)
  14) Message Analyzer
  15) Hosts file

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $TaskbarMenu = @'

  ┌─────────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Taskbar Shortcuts │
  └─────────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1)  Lync/SfB Management Shell
  2)  Lync/SfB Deployment Wizard
  3)  Lync/SfB Control panel
  4)  Exchange UM Integration Utility (OcsUmUtil)
  5)  Snooper
  6)  OCS/CLS Logger Logging Tool
  7)  Lync/SfB Topology Builder
  8)  REMOVE shortcut for PowerShell
  9)  Certificate Management (local machine)
  10) Active Directory Users and Computers (ADUC)
  11) Message Analyzer
  12) REMOVE Windows Store app from taskbar
  13) WireShark

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $DownloadMenu = @'

  ┌───────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Downloads       │
  └───────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1)  Latest Cumulative Update [DOWNLOAD ONLY]
  2)  Watcher Node [DOWNLOAD ONLY]
  3)  SCOM Management Pack [DOWNLOAD ONLY]
  4)  Lync 2013 Rollout & Adoption Success Kit (RASK) [DOWNLOAD ONLY]
  5)  Skype for Business SDN Interface API, Mgmt util, docs, & .chm [DOWNLOAD ONLY]
  6)  Lync/SfB Online Admin components [DOWNLOAD ONLY]
  8)  Network Assessment Tool [DOWNLOAD ONLY]
  9)  Bandwidth Calculator [DOWNLOAD ONLY]
  10) Skype for Business Adoption Portal [DOWNLOAD ONLY]
  11) Meeting Migration Tool (32 & 64 bit) [DOWNLOAD ONLY]
  12) Cloud Center Edition [DOWNLOAD ONLY]
  13) Skype for Business Post Move Cleanup Tool [DOWNLOAD ONLY]
  14) Call Quality Dashboard [DOWNLOAD ONLY]
  15) Real-Time Statistics Manager (StatsMan) [DOWNLOAD ONLY]
  16) IIS Crypto
  17) Skype for Business Basic Client (32 & 64 bit) [DOWNLOAD ONLY]
  18) Skype Room System Administrative Web Portal [DOWNLOAD ONLY]
  19) Key Health Indicators for Lync Server 2013 & Skype for Business Server 2015/2019 [DOWNLOAD ONLY]
  20) Skype for Business Server 2015 - 180 Eval .iso [DOWNLOAD ONLY]

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $SecurityMenu = @'

  ┌───────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Security        │
  └───────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1) Disable SSL 2.0 (PCI Compliance)
  2) Disable SSL 3.0 (PCI Compliance) (enable POODLE Defense
     and force TLS 1.1)
  3) EnableSessionTicket: Event IDs 32402, 61045 are logged
     in Lync Server 2013 Front End servers that are installed
     on Windows Server 2012 R2 (KB 2901554)
  4) Disable RC4 Cipher
  5) Lync Edge Server Replication failed FALSE with red cross
  6) Disable SMBv1
  7) Set LMCompatibilityLevel to 5 (NTLMv2 only)
  8) Disable Link-Local Multicast Name Resolution (LLMNR)
  9) Disable NetBIOS Name Service (NBTNS)
  10) Configure longer Diffie-Hellman ephemeral (DHE) key shares
      (MSA 3174644)
  11) Disable PCT 1.0
  12) Disable other weak ciphers (RC2, DES 56, etc.)
  13) Disable Multi-Protocol Unified Hello
  14) Remove Windows Defender Antivirus

  99) Exit to Main Menu

Select an option.. [1-99]?
'@

[string] $ServerConfigMenu = @"

  ┌───────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Server Config   │
  └───────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1)  Lync Server 2013 Documentation Help (Lync Server only)
  2)  Configure PowerShell Help auto-update scheduled task
  3)  Telnet client
  4)  Disable automatic Windows updates
  5)  Set recovery of Lync/SfB/OWAS/OOS services to `"restart`"
  6)  Set fabric logging to circular
  7)  Disable Server Manager on logon
  8)  Upgrade to PowerShell 4.0
  9)  Fix Lync Control Panel font (Lync Server only)
  10) Set power plan to `"High Performance`"
  11) Edit hosts file
  12) Configure static routing (edge and ARR)
  13) Configure Primary DNS suffix (edge and ARR)
  14) Lync/SfB Online Admin components
  15) Enable Photo URL option
  16) Lync Room System (LRS) Admin Portal prerequisites
  17) Add custom Scheduler URL to simple URLs
  18) Configure Skype Federation
  19) Temporarily block the installation of the .NET Framework 4.7.2
  20) Microsoft UCMA 4.0 - for sefautil.exe  
  21) Launch Windows Update
  22) Add Trusted Root Cert Authorities to Edge Servers
  23) Enable Enhanced Experience for Meetings Hosted on Skype for Business On-premises
  24) MS Teams PowerShell module
  25) Create Lync/SfB file share on local computer
  26) Disable Windows Admin Console prompt (WS2019)
  
  99) Exit to Main Menu

Select an option.. [1-99]?
"@

[string] $ReportsMenu = @'

  ┌───────────────────────────────────────────────────────────┐
  │ Lync Server / Skype for Business Server - Reports         │
  └───────────────────────────────────────────────────────────┘

    Please select an option from the choices below.

  1) Show AD disabled accounts that are still enabled in Lync/SfB
  2) Show elevated accounts that are enabled in Lync/SfB
  3) Show users whose SMTP address does not match their SIP address
  4) Show Response Groups with no agents
  5) Show admin group membership

  99) Exit to Main Menu

Select an option.. [1-99]?
'@
#endregion Menus

#region WindowsFeatures - Windows Features defined per role
# We use [System.Collections.ArrayList] here so that we can manipulate the arrays easier, as there are some differences between Server 2012/2012 R2 and 2016 and 2019.
###########################
# Peripheral roles required Windows features
###########################
# requires source
[Collections.ArrayList] $WinFeatARR =
  'Web-Default-Doc',
  'Web-Dir-Browsing',
  'Web-Http-Errors',
  'Web-Static-Content',
  'Web-Http-Logging',
  'Web-Log-Libraries',
  'Web-Http-Tracing',
  'Web-Stat-Compression',
  'Web-Filtering',
  'Web-Mgmt-Console',
  'Web-Scripting-Tools',
  'Web-Mgmt-Service',
  'NET-Framework-Core',
  'NET-Framework-45-Core',
  'NET-Framework-45-ASPNET',
  'NET-WCF-TCP-PortSharing45'

  [Collections.ArrayList] $WinFeatOWAS =
  'Web-Server', 
  'Web-Mgmt-Tools', 
  'Web-Mgmt-Console', 
  'Web-WebServer', 
  'Web-Common-Http', 
  'Web-Default-Doc', 
  'Web-Static-Content', 
  'Web-Performance', 
  'Web-Stat-Compression', 
  'Web-Dyn-Compression', 
  'Web-Security', 
  'Web-Filtering', 
  'Web-Windows-Auth', 
  'Web-App-Dev', 
  'Web-Net-Ext45', 
  'Web-Asp-Net45', 
  'Web-ISAPI-Ext', 
  'Web-ISAPI-Filter', 
  'Web-Includes', 
  'Windows-Identity-Foundation',
  'NET-WCF-HTTP-Activation45'

  if(-Not $IsSrv2016){ # Windows Server 2016 does not have this feature
    $WinFeatOWAS.Add('InkandHandwritingServices') | Out-Null
  }
  if ($IsSrv2016){  
    $WinFeatOWAS.Add('NET-Framework-45-Features') | Out-Null
    $WinFeatOWAS.Add('NET-Framework-45-Core') | Out-Null
  }

###########################
# Lync 2013/Skype For Business 2015/2019 roles required windows features
###########################

if ($skype4b -or $skype4b2019){ # Director - https://technet.microsoft.com/en-us/library/dn951388.aspx
  [Collections.ArrayList] $WinFeatDirector =
  'RSAT-ADDS', 
  'Web-Server', 
  'Web-Static-Content', 
  'Web-Default-Doc', 
  'Web-Http-Errors', 
  'Web-Asp-Net', 
  'Web-Net-Ext', 
  'Web-ISAPI-Ext', 
  'Web-ISAPI-Filter', 
  'Web-Http-Logging', 
  'Web-Log-Libraries', 
  'Web-Request-Monitor', 
  'Web-Http-Tracing', 
  'Web-Basic-Auth', 
  'Web-Windows-Auth', 
  'Web-Client-Auth', 
  'Web-Filtering', 
  'Web-Stat-Compression', 
  'NET-WCF-HTTP-Activation45', 
  'Web-Asp-Net45', 
  'Web-Scripting-Tools', 
  'Web-Mgmt-Compat', 
  'Telnet-Client',
  'Web-Dyn-Compression',
  'Web-Mgmt-Tools',
  'Windows-Identity-Foundation'
    
  if (-Not ($IsSrv2016) -and (-Not($IsSrv2019))){ # Windows Server 2016/2019 does not have this feature
    $WinFeatDirector.Add('Desktop-Experience') | Out-Null
  }
}

if ($skype4b -or $skype4b2019){ # Edge
    # requires source
    [Collections.ArrayList] $WinFeatEdge =
    'NET-Framework-Core', 
    'Windows-Identity-Foundation', 
    'NET-WCF-HTTP-Activation45', 
    'Web-Asp-Net45' 
}else{ 
    [Collections.ArrayList] $WinFeatEdge =
    'NET-Framework-45-Core',
    'Windows-Identity-Foundation'
}

if ($skype4b -or $skype4b2019){ # Front End - https://technet.microsoft.com/en-us/library/dn951388.aspx
  # requires source
  [Collections.ArrayList] $WinFeatFrontEnd =
  'NET-Framework-Core',
  'RSAT-ADDS',
  'Windows-Identity-Foundation',
  'Web-Server',
  'Web-Static-Content',
  'Web-Default-Doc',
  'Web-Http-Errors',
  'Web-Dir-Browsing',
  'Web-Asp-Net',
  'Web-Net-Ext',
  'Web-ISAPI-Ext',
  'Web-ISAPI-Filter',
  'Web-Http-Logging',
  'Web-Log-Libraries',
  'Web-Request-Monitor',
  'Web-Http-Tracing',
  'Web-Basic-Auth',
  'Web-Windows-Auth',
  'Web-Client-Auth',
  'Web-Filtering',
  'Web-Stat-Compression',
  'Web-Dyn-Compression',
  'NET-WCF-HTTP-Activation45',
  'Web-Asp-Net45',
  'Web-Mgmt-Tools',
  'Web-Scripting-Tools',
  'Web-Mgmt-Compat',
  'Server-Media-Foundation',
  'BITS'
  
  if ((-Not $IsSrv2016) -and (-Not $IsSrv2019)){ # Windows Server 2016/2019 do not have this feature
    $WinFeatFrontEnd.Add('Desktop-Experience') | Out-Null
  }
  if ($Skype4b2019 -and $IsSrv2019){ # based on Konrad's notes
    $WinFeatFrontEnd.Remove('Web-Dir-Browsing') | Out-Null
    $WinFeatFrontEnd.Remove('Server-Media-Foundation') | Out-Null
    $WinFeatFrontEnd.Remove('BITS') | Out-Null
  }
  if ($Skype4b2019){ # Per Korbyn Forsman - for SfB2019 CU1 - need to validate if that's OS specific
    $WinFeatFrontEnd.Add('ManagementOData') | Out-Null
    $WinFeatFrontEnd.Add('Web-Mgmt-Service') | Out-Null
    $WinFeatFrontEnd.Add('Web-WMI') | Out-Null
    $WinFeatFrontEnd.Add('Web-Lgcy-Scripting') | Out-Null
    $WinFeatFrontEnd.Add('Web-Lgcy-Mgmt-Console') | Out-Null
  }

  if ($Skype4b2019 -and $IsSrv2019){ # Required in SfB 2019 CU1 for new Control Panel (Preview) - doesn't appear to be required on WS2016
    $WinFeatFrontEnd.Add('NET-HTTP-Activation') | Out-Null # This seems to be the only feature that's not automatically installed on WS2016
    $WinFeatFrontEnd.Add('Web-Basic-Auth') | Out-Null
    $WinFeatFrontEnd.Add('Web-Mgmt-Tools') | Out-Null
    $WinFeatFrontEnd.Add('Web-Scripting-Tools') | Out-Null
    $WinFeatFrontEnd.Add('Web-Mgmt-Compat') | Out-Null
  }
}else{ # Lync Server 2013 # https://technet.microsoft.com/en-us/library/gg398686.aspx
  [Collections.ArrayList] $WinFeatFrontEnd =
  'RSAT-ADDS',
  'Web-Server',
  'Web-Static-Content',
  'Web-Default-Doc',
  'Web-Http-Errors',
  'Web-Asp-Net',
  'Web-Net-Ext',
  'Web-ISAPI-Ext',
  'Web-ISAPI-Filter',
  'Web-Http-Logging',
  'Web-Log-Libraries',
  'Web-Request-Monitor',
  'Web-Http-Tracing',
  'Web-Basic-Auth',
  'Web-Windows-Auth',
  'Web-Client-Auth',
  'Web-Filtering',
  'Web-Stat-Compression',
  'Web-Dyn-Compression',
  'NET-WCF-HTTP-Activation45',
  'Web-Asp-Net45',
  'Web-Mgmt-Tools',
  'Web-Scripting-Tools',
  'Web-Mgmt-Compat',
  'Desktop-Experience',
  'BITS',
  'Windows-Identity-Foundation'
}

if ($skype4b -or $skype4b2019){
  [Collections.ArrayList] $WinFeatMediation =
  'NET-Framework-Core', 
  'RSAT-ADDS', 
  'Windows-Identity-Foundation', 
  'NET-WCF-HTTP-Activation45', 
  'Web-Asp-Net45'
}else{ # Lync Server 2013
  $WinFeatMediation =
  'Windows-Identity-Foundation'
}

if ($skype4b -or $skype4b2019){ # PChat - https://technet.microsoft.com/en-us/library/dn951388.aspx
  # requires source
  [Collections.ArrayList] $WinFeatPChat =
    'NET-Framework-Core',
    'RSAT-ADDS',
    'Windows-Identity-Foundation',
    'Web-Server',
    'Web-Static-Content',
    'Web-Default-Doc',
    'Web-Http-Errors',
    'Web-Dir-Browsing',
    'Web-Asp-Net',
    'Web-Net-Ext',
    'Web-ISAPI-Ext',
    'Web-ISAPI-Filter',
    'Web-Http-Logging',
    'Web-Log-Libraries',
    'Web-Request-Monitor',
    'Web-Http-Tracing',
    'Web-Basic-Auth',
    'Web-Windows-Auth',
    'Web-Client-Auth',
    'Web-Filtering',
    'Web-Stat-Compression',
    'Web-Dyn-Compression',
    'NET-WCF-HTTP-Activation45',
    'Web-Asp-Net45',
    'Web-Mgmt-Tools',
    'Web-Scripting-Tools',
    'Web-Mgmt-Compat',
    'Server-Media-Foundation',
    'BITS',
    'MSMQ-Server'
}else{ # Lync Server 2013 # https://technet.microsoft.com/en-us/library/gg398686.aspx
  [Collections.ArrayList] $WinFeatPChat =
    'RSAT-ADDS',
    'Web-Server',
    'Web-Static-Content',
    'Web-Default-Doc',
    'Web-Http-Errors',
    'Web-Asp-Net',
    'Web-Net-Ext',
    'Web-ISAPI-Ext',
    'Web-ISAPI-Filter',
    'Web-Http-Logging',
    'Web-Log-Libraries',
    'Web-Request-Monitor',
    'Web-Http-Tracing',
    'Web-Basic-Auth',
    'Web-Windows-Auth',
    'Web-Client-Auth',
    'Web-Filtering',
    'Web-Stat-Compression',
    'Web-Dyn-Compression',
    'NET-WCF-HTTP-Activation45',
    'Web-Asp-Net45',
    'Web-Mgmt-Tools',
    'Web-Scripting-Tools',
    'Web-Mgmt-Compat',
    'Desktop-Experience',
    'BITS',
    'Windows-Identity-Foundation'
}

$WinFeatWatcherNode =
  'Windows-Identity-Foundation'

[Collections.ArrayList] $WinFeatUCMA4 =
  'Windows-Identity-Foundation',
  'Server-Media-Foundation'

$WinFeatPowerShell4 =
  'Windows-Identity-Foundation'

if ($IsSrv2016){
  $WinFeatDefender = 
  'Windows-Defender, Windows-Defender-GUI'
}

if ($IsSrv2019){
  $WinFeatDefender = 
  'Windows-Defender'
}
#endregion WindowsFeatures

#region LogHeader - what's included at the beginning of the log file. Mostly used for reference and troubleshooting.
Write-Log -Type Info -Message "Version           : $ScriptVersion" -NoConsole
Write-Log -Type Info -Message "Lync 2013         : $Lync2013" -NoConsole
Write-Log -Type Info -Message "Skype4B2015       : $Skype4B" -NoConsole
Write-Log -Type Info -Message "Skype4B2019       : $Skype4B2019" -NoConsole
Write-Log -Type Info -Message "User              : $env:UserDomain\$env:UserName" -NoConsole
Write-Log -Type Info -Message "Local Admin       : $(Test-IsAdmin)" -NoConsole
Write-Log -Type Info -Message "Command           : $($MyInvocation.Line)" -NoConsole
Write-Log -Type Info -Message "Server            : $env:ComputerName" -NoConsole
Write-Log -Type Info -Message "OS                : $OSName ($($OSVersion.Version))" -NoConsole
if ($VirtualizationInfo.IsVirtual){
  Write-Log -Type Info -Message "Virtualization    : $($VirtualizationInfo.VirtualType) (Host: $($VirtualizationInfo.Host))" -NoConsole
}else{
  Write-Log -Type Info -Message 'Virtualization    : Physical' -NoConsole
}
Write-Log -Type Info -Message "Culture           : $((Get-Culture).Name) `"$((Get-Culture).Displayname)`"" -NoConsole
Write-Log -Type Info -Message "Domain Member     : $IsDomainMember" -NoConsole
Write-Log -Type Info -Message "Memory            : $ram GB" -NoConsole
Write-Log -Type Info -Message "NICs Enabled      : $NumberOfNics" -NoConsole
Write-Log -Type Info -Message "Power Level       : $PowerLevel" -NoConsole
Write-Log -Type Info -Message "AV Solution       : $AvSolution" -NoConsole
Write-Log -Type Info -Message "Last boot time    : $LastBootTime" -NoConsole
Write-Log -Type Info -Message "Log path          : $LogPath" -NoConsole

if ($GetInfoFromRegistry){
  Write-Log -Type Info -Message "Target folder     : $TargetFolder (via registry)" -NoConsole
  Write-Log -Type Info -Message "SQLPath           : $SQLPath (via registry)" -NoConsole
  if ($WindowsSourceIso){
    Write-Log -Type Info -Message "WindowsSource     : $WindowsSourceIso as $WindowsSource (via registry)" -NoConsole
  }else{
    Write-Log -Type Info -Message "WindowsSource     : $WindowsSource (via registry)" -NoConsole
  }
  Write-Log -Type Info -Message "DisableAutoUpdates: $DisableAutoUpdates" -NoConsole  
  Write-Log -Type Info -Message "DisableFPSharing  : $DisableFPSharing" -NoConsole
  Write-Log -Type Info -Message "DisableLmHosts    : $DisableLmHosts" -NoConsole
  Write-Log -Type Info -Message "DisableNetBios    : $DisableNetBios" -NoConsole
  Write-Log -Type Info -Message "DisableWac        : $DisableWac" -NoConsole
  Write-Log -Type Info -Message "IncludeFW         : $IncludeFW" -NoConsole
  Write-Log -Type Info -Message "IncludeHighPower  : $IncludeHighPower" -NoConsole
  Write-Log -Type Info -Message "IncludeLangPack   : $IncludeLanguagePack" -NoConsole
  Write-Log -Type Info -Message "IncludeOnlineAdmin: $IncludeOnlineAdminTools" -NoConsole
  Write-Log -Type Info -Message "IncludeSsms       : $IncludeSSMS" -NoConsole
  Write-Log -Type Info -Message "IncludeStandard   : $IncludeStandard" -NoConsole
  Write-Log -Type Info -Message "IncludeTelnet     : $IncludeTelnet" -NoConsole
  Write-Log -Type Info -Message "IncludeTrustedCert: $IncludeTrustedCerts" -NoConsole  
} else {
  Write-Log -Type Info -Message "Target folder     : $TargetFolder" -NoConsole
  Write-Log -Type Info -Message "SQLPath           : $SQLPath" -NoConsole
  if ($WindowsSourceIso){
    Write-Log -Type Info -Message "WindowsSource     : $WindowsSourceIso as $WindowsSource" -NoConsole
  }else{
    Write-Log -Type Info -Message "WindowsSource     : $WindowsSource" -NoConsole
  }
}
Write-Log -Type Info -Message "ParameterSet      : $($PsCmdlet.ParameterSetName)" -NoConsole
Write-Log -Type Info -Message "Signed script     : $(Test-IsSigned)" -NoConsole
# These are commented out because they cause a problem for some users.
# Write-Log -Type Info -Message "Forest level      : $(Get-FunctionalLevel -forest)" -NoConsole
# Write-Log -Type Info -Message "Domain level      : $(Get-FunctionalLevel -domain)" -NoConsole
Write-Log -Type Info -Message "Domain firewall   : $DomainFW" -NoConsole
Write-Log -Type Info -Message "Public firewall   : $PublicFW" -NoConsole
Write-Log -Type Info -Message "Private firewall  : $PrivateFW" -NoConsole
Write-Log -Type Info -Message "Recom'd updates   : $RecommendedUpdates" -NoConsole

Write-Log -Type Info -Message ".Net Framework    : $DotNetVersion ($InstalledDotNetVersion)" -NoConsole
if ($lync2013){
  Write-Log -Type Info -Message "Visual C++ 2012   : $VC12PlusPlus" -NoConsole
}else{
  Write-Log -Type Info -Message "Visual C++ 2013   : $VC13PlusPlus" -NoConsole
  Write-Log -Type Info -Message "Visual C++ 2014   : $VC14PlusPlus" -NoConsole
  Write-Log -Type Info -Message "Visual C++ 2015   : $VC15PlusPlus" -NoConsole
  Write-Log -Type Info -Message "Visual C++ 2017   : $VC17plusplus" -NoConsole
}

Write-Log -Type Info -Message "SSL 2 enabled     : $IsSSL2Enabled" -NoConsole
Write-Log -Type Info -Message "SSL 3 enabled     : $IsSSL3Enabled" -NoConsole
Write-Log -Type Info -Message "RC4 enabled       : $IsRc4Enabled" -NoConsole
Write-Log -Type Info -Message "Lm Compatibility  : $LmCompatibilityLevel" -NoConsole
Write-Log -Type Info -Message "PowerShell        : $PowerShellVersion" -NoConsole

Write-Log -Type Divider -NoConsole
if ((-Not ($SkipUpdateCheck)) -and (-Not ($GetInfoFromRegistry))){
  Get-UpdateInfo -Article $Article
  Write-Log -Type Divider -NoConsole
}else{
  Write-Log -Type Info -Message 'User opted to skip update check' -NoConsole
}
Write-Log -Type Info -Message 'Checking environment' -NoConsole

Write-Log -Type Info -Message 'Checking operating system version' -NoConsole -Indent 1
if ((-Not ($IsSrv2012)) -and (-Not ($IsSrv2012R2)) -and (-Not ($IsSrv2016)) -and (-Not ($IsSrv2019 -and $Skype4b2019)) -and (-Not ($DownloadAll)) -and (-Not ($DownloadOnly))){
  Write-Host $OSMismatchWarning -ForegroundColor Red
  Write-Log -Type Error -Message "Failed operating system version ($($OSVersion.Version))" -NoConsole -Indent 1
  Stop-Script
}

if ($skype4b2019 -and (-Not ($IsSrv2016 -or $IsSrv2019)) -and (-Not ($DownloadAll)) -and (-Not ($DownloadOnly))){
  Write-Host $OSMismatchWarning2016 -ForegroundColor Red
  Write-Log -Type Error -Message "Failed operating system version ($($OSVersion.Version))" -NoConsole -Indent 1
  Stop-Script
}

if ($IsSrvCore){
  Write-Host $NanoWarning -ForegroundColor Red
  Write-Log -Type Error -Message "Failed operating system Windows Server Core check ($($OSVersion.Version))" -NoConsole -Indent 1
  Stop-Script
}

Write-Log -Type Info -Message "Passed operating system version ($($OSVersion.Version))" -NoConsole -Indent 1
Write-Log -Type Divider -NoConsole

if ((-Not $SkipCoreCheck) -and (-Not $DownloadAll) -and (-Not ($DownloadOnly))){
  if (Test-IsServerCore){
    Write-Host $Win2012CoreWarning -ForegroundColor Red
    Write-Log -Type Error -Message 'Failed operating system core vs. gui' -NoConsole -Indent 1
    Stop-Script
  } else {
    Write-Log -Type Info -Message 'Passed operating system core vs. gui' -NoConsole -Indent 1
  }
}else{
  Write-Log -Type Info -Message 'User opted to skip core test' -NoConsole -Indent 1
}
Write-Log -Type Divider -NoConsole

# Restart-AsElevatedScript

<#
    Write-Log -Type Info -Message 'Checking if server restart is required.'
    if ((Test-IsRebootRequired) -and (-Not ($DownloadOnly)) -and (-Not ($DownloadAll))){
    Write-Log -Type Warn -Message 'Restart is required' -Indent 1
    $RestartRequired = $true
    Write-Log -Type Info -Message 'Prompting the user to restart.' -NoConsole
    if ((New-Popup -Message 'A server restart is required before other components can be installed. Once restarted, run the script again, and choose the same option. Would you like to restart the server now?' -Title 'Server restart is required' -Buttons YesNo -Icon Question) -eq 6){
    Write-Log -Type Info -Message 'User chose to restart.' -NoConsole -Indent 1
    Set-RunOnce
    Stop-Script -Reboot
    }else{
    Write-Log -Type Info -Message 'User chose NOT to restart.' -NoConsole -Indent 1
    Stop-Script
    }
    }else{
    Write-Log -Type Info -Message 'Restart is NOT required.' -Indent 1        
    }
    Write-Log -Type Divider -NoConsole
#>
Invoke-RestartQuery

Test-InvalidCert -FixRootStore -FixIntermediateStore
#endregion LogHeader

#region DownloadAll - Just downloads all of the files. Useful if you run from workstation and copy files to servers without Internet access
if ($DownloadAll){
  Write-Log -Type Info -Message 'DownloadAll option selected' -NoConsole
  Write-Log -Type Divider -NoConsole

  $StuffToDownload = Get-Variable | Where-Object {$_.name -match '^url' -and ($_.name -NotMatch '^URLwacimage$')} | Sort-Object -Property Name
  if ($StuffToDownload){
    $FileCounter = 0
    foreach ($dlurl in $StuffToDownload){
      if ($dlurl.name -match 'URLlatestcu|URLchm'){
        New-FileDownload -SourceFile "$($dlurl.value)" -IgnoreLocalCopy
      }else{
        New-FileDownload -SourceFile "$($dlurl.value)"
      }
      $FileCounter++
      Write-Log -Type Divider -NoConsole
    }
    # Write-Log -Type Divider -NoConsole
  }
  Write-Log -Type Info -Message "Completed processing of $FileCounter files"
  Stop-Script
}
#endregion DownloadAll
Do { # This is where the magic happens. Strap in, it's a bumpy ride!
  if ($InitialMenuOption){
    Write-Log -Type Info -Message "User defined InitialMenuOption as $InitialMenuOption" -NoConsole
    Write-Log -Type Info -Message 'Skipping display of menu' -NoConsole -Indent 1
    $MenuOption = $InitialMenuOption
    Remove-Variable -Name InitialMenuOption
    [gc]::Collect()
  } else {
    # Write-Log -Type Divider -NoConsole
    Write-Log -Type Info -Message 'Displaying main menu' -NoConsole
    $MenuOption = Read-Host -Prompt $Menu
  }

  switch ($MenuOption) {
    1{ # Director server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Director server)" -NoConsole
      Write-Log -Type Divider -NoConsole

      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLsqlexpress
        New-FileDownload -SourceFile $URLsqlmgmtstudio
        Break
      }

      if (-Not ($IsDomainMember)){
        Write-Log -Type Error -Message 'This server is not domain joined. Director servers must be domain joined. Please domain join this server and try again.'
        Break
      }

      Invoke-NicCheck      
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      Invoke-WinSourceCheck
      if ($ValidWinSource){        
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatDirector").Replace(' ', ', '))" -NoConsole
        $WindowsFeatures = Add-WindowsFeature -Name $WinFeatDirector -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
        $RestartNeeded = $WindowsFeatures.RestartNeeded
        Invoke-RestartQuery
      } else {
        Write-Log -Type Error -Message 'WindowsSource not valid' -NoConsole
        Write-Host $Win2012SourceWarning -ForegroundColor red
        Stop-Script
      }
      if (-not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $WindowsFeatures.Success
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }
      if (($Skype4B -or $skype4b2019) -and (-Not ($IsSrv2016)) -and (-Not ($IsSrv2019))){
        Install-Hotfix
      }
      if (-Not ($NoSQL)){New-SqlInstance -Instance RtcLocal}
      if (-Not ($NoSQL)){New-SqlInstance -Instance LyncLocal}
      Install-SqlMgmtStudio
      Set-HighPower
      Set-AutoUpdateConfig
      Install-DotNet
      Disable-WacPrompt
      # Set-NicPowerManagement -Disable
      Invoke-RestartQuery -NoRunonce
    } # end Director server
    2{ # Edge server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Edge server)" -NoConsole
      Write-Log -Type Divider -NoConsole

      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLsqlexpress
        New-FileDownload -SourceFile $URLsqlmgmtstudio
        Break
      }

      # Invoke-NicCheck
      Write-Log -Type Info -Message 'Checking for domain membership' -NoConsole
      if ($IsDomainMember){
        Write-Log -Type Warn -Message 'This server is domain joined, which is not recommended for this role. Prompting user.' -Indent 1
        if ((New-Popup -Message 'This server is domain joined. Domain membership for this role is not recommended. Do you wish to continue anyways?' -Title 'Domain membership' -Buttons YesNo) -eq 7){
          Write-Log -Type Info -Message 'User opted to NOT continue' -Indent 1 -NoConsole
          Stop-Script
        }else{
          Write-Log -Type Info -Message 'User opted to NOT continue' -Indent 1 -NoConsole
        }
      }else{
        Write-Log -Type Info -Message 'Server is NOT domain joined' -NoConsole -Indent 1
        Write-Log -Type Divider -NoConsole
        Set-PrimaryDnsSuffix
      }
      Write-Log -Type Divider -NoConsole
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient      
      if ($skype4b -or $skype4b2019){
        Invoke-WinSourceCheck        
        if ($ValidWinSource){
          Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
          Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatEdge").Replace(' ', ', '))" -NoConsole
          $WindowsFeatures = Add-WindowsFeature -Name $WinFeatEdge -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
          $RestartNeeded = $WindowsFeatures.RestartNeeded
        }
      }else{
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatEdge").Replace(' ', ', '))" -NoConsole
        $RestartNeeded = (Add-WindowsFeature -Name $WinFeatEdge -WarningAction SilentlyContinue).RestartNeeded
      }
      if (-not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }      
      Invoke-RestartQuery
      if (($Skype4B -or $skype4b2019) -and (-Not ($IsSrv2016))){
        Install-Hotfix
      }
      if (-Not ($NoSQL)){
        New-SqlInstance -Instance RtcLocal
      }
      Install-SqlMgmtStudio
      Set-HighPower
      Set-AutoUpdateConfig
      if (-Not $SkipEdgeNicConfig){
        Set-NicConfig
      }else{
        Write-Log -Type Warn -Message 'SkipEdgeNicConfig option chosen. User is responsible for related NIC configuration.'
        Write-Log -Type Divider -NoConsole
      }
      
      Write-Log -Type Info -Message 'Prompting for trusted root certification authorities' -NoConsole
      if ($IncludeTrustedCerts -or ((New-Popup -Message 'Add Trusted Root Certification Authorities to Edge Servers' -Title 'Trusted certs' -Buttons YesNo -Icon Question) -eq 6)){
        Write-Log -Type Info -Message 'User chose to add trusted root certification authorities to edge servers' -NoConsole
        'https://comodo.com', 'https://digicert.com', 'https://www.entrust.net', 'https://geotrust.com', 'https://www.globalsign.com', 'https://godaddy.com', 'https://letsencrypt.org', 'https://www.networksolutions.com', 'https://www.ssl.com', 'https://www.swisssign.com', 'https://www.symantec.com', 'https://thawte.com', 'https://wisekey.com' | Add-TrustedRootCertsToEdge
      } else {
        Write-Log -Type Warn -Message 'User chose NOT to add trusted root certification authorities to edge servers' -NoConsole
        Write-Log -Type Divider -NoConsole
      }
      Install-DotNet
      Disable-WacPrompt
      # Set-NicPowerManagement -Disable
      Invoke-RestartQuery -NoRunonce
    } # end Edge server
    3{ # Front End server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Front End server)" -NoConsole
      Write-Log -Type Divider -NoConsole      

      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLsilverlight
        New-FileDownload -SourceFile $URLsqlexpress
        New-FileDownload -SourceFile $URLsqlmgmtstudio
        Break
      }
            
      if (-Not ($IsDomainMember)){
        Write-Log -Type Error -Message 'This server is not domain joined. Front End servers must be domain joined. Please domain join this server and try again.'
        Break
      }
      Invoke-NicCheck      
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      Invoke-WinSourceCheck
      if ($ValidWinSource){        
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatFrontEnd").Replace(' ', ', '))" -NoConsole        
        $WindowsFeatures = Add-WindowsFeature -Name $WinFeatFrontEnd -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
        $RestartNeeded = $WindowsFeatures.RestartNeeded
        Write-Log -Type Info -Message 'Checking if restart is needed' -NoConsole
        if ($RestartNeeded -eq 'Yes'){
          Write-Log -Type Warn -Message 'Restart is required' -NoConsole -Indent 1
          if ((New-Popup -Message $PrereqRebootPromptWarning -Title 'Restart is required' -Buttons YesNo -Icon Question) -eq 6){
            Write-Log -Type Info -Message 'User chose to reboot' -NoConsole -Indent 1
            # Write-Log -Type Info -Message 'Setting registry entry' -NoConsole -Indent 1
            Set-RunOnce
            Stop-Script -Reboot
          } else {
            Write-Log -Type Warn -Message 'User chose NOT to reboot' -NoConsole
            Stop-Script
          }
        }else{
          Write-Log -Type Info -Message 'Restart is NOT needed' -NoConsole -Indent 1
        }
      } else {
        Write-Log -Type Error -Message 'WindowsSource not valid' -NoConsole -Indent 1
        Write-Host $Win2012SourceWarning -ForegroundColor red
        Stop-Script
      }
      if (-not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }
      Write-Log -Type Divider -NoConsole
      if (($Skype4B -or $skype4b2019) -and (-Not ($IsSrv2016)) -and (-Not($IsSrv2019))){
        Install-Hotfix
      }
      if (-Not ($NoSQL)){New-SqlInstance -Instance RtcLocal}
      if (-Not ($NoSQL)){New-SqlInstance -Instance LyncLocal}
      if (-Not ($IncludeStandard) -and (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -Name 'Rtc' -ErrorAction SilentlyContinue))){
        Write-Log -Type Info -Message 'Prompting for Standard Edition' -NoConsole
        $Standard = New-Popup -Message 'Is this a Standard Edition server?' -Title 'What type of server?' -Buttons 'YesNo' -Icon Question
      }
      if ($Standard -eq 6 -or ($IncludeStandard)){
        Write-Log -Type Info -Message 'This is a Standard Edition server' -NoConsole
        # Let's see if this next line correctly removes the prompt for standard after the reboot (following the SQL instances being installed).
        $IncludeStandard = $true
        Write-Log -Type Divider -NoConsole
        if (-Not ($NoSQL)){
          New-SqlInstance -Instance Rtc
        }
      } else {
        Write-Log -Type Info -Message 'This is NOT a Standard Edition server' -NoConsole -Indent 1
      }
      Install-SqlMgmtStudio
      Install-SilverLight
      Set-HighPower
      Set-AutoUpdateConfig
      Install-DotNet      
      New-FeShare
      Disable-WacPrompt
      # Set-NicPowerManagement -Disable      
      Invoke-RestartQuery
      Install-CsOnlineAdminTools
      Invoke-RestartQuery -NoRunonce
    } # end Front End server
    4{ # Mediation server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Mediation server)" -NoConsole
      Write-Log -Type Divider -NoConsole
      
      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLsqlexpress
        New-FileDownload -SourceFile $URLsqlmgmtstudio
        Break
      }

      if (-Not ($IsDomainMember)){
        Write-Log -Type Error -Message 'This server is not domain joined. Mediation servers must be domain joined. Please domain join this server and try again.'
        Break
      }

      Invoke-NicCheck
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      Invoke-WinSourceCheck
      if ($ValidWinSource){        
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatMediation").Replace(' ', ', '))" -NoConsole
        $WindowsFeatures = Add-WindowsFeature -Name $WinFeatMediation -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
        $RestartNeeded = $WindowsFeatures.RestartNeeded
      } else {
        Write-Log -Type Error -Message 'WindowsSource not valid' -NoConsole -Indent 1
        Write-Host $Win2012SourceWarning -ForegroundColor red
        Stop-Script
      }
      if (-not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }      
      Invoke-RestartQuery
      if (($Skype4B -or $skype4b2019) -and (-Not ($IsSrv2016))){
        Install-Hotfix
      }
      if (-Not ($NoSQL)){
        New-SqlInstance -Instance RtcLocal
      }
      Install-SqlMgmtStudio
      Set-HighPower
      Set-AutoUpdateConfig
      Install-DotNet
      Disable-WacPrompt
      # Set-NicPowerManagement -Disable
      Invoke-RestartQuery -NoRunonce
    } # end Mediation server
    5{ # Office Online Server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Office Online Server)" -NoConsole
      Write-Log -Type Divider -NoConsole
      
      if ($IsSrv2019){
        Write-Log -Type Warn -Message 'This option is not supported on Windows Server 2019'
        Break
      }      
      
      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLdotnet
        if ($URLwacCU) {
          New-FileDownload -SourceFile $URLwacCU
        }
        New-FileDownload -SourceFile $URLwacenglishlanguagepack
        New-FileDownload -SourceFile $URLvc12plusplus
        New-FileDownload -SourceFile $URLIdentityModel
        Break
      }      
      
      ##############################################################################################################
      ##########
      ########## Note:   OWAS *MUST* be installed on the system drive or weird errors in rendering may occur.
      ##########         When creating the farm, however, cache and logging folders can be located elsewhere.
      ##########
      if (-Not($IsSrv2012R2 -or $IsSrv2016)){ # https://docs.microsoft.com/en-us/officeonlineserver/deploy-office-online-server
        Write-Log -Type Warn -Message 'This option is only supported on Windows Server 2012R2 and 2016'
        Break
      }
      Invoke-NicCheck
      
      if (Get-UacStatus){
        Write-Log -Type Warn -Message 'User Account Control (UAC) is enabled. That setting will cause issues installing OOS components programatically.' -NoConsole -Indent 1
        Write-Log -Type Warn -Message 'Prompting user to disable.' -NoConsole -Indent 1
        if ((New-Popup -Message 'User Account Control (UAC) is enabled. That setting will cause issues installing OOS components programatically. Would you like to disable it now (it can be re-enabled after installation)? If you opt NOT to disable UAC, this script will exit.' -Title 'Disable UAC' -Buttons 'YesNo' -Icon 'Question') -eq 6){
          Set-UacStatus -Enabled $false
        }else{
          Write-Log -Type Info -Message 'User opted NOT to disable UAC' -NoConsole -Indent 1
          Stop-Script
        }
      }else{
        Write-Log -Type Warn -Message 'UAC is already disabled' -NoConsole -Indent 1
      }
      Write-Log -Type Divider -NoConsole

      #region OWASprereqs
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      Invoke-WinSourceCheck
      if ($ValidWinSource){        
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatOwas").Replace(' ', ', '))" -NoConsole
        $WindowsFeatures = Add-WindowsFeature -Name $WinFeatOWAS -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
        $RestartNeeded = $WindowsFeatures.RestartNeeded        
        Invoke-RestartQuery
      } else {
        Write-Log -Type Error -message 'WindowsSource not valid' -NoConsole -Indent 1
        Write-Host $Win2012SourceWarning -ForegroundColor red
        Stop-Script
      }
      if (-not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }         
      #endregion OWASprereqs

      Install-DotNet        

      #region vc++
      if ((-not ($VC12PlusPlus)) -and (-not ($VC13PlusPlus)) -and (-not ($VC14PlusPlus))){
        Write-Log -Type Info -Message 'Installing Visual C++ 2013 runtime'
        New-FileDownload -SourceFile $URLvc12plusplus
        New-ProgramInstallation -InstallFile "$TargetFolder\$($URLvc12plusplus | Split-Path -leaf)" -InstallSwitches '/install /passive /norestart' -WaitForRegistryEntry "$UninstallKey\$GUIDvc12plusplus"
      }
      #endregion vc++

      #region IdentityModel
        Write-Log -Type Info -Message 'Checking if Identity Model Extensions are installed' -NoConsole
        if (-Not (Test-Path -Path "$UninstallKey\$GUIDIdentityModel")){
          Write-Log -Type Info -Message 'Identity Model Extensions are not installed' -NoConsole
          Write-Log -Type Info -Message 'Installing Identity Model Extensions' -NoConsole
          New-FileDownload -SourceFile $URLIdentityModel
          New-ProgramInstallation -InstallFile "$TargetFolder\$($URLIdentityModel | Split-Path -leaf)" -InstallSwitches '/qb'
        }
        #endregion IdentityModel

      #region OOSrtm
        Write-Log -Type Info -Message 'Checking if Office Online Server is already installed' -NoConsole
        if (-Not (Test-Path -Path "$UninstallKey\$GUIDwacimage")){
          # if (-Not (Test-Path -Path '$UninstallKey\{90150000-1151-0000-1000-0000000FF1CE}')){
          Write-Log -Type Info -Message 'Office Online Server is not installed' -NoConsole -Indent 1

          if (-Not (Test-Path -Path "$TargetFolder\$($URLwacimage | Split-Path -leaf)")){
              Write-Log -Type Warn -Message "Office Online Server is no longer available on the Microsoft Download Center. Please download the ISO file from your Volume License Account, and place it in $TargetFolder. To access the Volume Licensing Service Center, go to https://www.microsoft.com/licensing/servicecenter/"
          }

          if (Test-Path -Path "$TargetFolder\$($URLwacimage | Split-Path -leaf)"){
            Start-Sleep -Seconds 5
            Write-Log -Type Info -Message "Mounting $TargetFolder\$($URLwacimage | Split-Path -leaf)."
            Get-DiskImage -ImagePath "$TargetFolder\$($URLwacimage | Split-Path -leaf)" | Mount-DiskImage
            Write-Log -Type Info -Message 'Determining which drive is the mounted OOS image' -NoConsole -Indent 1
            $WACSource = (Get-DiskImage -ImagePath "$TargetFolder\$($URLwacimage | Split-Path -leaf)" | Get-Volume).DriveLetter + ':'
            Write-Log -Type Info -Message "Mounted OOS image is $WACSource" -NoConsole -Indent 1
            # short sleep period because sometimes the script was too fast, and the following code would fail because the computer wasn't done mounting the drive            
            Start-Sleep -Seconds 2
            if (Test-Path -Path $WACSource\setup.exe) {
              Write-Log -Type Info -Message 'OOS install path exists' -NoConsole -Indent 1
              Write-Log -Type Info -Message 'Installing Office Online Server'
              Start-Process -FilePath "$WACSource\setup.exe" -ArgumentList '/config files\setupsilent\config.xml'
              do {Invoke-Spinner} while (Get-Process -Name 'setup' -ErrorAction SilentlyContinue)
              Write-Host "`b `b" -NoNewline
              Write-Log -Type Info -Message "Dismounting $TargetFolder\$($URLwacimage | Split-Path -leaf) from $WACSource."
              Get-DiskImage -ImagePath "$TargetFolder\$($URLwacimage | Split-Path -leaf)" | Dismount-DiskImage
            }else{
              Write-Log -Type Error -Message "$WACSource\setup.exe does not exist. Unable to install Office Online Server" -Indent 1
            }
          }else{
            Write-Log -Type Error -Message "$TargetFolder\$($URLwacimage | Split-Path -leaf) does not exist. Unable to attempt installation." -Indent 1
          }
        } else {
          Write-Log -Type Warn -Message 'Office Online Server is already installed' -Indent 1
        }
        Write-Log -Type Divider -NoConsole
        #endregion OOSrtm
          
      #region OOSlangpack
        # Crazy error suppression method
        Write-Log -Type Info -Message 'Checking if Office Online Server is already installed' -NoConsole
        try {$IsOWAS = Get-OfficeWebAppsFarm} 
        catch [Management.Automation.CommandNotFoundException]{
          Write-Log -Type Error -Message 'Farm query failed. This is expected if the server is not part of an OOS farm.' -NoConsole -Indent 1
        }
        catch {
          # Write-Log -Type Error -Message "failed at $((Get-PSCallStack).ScriptLineNumber[0]) with `"$($_.Exception.Message)`'"
          Write-Log -Type Info -Message 'This server is not part of an Office Online Server Web Apps farm. This is expected' -NoConsole -Indent 1
        }
        if (-Not ($IsOWAS)){
          # We can probably clean this up a little. If we get to this point, OOS is installed (since it's part of a farm)
          # if (Test-Path -Path '$UninstallKey\{90150000-1151-0000-1000-0000000FF1CE}'){
          if (Test-Path -Path "$UninstallKey\{90160000-1151-0000-1000-0000000FF1CE}"){
            Write-Log -Type Info -Message 'Office Online Server is installed' -Indent 1 -NoConsole
            # http://www.microsoft.com/en-us/download/details.aspx?id=35490
              
            if (-Not (Test-Path -Path "$UninstallKey\$GUIDwacenglishlanguagepack")){
              Write-Log -Type Info -Message 'Prompting for the Engligh language pack' -NoConsole -Indent 1
              if ($IncludeLanguagePack -or ((New-Popup -Message 'Install the English language pack?' -Title 'English Language Pack' -Buttons YesNo -Icon Question) -eq 6)){
                Write-Log -Type Info -Message 'User chose to install English language pack' -NoConsole -Indent 2
                Write-Log -Type Info -Message 'Checking for Office Online Server Language Pack' -Indent 1
                Write-Log -Type Info -Message 'Office Online Server Language Pack is not installed.' -Indent 2
                New-FileDownload -SourceFile $URLwacenglishlanguagepack
                Write-Log -Type Info -Message 'Extracting language pack files' -Indent 1
                Start-Process -FilePath "$TargetFolder\$($URLwacenglishlanguagepack | Split-Path -leaf)" -ArgumentList "/extract:$TargetFolder\OWASLanguagePacks\English /quiet" -Wait
                Write-Log -Type Info -Message 'Installing language pack' -Indent 1
                Start-Process -FilePath "$TargetFolder\OWASLanguagePacks\English\setup.exe" -ArgumentList '/config files\setupsilent\config.xml'
                Do {Invoke-Spinner} while (Get-Process | Where-Object ProcessName -match 'setup')
                Write-Host "`b `b" -NoNewline
                #
                # Write-Log -Type Info -Message 'Stopping WACSM service' -NoConsole -Indent 1
                # Stop-Service WACSM
                # Write-Log -Type Info -Message 'Starting WACSM service' -NoConsole -Indent 1
                # Start-Service WACSM
                #
              } else {
                Write-Log -Type Info -Message 'User chose NOT to install English language pack.' -NoConsole -Indent 1
              }
            } else {
              Write-Log -Type Warn -Message 'Office Online Server Language Pack is already installed.' -Indent 1
            }
          }else{
            Write-Log -Type Error -Message 'Office Online Server not installed. Unable to attempt installation of Language Pack.' -Indent 1
          }
        }else{
          Write-Log -Type Error -Message "This server is already a member of farm $($IsOWAS.InternalUrl).host. It cannot be part of a farm while being updated."
        }
        Write-Log -Type Divider -NoConsole
        #endregion OOSlangpack
          
      #region OWAScu
      if ($URLwacCU){
        if (-Not ($IsOWAS)){
          $iso = "$($URLwacCU | Split-Path -leaf)"
          $kb = $iso.Substring(16,7)
          Write-Log -Type Info -Message 'Checking if Office Online Server is already installed' -NoConsole
          if (Test-Path -Path "$UninstallKey\$GUIDwacimage"){
            Write-Log -Type Info -Message 'Office Online Server is installed' -Indent 1 -NoConsole
            Write-Log -Type Info -Message "Checking for Office Online Server Update $kb"

            if (-Not (Test-Path -Path "$UninstallKey\$GUIDwacCU")){
              Write-Log -Type Info -Message "Office Online Server Update $kb is not installed." -Indent 1
              if (-Not (Test-Path -Path "$TargetFolder\$($URLwacCU | Split-Path -leaf)")){
                Write-Log -Type warn -Message 'This is a big file (1GB+) and can take several minutes.'
                New-FileDownload -SourceFile $URLwacCU -GetSize
              }
              Write-Log -Type Info -Message "Starting installation of Office Online Server Update $kb."
              Write-Log -Type Warn -Message 'This will take a while, during which it may appear like nothing is happening.' -Indent 1
              Start-Process -FilePath "$TargetFolder\$($URLwacCU | Split-Path -leaf)" -ArgumentList '/q'
              do {Invoke-Spinner} while (Get-Process -Name $([IO.FileInfo] ("$($URLwacCU | Split-Path -leaf)")).BaseName -ErrorAction SilentlyContinue)
              Write-Host "`b `b" -NoNewline
            } else {
              Write-Log -Type Warn -Message "Office Online Server Update $kb is already installed" -Indent 1
            }
          }else{
            Write-Log -Type Error -Message "Office Online Server not installed. Unable to attempt installation of update $kb." -Indent 1
          }
        }else{
            Write-Log -Type Error -Message "This server is already a member of farm $($IsOWAS.InternalUrl).host. It cannot be part of a farm while being updated."
        }
      }else{
        Write-Log -Type Warn -Message 'No OOS CU available. This is expected if a CU has not been released since the last full release of OOS'
      }
      Write-Log -Type Divider -NoConsole
      #endregion OWAScu
      Set-HighPower
      Set-AutoUpdateConfig
      # Set-NicPowerManagement -Disable
      Invoke-RestartQuery -NoRunonce
    } # end Office Online server
    6{ # Persistent Chat server
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Persistent Chat server)" -NoConsole
      Write-Log -Type Divider -NoConsole      
      
      if ($Skype4b2019){ # Persistent Chat role is deprecated in Skype for Business 2019      
        Write-Log -Type Warn -Message 'This role is not available for Skype for Business 2019'
        Break
      }      
      
      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLsqlexpress
        New-FileDownload -SourceFile $URLsqlmgmtstudio
        Break
      }
      
      if (-Not ($IsDomainMember)){
        Write-Log -Type Error -Message 'This server is not domain joined. Persistent Chat servers must be domain joined. Please domain join this server and try again.'
        Break
      }

      Invoke-NicCheck
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      Invoke-WinSourceCheck
      if ($ValidWinSource){        
        Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
        Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatPChat").Replace(' ', ', '))" -NoConsole
        $WindowsFeatures = Add-WindowsFeature -Name $WinFeatPChat -Source $WindowsSource\sources\sxs -WarningAction SilentlyContinue
        $RestartNeeded = $WindowsFeatures.RestartNeeded
        if (-Not ($WindowsFeatures.Success)){
          Write-Log -Type Error -Message $error
          Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
          Stop-Script
        }        
        Invoke-RestartQuery
      } else {
        Write-Log -Type Error -message 'WindowsSource not valid' -NoConsole -Indent 1
        Write-Host $Win2012SourceWarning -ForegroundColor red
        Stop-Script
      }
      if (($Skype4B -or $skype4b2019) -and (-Not ($IsSrv2016))){
        Install-Hotfix
      }
      if (-Not ($NoSQL)){
        New-SqlInstance -Instance RtcLocal
      }
      Install-SqlMgmtStudio
      Set-HighPower
      Set-AutoUpdateConfig
      # Set-NicPowerManagement -Disable
      Invoke-RestartQuery -NoRunonce
    } # end Persistent Chat server
    7{ # SCOM Watcher Node
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (SCOM Watcher Node)" -NoConsole
      Write-Log -Type Divider -NoConsole

      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLSkypeOnlineModule
        New-FileDownload -SourceFile $URLwatchernode
        Break
      }

      Invoke-NicCheck
      Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
      Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatWatcherNode").Replace(' ', ', '))" -NoConsole
      Set-ModuleStatus -Name ServerManager
      $WindowsFeatures = Add-WindowsFeature -Name $WinFeatWatcherNode -WarningAction SilentlyContinue
      $RestartNeeded = $WindowsFeatures.RestartNeeded
      if (-Not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }
      Invoke-RestartQuery
      Install-DotNet
      # TODO: Not sure why we download and install this...
      # We should detect if it's installed first.
      New-FileDownload -SourceFile $URLSkypeOnlineModule
      Write-Log -Type Warn -Message 'The installation of Skype Online Module may cause the server to restart. If it does, run the script again with the same option to finish.'
      New-ProgramInstallation -InstallFile "$TargetFolder\$($URLSkypeOnlineModule | Split-Path -leaf)" -InstallSwitches '/install /quiet /norestart' -WaitForProcessName $($URLSkypeOnlineModule | Split-Path -leaf).Substring(0,$($URLSkypeOnlineModule | Split-Path -leaf).Length -4)
      New-FileDownload -SourceFile $URLwatchernode
      Invoke-RestartQuery -NoRunonce
    } # end SCOM Watcher Node
    8{ # Application Request Routing (ARR) prerequisites (Pirate Proxy)
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Pirate Proxy)" -NoConsole
      Write-Log -Type Divider -NoConsole
            
      if ($DownloadOnly){
        Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
        New-FileDownload -SourceFile $URLWebPlatformInstaller
        Break
      }

      Invoke-NicCheck
      Write-Log -Type Info -Message 'Checking for domain membership' -NoConsole
      if ($IsDomainMember){
        Write-Log -Type Warn -Message 'This server is domain joined, which is not recommended for this role. Prompting user.' -Indent 1 -NoConsole
        if ((New-Popup -Message 'This server is domain joined. Domain membership for this role is not recommended. Do you wish to continue anyways?' -Title 'Domain membership' -Buttons YesNo) -eq 7){
          Write-Log -Type Info -Message 'User opted to NOT continue' -Indent 1 -NoConsole
          Stop-Script
        }else{
          Write-Log -Type Info -Message 'User opted to continue' -Indent 1 -NoConsole
        }
      }else{
        Write-Log -Type Info -Message 'Server is NOT domain joined' -NoConsole -Indent 1
        Set-PrimaryDnsSuffix
      }
      Write-Log -Type Divider -NoConsole
      
      New-FileDownload -SourceFile $URLWebPlatformInstaller
      Write-Log -Type Info -Message 'Installing operating system prerequisites' -NoLog
      Write-Log -Type Info -Message "Installing operating system prerequisites: $(("$WinFeatARR").Replace(' ', ', '))" -NoConsole
      Set-ModuleStatus -Name ServerManager
      Install-TelnetClient
      $WindowsFeatures = Add-WindowsFeature -Name $WinFeatARR -WarningAction SilentlyContinue
      $RestartNeeded = $WindowsFeatures.RestartNeeded      
      if (-Not ($WindowsFeatures.Success)){
        Write-Log -Type Error -Message $error
        Write-Log -Type Error -Message 'An error has occurred while installing Windows Features. Exiting.'
        Stop-Script
      }
      Set-HighPower
      Invoke-RestartQuery -NoRunonce
    } # end Application Request Routing (ARR) (Pirate Proxy)
    20{ # Microsoft apps and tools
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MSOption (Microsoft tools menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying Microsoft tools menu' -NoConsole
        $MSOption = Read-Host -Prompt $MSMenu
        switch ($MSOption) {
          1{ # Resource Kit Tools
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Resource Kit Tools)" -NoConsole
            if (-Not ($DownloadOnly)){        
              if ($lync2013){            
                Write-Log -Type Info -Message "Checking for `"Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727`"" -NoConsole
                # if (Get-ItemProperty "$UninstallKey\$GUIDvcplusplus2012" -ErrorAction SilentlyContinue){
                if ($VC12PlusPlus -ge '11.0.50727'){
                  Write-Log -Type Info -Message "`"Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727`" installed" -NoConsole
                  Write-Log -Type Info -Message "Checking for `"Lync Server 2013 Resource Kit Tools`""
                  if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUID2013resourcekit" -ErrorAction SilentlyContinue)){
                    Write-Log -Type Info -Message 'Resource kit not installed' -Indent 1
                    New-FileDownload -SourceFile $URLresourcekit
                    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLresourcekit | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Microsoft Lync Server 2013\ResKit\sefautil.exe"
                  } else {
                    Write-Log -Type Warn -message "`"Lync Server 2013 Resource Kit Tools`" already installed" -Indent 1
                  }
                } else {
                  Write-Log -Type Error -message "`"Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727`" not installed. This is common if Lync Server 2013 is not yet installed. Please install Lync Server and try this option again."
                }
              }elseif ($skype4b){
                Write-Log -Type Info -Message "Checking for `"Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.21005`"" -NoConsole
                if ($VC13PlusPlus -ge '12.0.21005'){
                  Write-Log -Type Info -Message "Version detected: $VC13PlusPlus"
                  Write-Log -Type Info -Message "Checking for `"Skype for Business Server 2015 Resource Kit Tools`""
                  if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUID2013resourcekit" -ErrorAction SilentlyContinue)){
                    Write-Log -Type Info -Message 'Resource kit not installed' -Indent 1
                    New-FileDownload -SourceFile $URLresourcekit
                    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLresourcekit | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Skype for Business Server 2015\ResKit\sefautil.exe"
                  } else {
                    Write-Log -Type Warn -message "`"Skype for Business Server 2015 Resource Kit Tools`" already installed" -Indent 1
                  }
                } else {
                  Write-Log -Type Error -message "`"Microsoft Visual C++ 2013 x64 Minimum Runtime - 12.0.21005`" not installed. This is common if Skype for Business Server 2015 is not yet installed. Please install Skype for Business Server 2015 and try this option again."
                }
              }elseif ($skype4b2019){
                Write-Log -Type Warn -Message 'This option is not available for Skype for Business Server 2019'
              }       
            }else{
              New-FileDownload -SourceFile $URLresourcekit
            }
          } # end Resource Kit Tools
          2{ # Persistent Chat Resource Kit
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Persistent Chat Resource Kit)" -NoConsole
            if ($Skype4b -or $skype4b2019){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            if (-Not ($DownloadOnly)){
              Write-Log -Type Info -Message "Checking if `"Lync Server 2013 Persistent Chat Resource Kit`" is installed" -NoConsole
               if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUID2013pchatresourcekit" -ErrorAction SilentlyContinue)){
                 Write-Log -Type Info -Message "`"Lync Server 2013 Persistent Chat Resource Kit`" is not installed" -NoConsole -Indent 1
                 New-FileDownload -SourceFile $URLpchatresourcekit
                 New-ProgramInstallation -InstallFile "$TargetFolder\$($URLpchatresourcekit | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Microsoft Lync Server 2013\Persistent Chat Server Resource Kit\AffCheck\affcheck.exe"
                } else {
                  Write-Log -Type Warn -message "`"Lync Server 2013 Persistent Chat Resource Kit Tools`" already installed" -Indent 1
                }
             }else{
               Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
               New-FileDownload -SourceFile $URLpchatresourcekit
            }            
          } # end Persistent Chat Resource Kit
          3{ # Debugging Tools
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Debugging Tools)" -NoConsole
            if (-Not ($DownloadOnly)){
              if ($lync2013){
                Write-Log -Type Info -Message "Checking for `"Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727`" (or later)" -NoConsole
                # if (Get-ItemProperty "$UninstallKey\$GUIDvcplusplus2012" -ErrorAction SilentlyContinue){
                if ($VC12PlusPlus -eq '11.0.50727'){
                  Write-Log -Type Info -Message 'Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727 (or later) is installed' -NoConsole
                  Write-Log -Type Info -Message "Checking for `"Lync Server 2013 Debugging Tools`"" -NoConsole
                  if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDdebuggingtools" -ErrorAction SilentlyContinue)){
                    Write-Log -Type Info -Message "`"Lync Server 2013 Debugging Tools`" not installed" -NoConsole -Indent 1
                    New-FileDownload -SourceFile $URLdebuggingtools
                    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLdebuggingtools | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe"
                    Set-PinnedApp -Pin -File "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe"
                    Add-PinnedAppToStartMenu -Pin -path "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe"
                  } else {
                    Write-Log -Type Warn -message "`"Lync Server 2013 Debugging Tools`" already installed" -Indent 1
                  }
                } else {
                  Write-Log -Type Error -Message "`"Microsoft Visual C++ 2012 x64 Minimum Runtime - 11.0.50727`" (or later) not installed. This is common if Lync Server 2013 is not yet installed. Please install Lync Server and try this options again." -Indent 1 -NoConsole
                  Write-Host $VisualCMissingError -ForegroundColor Red
                }
              }elseif ($skype4b){
                Write-Log -Type Info -Message "Checking for `"Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026.0`" (or later)" -NoConsole
                if ($VC15PlusPlus -lt '14.0.23026'){
                  # Write-Log -Type Info -Message 'Installing Visual C++ 2015' -Indent 1
                  New-FileDownload -SourceFile $URLvc15plusplus
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLvc15plusplus | Split-Path -leaf)" -InstallSwitches '/q' -WaitForProcessName 'vc_redist.x64'
                }
                # if ((Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum' -Name version -ErrorAction SilentlyContinue).version -ge '14.0.23026'){
                if ($VC15PlusPlus -ge '14.0.23026'){
                  Write-Log -Type Warn -Message "Version detected: $VC15PlusPlus" -NoConsole -Indent 1
                  Write-Log -Type Warn -Message 'Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026.0 (or later) is already installed' -NoConsole -Indent 1
                  Write-Log -Type Info -Message "Checking for `"Skype for Business Server 2015 Debugging Tools`"" -NoConsole
                  if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDdebuggingtools" -ErrorAction SilentlyContinue)){
                    Write-Log -Type Info -Message "`"Skype for Business Server 2015 Debugging Tools`" not installed" -NoConsole -Indent 1
                    New-FileDownload -SourceFile $URLdebuggingtools
                    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLdebuggingtools | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\clslogger.exe"
                    Set-PinnedApp -Pin -File "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\clslogger.exe"
                    Add-PinnedAppToStartMenu -Pin -Path "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\clslogger.exe"
                  } else {
                    Write-Log -Type Warn -Message "`"Skype for Business Server 2015 Debugging Tools`" already installed" -Indent 1
                  }
                }else{
                  Write-Log -Type Error -Message "`"Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026`" not installed. This is common if Skype for Business Server is not yet installed. Please install Skype for Business Server and try this options again." -Indent 1 -NoConsole
                  Write-Host $VisualC2013MissingError -ForegroundColor Red
                }
              }elseif ($skype4b2019){
                Write-Log -Type Info -Message "Checking for `"Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026.0`" (or later)" -NoConsole
                if ($VC15PlusPlus -lt '14.0.23026'){
                  # Write-Log -Type Info -Message 'Installing Visual C++ 2015' -Indent 1
                  New-FileDownload -SourceFile $URLvc15plusplus
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLvc15plusplus | Split-Path -leaf)" -InstallSwitches '/q' -WaitForProcessName 'vc_redist.x64'
                }
                # if ((Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum' -Name version -ErrorAction SilentlyContinue).version -ge '14.0.23026'){
                if ($VC15PlusPlus -ge '14.0.23026'){
                  Write-Log -Type Warn -Message "Version detected: $VC15PlusPlus" -NoConsole -Indent 1
                  Write-Log -Type Warn -Message 'Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026.0 (or later) is already installed' -NoConsole -Indent 1
                  Write-Log -Type Info -Message "Checking for `"Skype for Business Server 2019 Debugging Tools`"" -NoConsole
                  if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDdebuggingtools" -ErrorAction SilentlyContinue)){
                    Write-Log -Type Info -Message "`"Skype for Business Server 2019 Debugging Tools`" not installed" -NoConsole -Indent 1
                    New-FileDownload -SourceFile $URLdebuggingtools
                    New-ProgramInstallation -InstallFile "$TargetFolder\$($URLdebuggingtools | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForPath "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\clslogger.exe"
                    Set-PinnedApp -Pin -File "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\clslogger.exe"
                    Add-PinnedAppToStartMenu -Pin -Path "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\clslogger.exe"
                  } else {
                    Write-Log -Type Warn -Message "`"Skype for Business Server 2019 Debugging Tools`" already installed" -Indent 1
                  }
                }else{
                  Write-Log -Type Error -Message "`"Microsoft Visual C++ 2015 x64 Minimum Runtime - 14.0.23026`" not installed. This is common if Skype for Business Server is not yet installed. Please install Skype for Business Server and try this options again." -Indent 1 -NoConsole
                  Write-Host $VisualC2013MissingError -ForegroundColor Red
                }
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLdebuggingtools
            }
          } # end Debugging Tools
          4{ # Stress and Performance Tool
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Stress and Performance Tool)" -NoConsole
            if ($skype4b2019){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business Server 2019'
              Break
            }
            if (-Not ($DownloadOnly)){
              if (-Not ($Skype4b)){
                Write-Log -Type Info -Message "Checking if `"Lync Server 2013 Stress and Performance Tool`" is installed" -NoConsole
                if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDstressperformancetool" -ErrorAction SilentlyContinue)){
                  Write-Log -Type Info -Message "`"Lync Server 2013 Stress and Performance Tool`" not installed" -NoConsole -Indent 1
                  New-FileDownload -SourceFile $URLstressandperformancetool
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForRegistryEntry "$UninstallKey\$GUIDstressperformancetool" -WaitForProcessName "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)"
                } else {
                  Write-Log -Type Warn -Message "`"Lync Server 2013 Stress and Performance Tool`" already installed" -Indent 1
                }
              }else{
                Write-Log -Type Info -Message "Checking if `"Skype for Business Server 2015 Stress and Performance Tool`" is installed" -NoConsole
                if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDstressperformancetool" -ErrorAction SilentlyContinue)){
                  Write-Log -Type Info -Message "`"Skype for Business Server 2015 Stress and Performance Tool`" not installed" -NoConsole -Indent 1
                  New-FileDownload -SourceFile $URLstressandperformancetool
                  # New-ProgramInstallation -InstallFile "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)" -InstallSwitches "/qb" -WaitForRegistryEntry "$UninstallKey\$GUIDstressperformancetool" -WaitForProcessName "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)"
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLstressandperformancetool | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForRegistryEntry "$UninstallKey\$GUIDstressperformancetool"
                } else {
                  Write-Log -Type Warn -Message "`"Skype for Business Server 2015 Stress and Performance Tool`" already installed" -Indent 1
                }
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLstressandperformancetool
            }
          } # end Stress and Performance Tool
          5{ # Best Practices Analyzer
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Best Practices Analyzer)" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            if (-Not ($DownloadOnly)){
              Write-Log -Type Info -Message "Checking if `"Lync Server 2013 Best Practices Analyzer`" is installed" -NoConsole
              if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUID2013bpa" -ErrorAction SilentlyContinue)){
                Write-Log -Type Info -Message "`"Lync Server 2013 Best Practices Analyzer`" not installed" -NoConsole -Indent 1
                New-FileDownload -SourceFile $URLbpa
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLbpa | Split-Path -leaf)" -InstallSwitches '/qb' -WaitForProcessName 'rtcbpa.msi'
              } else {
                Write-Log -Type Warn -Message "`"Lync Server 2013 Best Practices Analyzer`" already installed" -Indent 1
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLbpa
            }
          } # end Best Practices Analyzer
          6{ # Lync Connectivity Analyzer
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Lync Connectivity Analyzer)" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            if (-Not ($DownloadOnly)){
              Write-Log -Type Info -Message 'Checking for .Net 4.5' -NoConsole
              if ((Get-WindowsFeature -Name NET-Framework-45-Core).Installed){
                Write-Log -Type Info -Message '.Net 4.5 installed' -NoConsole -Indent 1
                Write-Log -Type Info -Message "Checking if `"Lync Connectivity Analyzer`" is installed" -NoConsole
                if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUID2013connectivityanalyzer" -ErrorAction SilentlyContinue)){
                  Write-Log -Type Info -Message "`"Lync Connectivity Analyzer`" is not installed" -NoConsole -Indent 1
                  New-FileDownload -SourceFile $URLconnectivityanalyzer
                  Add-Type -AssemblyName 'system.io.compression.filesystem'
                  # [IO.Compression.ZipFile]::ExtractToDirectory("$TargetFolder\$($URLconnectivityanalyzer | Split-Path -leaf)", $TargetFolder) | Out-Null
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLconnectivityanalyzer | Split-Path -leaf)" -InstallSwitches '/qb'
                  # New-ProgramInstallation -InstallFile "$TargetFolder\LyncConnectivityAnalyzer-64bit.msi" -InstallSwitches '/qb'
                } else {
                  Write-Log -Type Warn -Message "`"Lync Server Connectivity Analzer`" is already installed" -Indent 1
                }
              } else {
                Write-Log -Type Warn -Message '.Net 4.5 not installed. Please try this option again after Lync Server is installed'
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLconnectivityanalyzer
            }
          } # end Lync Connectivity Analyzer
          7{ # Microsoft Message Analyzer (formerly NetMon)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Install Microsoft Message Analyzer)" -NoConsole
            if (-Not ($DownloadOnly)){
              Write-Log -Type Info -Message "Checking if `"Microsoft Message Analyzer`" is installed" -NoConsole
              if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDMessageAnalyzer" -ErrorAction SilentlyContinue)){
                Write-Log -Type Info -Message "`"Microsoft Message Analyzer`" is not installed" -NoConsole
                New-FileDownload -SourceFile $URLmessageanalyzer
                New-FileDownload -SourceFile $URLmessageanalyzerknownissuesdoc
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLmessageanalyzer | Split-Path -leaf)" -InstallSwitches '/q' -WaitForRegistryEntry "$UninstallKey\$GUIDMessageAnalyzer" -ReallyLongInstall
              } else {
                Write-Log -Type Warn -Message "`"Microsoft Message Analyzer`" already installed" -Indent 1
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLmessageanalyzer
              New-FileDownload -SourceFile $URLmessageanalyzerknownissuesdoc
              # New-FileDownload $URLmessageanalyzeroperatingguidedoc
            }
          } # end Microsoft Message Analyzer (formerly NetMon)
          8{ # SQL Server Management Studio
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (SQL Server Management Studio)" -NoConsole
            if (-Not ($DownloadOnly)){
              $IncludeSSMS = $true
              Install-SqlMgmtStudio
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLsqlmgmtstudio
            }
          } # end SQL Server Management Studio
          9{ # Network Assessment Tool
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (Network Assessment Tool)" -NoConsole
            if (-Not ($DownloadOnly)){
              Write-Log -Type Info -Message "Checking if `"Network Assessment Tool`" is installed" -NoConsole
              if (-Not (Get-ItemProperty -Path "$UninstallKey\$GUIDNetworkAssessmentTool" -ErrorAction SilentlyContinue)){
                Write-Log -Type Info -Message "`"Network Assessment Tool`" is not installed" -NoConsole
                New-FileDownload -SourceFile $URLNetworkAssessmentTool
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLNetworkAssessmentTool | Split-Path -leaf)" -InstallSwitches '/q' -WaitForRegistryEntry "$UninstallKey\$GUIDNetworkAssessmentTool"
                # Set-PinnedApp -File "$env:ProgramFiles\Microsoft Skype for Business Network Assessment Tool\NetworkAssessmentTool.exe" -Pin
              } else {
                Write-Log -Type Warn -Message "`"Network Assessment Tool`" already installed" -Indent 1
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLNetworkAssessmentTool
            }
          } # end Network Assessment Tool
          10{ # .NET Framework
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MSOption (.NET Framework)" -NoConsole
            if (-Not ($DownloadOnly)){
              Install-DotNet
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLdotnet
            }          
          } # end .NET Framework          
        } # end switch
      } while ($MSOption -NotMatch {^99$|^x$|^exit$})
    } # end Microsoft tools menu
    30{ # Third Party Apps
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $ThirdPartyOption (Third party menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying Third Party menu' -NoConsole
        $ThirdPartyOption = Read-Host -Prompt $ThirdPartyMenu
        switch ($ThirdPartyOption) {
          1{ # WireShark
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ThirdPartyOption (Wireshark)" -NoConsole
            if (-Not ($DownloadOnly)){
              if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Wireshark' -ErrorAction SilentlyContinue)){
                New-FileDownload -SourceFile $URLwireshark
                New-FileDownload -SourceFile $URLwiresharkInstall
                New-FileDownload -SourceFile $URLwiresharkConfig
                if ((Test-Path -Path "$TargetFolder\$($URLwiresharkInstall | Split-Path -leaf)") -and (Test-Path -Path "$TargetFolder\$($URLwireshark | Split-Path -leaf)")){
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLwiresharkInstall | Split-Path -leaf)" -WaitForProcessName $([IO.FileInfo] ("$TargetFolder\$($URLwiresharkInstall | Split-Path -leaf)")).BaseName
                  Write-Log -Type Info -Message 'Waiting for installation to finish' -Indent 1
                  # do {Start-Sleep -Seconds 1} while (-Not ((Get-ItemProperty 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Wireshark' -ErrorAction SilentlyContinue) -and (Get-ItemProperty 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\WinPcapInst' -ErrorAction SilentlyContinue)) -or (Get-Process WinPcap* -ErrorAction SilentlyContinue) -or (Get-Process Wireshark-win64* -ErrorAction SilentlyContinue))                  
                  Invoke-RestartQuery
                }else{
                  Write-Log -Type Error -Message 'WireShark .exe or install macro file missing. Unable to install.'
                }
                if ((Test-Path -Path $TargetFolder\$($URLwiresharkConfig | Split-Path -leaf)) -and (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Wireshark' -ErrorAction SilentlyContinue)){
                  Write-Log -Type Info -Message 'Beginning configuration of Wireshark for Lync/SfB' -NoConsole
                  New-ProgramInstallation -InstallFile "$TargetFolder\$($URLwiresharkConfig | Split-Path -leaf)" -WaitForProcessName $([IO.FileInfo] ("$TargetFolder\$($URLwiresharkConfig | Split-Path -leaf)")).BaseName
                }else{
                  Write-Log -Type Error -Message "$TargetFolder\$($URLwiresharkConfig | Split-Path -leaf) does not exist or WireShark is not installed. Unable to configure WireShark."
                }
              } else {
                $InstalledWireshark = $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Wireshark' -ErrorAction SilentlyContinue).DisplayVersion
                Write-Log -Type Warn -Message "`"Wireshark`" $InstalledWireshark is already installed" -Indent 1
              }
              Write-Log -Type Info -Message 'Prompting for Lync/Skype for Business plug-in for Wireshark' -NoConsole -Indent 1
              if ((New-Popup -Message 'Install Lync/Skype for Business plug-in for Wireshark? This is helpful on edge servers for decrypting Ice/STUN/TURN info.' -Title 'Lync plug-in for Wireshark' -Buttons YesNo -Icon Question) -eq 6){
                Write-Log -Type Info -Message 'User accepted installation of the Lync plug-in for Wireshark' -NoConsole -Indent 1
                [string] $WiresharkPlugInPath = (Get-ChildItem -Path "$env:ProgramFiles\Wireshark\plugins" -Directory -ErrorAction SilentlyContinue | Select-Object -First 1).name
                if ($WiresharkPlugInPath){
                  if (-Not (Test-Path -Path "$env:ProgramFiles\Wireshark\plugins\$WiresharkPlugInPath\$($URLwiresharkPlugin | Split-Path -leaf)")){
                    Write-Log -Type Info -Message 'Downloading the Lync/Skype for Business plug-in for Wireshark' -NoConsole -Indent 1
                    New-FileDownload -SourceFile $URLwiresharkPlugin -DestFolder "$env:ProgramFiles\Wireshark\plugins\$WiresharkPlugInPath"
                  }else{
                    Write-Log -Type Warn -Message 'Lync/Skype for Business plug-in for Wireshark already exists' -Indent 1
                  }
                }else{
                  Write-Log -Type Error -Message 'Wireshark plug-in path not found' -Indent 1
                }
              }

              if ((New-Popup -Message 'Create taskbar shortcut for Wireshark?' -Title 'Taskbar Shortcut for Wireshark' -Buttons YesNo -Icon Question) -eq 6){
                Write-Log -Type Info -Message 'User accepted creating a taskbar shortcut for WireShark.' -NoConsole -Indent 1
                if (Test-Path -Path "$env:ProgramFiles\Wireshark\Wireshark-gtk.exe"){
                  Set-PinnedApp -File "$env:ProgramFiles\Wireshark\Wireshark-gtk.exe" -Pin
                }
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLwireshark
              New-FileDownload -SourceFile $URLwiresharkInstall
              New-FileDownload -SourceFile $URLwiresharkConfig
              New-FileDownload -SourceFile $URLwiresharkPlugin
            }
          } # end WireShark
          2{ # Customized PortQryUI
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ThirdPartyOption (Customized PortQryUI)" -NoConsole
            if (-Not ($DownloadOnly)){
              Set-ModuleStatus -Name ServerManager
              Write-Log -Type Info -Message 'Checking for .Net 4.5' -NoConsole
              if ((Get-WindowsFeature -Name NET-Framework-45-Core).Installed){
                Write-Log -Type Info -Message '.Net 4.5 installed' -NoConsole -Indent 1
                Push-Location
                New-FileDownload -SourceFile $URLportqry
                [string]$InstallPath = "$env:ProgramFiles\PortQryUI"
                Set-Location -Path $TargetFolder
                Write-Log -Type Info -Message 'Unzipping first file' -NoConsole
                .\PortQryUI.exe /Q /T:$InstallPath /C
                Start-Sleep -Seconds 2
                Set-Location -Path $InstallPath          
                Write-Log -Type Info -Message 'Unzipping second file' -NoConsole
                .\PORTQR~1.EXE /auto $InstallPath
                Start-Sleep -Seconds 2          
                if (Test-Path -Path PORTQR~1.EXE){
                  Write-Log -Type Info -Message 'Deleting PORTQR~1.exe' -NoConsole
                  Remove-Item -Path PORTQR~1.EXE -Force
                }
                if (Test-Path -Path $InstallPath\portqueryui.exe){
                  New-Shortcut -Name "$env:public\Desktop\PortQryUI.lnk" -File "$InstallPath\portqueryui.exe" -WorkingDir "$InstallPath" -Description 'PortQryUI'
                }
                New-FileDownload -SourceFile $URLportqryconfig -DestFolder "$InstallPath"
                if (-Not (Test-Path -Path 'config.xml.old')){
                  Write-Log -Type Info -Message "Renaming 'config.xml' to 'config.xml.old' as a backup" -NoConsole
                  Rename-Item -Path 'config.xml' -NewName 'config.xml.old'
                } else {
                  Write-Log -Type Info -Message "Removing 'config.xml' since 'config.xml.old' already exists" -NoConsole
                  Remove-Item -Path config.xml
                }
                Write-Log -Type Info -Message 'Unzipping file' -NoConsole
                Add-Type -AssemblyName 'System.Io.Compression.Filesystem'
                [IO.Compression.ZipFile]::ExtractToDirectory("$InstallPath\$($URLportqryconfig | Split-Path -leaf)", $InstallPath) | Out-Null
                if (Test-Path -Path "$InstallPath\config.xml"){
                  Write-Log -Type Info -Message 'Finished unzipping file' -NoConsole
                }
                Start-Sleep -Seconds 2
                Pop-Location
              } else {
                Write-Log -Type warn -Message '.Net 4.5 not installed. Please try this option again after Lync Server is installed'
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLportqry
              New-FileDownload -SourceFile $URLportqryconfig
            }
          } # end Customized PortQryUI
        } # end switch
      } while ($ThirdPartyOption -NotMatch {^99$|^x$|^exit$})
    } # end Third Party Apps menu
    40{ # Reports and info
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Misc reports menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying Reports menu' -NoConsole
        $ReportsOption = Read-Host -Prompt $ReportsMenu
        switch ($ReportsOption) {
          1{ # AD disabled accounts that are still enabled in Lync/SfB
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ReportsOption (AD disabled accounts that are still enabled in Lync/SfB)" -NoConsole
            $EnabledUsers = Get-CsAdUser -ResultSize Unlimited | Where-Object {$_.UserAccountControl -match 'AccountDisabled' -and $_.Enabled -eq $true} | Sort-Object -Property Name | Select-Object -Property Name,Enabled,SipAddress
            if ($EnabledUsers){
              Write-Log -Type Warn -Message 'The following users are disabled for Active Directory, but are still enabled for Lync/Skype for Business. Due to the certificate based authentication method used in Lync/Skype for Business, these users could theoretically still login to Lync/Skype for Business. It is advised these users be disabled in Lync/Skype for Business, and their certificate revoked.' -Indent 1
              Write-Output -InputObject $EnabledUsers | Format-Table -AutoSize
            }else{
              Write-Log -Type Info -Message 'No users found that are disabled in Active Directory and enabled in Lync/Skype for Business.'
            }
          } # end AD disabled accounts that are still enabled in Lync/SfB
          2{ # Elevated accounts that are enabled in Lync/SfB
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ReportsOption (Elevated accounts that are enabled in Lync/SfB)" -NoConsole
            # need to check for nested members: https://redmondmag.com/articles/2016/03/15/nested-active-directory-group-memberships.aspx
            $EnabledUsers = (Get-ADGroupMember -Identity 'Domain Admins').DistinguishedName | Get-CsUser -ErrorAction SilentlyContinue | Sort-Object -Property DisplayName | Format-Table -Property DisplayName,SipAddress
            if ($EnabledUsers){
              Write-Log -Type Warn -Message 'The following users are enabled for Lync/Skype for Business, but are a member of Domain Admins, and elevated group. Administration of these users must also be performed by a member of an elevated group to avoid errors, including access problems.' -Indent 1
              Write-Output -InputObject $EnabledUsers | Format-Table -AutoSize
            }else{
              Write-Log -Type Info -Message 'No users found that are members of the Domain Admins group and enabled in Lync/Skype for Business.'
            }
          } # end Elevated accounts that are enabled in Lync/SfB
          3{ # Users whose SMTP address does not match their SIP address
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ReportsOption (Find users whose SMTP address does not match their SIP address)" -NoConsole
            $EnabledUsers = Get-CsAdUser | Where-Object {($_.WindowsEmailAddress -and $_.SipAddress) -and ($_.WindowsEmailAddress -ne ($_.SipAddress -replace 'sip:',''))} | Sort-Object -Property DisplayName | Select-Object -Property DisplayName,WindowsEmailAddress,@{Expression={$_.sipaddress -replace 'sip:'};label='SipAddress'}
            if ($EnabledUsers){
              Write-Log -Type Warn -Message 'The following users have SMTP addresses that do not match their SIP addresses. This can be problematic for some features in Lync/Skype for Business.' -Indent 1
              Write-Output -InputObject $EnabledUsers | Format-Table -AutoSize
            }else{
              Write-Log -Type Info -Message 'No users found that have SMTP addresses different from their SIP address.'
            }
          } # end Users whose SMTP address does not match their SIP address
          4{ # Empty response groups
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ReportsOption (Empty response groups)" -NoConsole
            Get-CsRgsAgentGroup | Where-Object {($_.agentsbyuri).count -eq 0}
          } # end Empty response groups
          5{ # Check group membership
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Check group membership)" -NoConsole
            Write-Log -Type Divider -NoConsole
            # Get-ADPrincipalGroupMembership -Identity $env:UserName | Sort-Object -Property SamAccountName | Format-Table -Property SamAccountName
            $Groups = [Security.Principal.WindowsIdentity]::GetCurrent().Groups
            $stuff = @()
            foreach ($Group in $Groups) {
              if ($group.value){
                $GroupSID = $Group.Value
                $GroupName = New-Object -TypeName System.Security.Principal.SecurityIdentifier -ArgumentList ($GroupSID)
                $GroupDisplayName = $GroupName.Translate([Security.Principal.NTAccount])
              }
              [object] $AllMyGroups = $GroupDisplayName | Where-Object {$_.Value -match 'admin'}
              $stuff +=$AllMyGroups
            }
            Write-Output -InputObject "`nYou are a member of the following admin groups:`n$(($stuff | Sort-Object) -join "`n")"
          } # end Check group membership
        } # end switch
      } while ($ReportsOption -NotMatch {^99$|^x$|^exit$})
    } # end Reports and info menu
    50{ # Misc server config menu
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Misc server config menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying Misc server config menu' -NoConsole
        $ServerConfigOption = Read-Host -Prompt $ServerConfigMenu
        switch ($ServerConfigOption) {
          1{ # Lync Server 2013 documentation help
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Lync Server 2013 documentation help)" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            if (-Not ($DownloadOnly)){
              New-FileDownload -SourceFile $URLchm -IgnoreLocalCopy
              New-ProgramInstallation -InstallFile "$TargetFolder\$($URLchm | Split-Path -leaf)" -InstallSwitches "/auto 'C:\Program Files\Microsoft Lync Server 2013\Documentation'"
              if (Test-Path -Path "$TargetFolder\$($URLchm | Split-Path -leaf)"){
                # We need to use the following method to avoid an error
                Do {Invoke-Spinner} while (Get-Process | Where-Object ProcessName -Match 'LyncServer2013_ITPro')
                Write-Host "`b `b" -NoNewline
                New-Shortcut -Name "$env:public\Desktop\Lync Server 2013 Help Documentation.lnk" -File "$env:ProgramFiles\Microsoft Lync Server 2013\Documentation\LyncServer2013_ITPro.chm" -WorkingDir "$env:ProgramFiles\Microsoft Lync Server 2013\Documentation" -Description 'Lync Server 2013 Help Documentation'
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLchm -IgnoreLocalCopy
            }
          } # end Lync Server 2013 documentation help
          2{ # PowerShell Update-Help scheduled task
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (PowerShell Update-Help scheduled task)" -NoConsole
            New-PsUpdateHelpScheduledTask
          } # end PowerShell Update-Help scheduled task
          3{ # Install Telnet client
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Install Telnet client)" -NoConsole
            Install-TelnetClient -IgnorePrompt
          } # end Install Telnet client
          4{ # Disable auto updates
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Disable auto update)" -NoConsole
            Set-AutoUpdateConfig -IgnorePrompt
          } # end Disable auto updates
          5{ # Set recovery of SfB/Lync/OOS services to restart
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Set recovery of Skype for Business/Lync/OOS services to restart)" -NoConsole
            $services = Get-CimInstance -ClassName 'Win32_Service' | Where-Object {$_.Description -imatch 'Skype for Business|Lync' -or $_.Name -imatch 'WACSM|StatsManPerfAgent' -and $_.StartMode -eq 'Auto'}
            
            if ($services){
              Foreach ($service in $services){
                # the space after the equals signs is CRITICAL
                # double slash means to take no action
                # sc.exe failure $service.name reset= 86400 actions= restart/5000
                Write-Log -Type Info -Message "Configuring `'$service.name`'"
                & "$env:windir\system32\sc.exe" failure $($service.name) reset= 86400 actions= restart/5000/restart/5000//
              }
            }            
          } # end Set recovery of Lync/OWAS services to restart
          6{ # Set fabric logging to circular
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Enable fabric log circular logging)" -NoConsole
            # TODO: Validate what versions this is good for.
            if ((($env:FabricDataRoot) -and (Test-Path -Path "$env:FabricDataRoot\Fabric\log\Traces")) -or ((Test-Path -Path "$UninstallKey\{C610AAA3-9C21-45BF-A705-F7309B8262D2}") -and (Test-Path -Path "$UninstallKey\{21BE08F9-CAF1-4168-B58B-45594921DFC7}"))){
              Write-Log -Type Info -Message 'Setting circular logging' -NoConsole -Indent 1
              logman update trace FabricLeaseLayerTraces -f bincirc --cnf | Out-Null
              if ($LastExitCode -eq 0){
                Write-Log -Type Info -Message 'Completed setting circular logging for fabric traces' -NoConsole -Indent 1
              }else{
                Write-Log -Type Error -Message "Error $LastExitCode occurred setting circular logging for fabric traces" -Indent 1
              }
            }else{
              if (-Not ($lync2013)){
                Write-Log -Type Warn -Message 'This server does not have Windows Fabric installed. It does not appear to be an Enterprise Edition Front End server. If Skype for Business is not yet installed, please try this option after installation is completed.'
              }else{
                Write-Log -Type Warn -Message 'This server does not have Windows Fabric installed. It does not appear to be an Enterprise Edition Front End server. If Lync is not yet installed, please try this option after installation is completed.'
              }
            }
          } # end Set fabric logging to circular
          7{ # Disable Server Manager on logon
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Disable Server Manager on logon)" -NoConsole
            Write-Log -Type Info -Message 'Disabling Server Manager for all users' -NoConsole -Indent 1
            Set-ItemProperty -path 'HKLM:\Software\Microsoft\ServerManager' -Name DoNotOpenServerManagerAtLogon -Value 1
            Write-Log -Type Info -Message 'Disabling Server Manager for current user' -NoConsole -Indent 1
            Set-ItemProperty -path 'HKCU:\Software\Microsoft\ServerManager' -Name CheckedUnattendLaunchSetting -Value 0
            Set-ItemProperty -path 'HKCU:\Software\Microsoft\ServerManager' -Name DoNotOpenServerManagerAtLogon -Value 1
          } # end Disable Server Manager on logon
          8{ # Upgrade to PowerShell v4
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Upgrade to PowerShell v4.0)" -NoConsole
            if (-Not ($DownloadOnly)){
              if ($psversiontable.psversion.major -lt 4.0){
                New-FileDownload -SourceFile $URLpowershell4releasenotes
                New-FileDownload -SourceFile $URLpowershell4dscquickpdf
                New-FileDownload -SourceFile $URLpowershell4dscquickpptx
                New-FileDownload -SourceFile $URLpowershell4
                Write-Log -Type Info -Message 'Installing operating system prerequisites'
                Set-ModuleStatus -name ServerManager
                $RestartNeeded = (Add-WindowsFeature -Name $WinFeatPowerShell4).RestartNeeded
                if ($RestartNeeded -eq 'Yes'){
                  Write-Log -Type Warn -Message 'Restart is required' -NoConsole -Indent 1
                  if ((New-Popup -Message $PrereqRebootPromptWarning -Title 'Restart is required' -Buttons YesNo -Icon Question) -eq 6){
                    Write-Log -Type Info -Message 'User chose to reboot' -NoConsole -Indent 1
                    Write-Log -Type Info -Message 'Setting registry entry' -NoConsole -Indent 1
                    Set-RunOnce
                    Stop-Script -Reboot
                  } else {
                    Write-Log -Type Warn -Message 'User chose NOT to reboot' -NoConsole
                    Stop-Script
                  }
                } else {
                  Write-Log -Type Info -Message 'Restart is NOT required' -NoConsole -Indent 1
                }
                Write-Log -Type Info -Message 'Beginning installation of PowerShell 4' -NoConsole
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLpowershell4 | Split-Path -leaf)" -InstallSwitches '/quiet /norestart' -WaitForProcessName 'wusa' -LongInstall
                $RestartRequired = $true
                if ((New-Popup -Message $PrereqRebootPromptWarning -Title 'Restart is required' -Buttons YesNo -Icon Question) -eq 6){
                  Write-Log -Type Info -Message 'User chose to reboot' -NoConsole
                  Stop-Script -Reboot
                } else {
                  Write-Log -Type Warn -Message 'User chose NOT to reboot' -NoConsole
                  Stop-Script
                }
              }else{
                Write-Log -Type Warn -Message 'PowerShell version on this server is already at or above 4.0'
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLpowershell4releasenotes
              New-FileDownload -SourceFile $URLpowershell4dscquickpdf
              New-FileDownload -SourceFile $URLpowershell4dscquickpptx
              New-FileDownload -SourceFile $URLpowershell4
            }
          } # end Upgrade to PowerShell v4
          9{ # Fix Control Panel font
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Fix Control Panel font)" -NoConsole
            if ($Skype4b -or $skype4b2019){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            Set-ItemProperty -path 'HKCU:\Software\Microsoft\Internet Explorer\International\Scripts\3' -Name IEPropFontName -Value 'Segoe UI'            
          } # end Fix Control Panel font
          10{ # Set Power Plan
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Set power plan)" -NoConsole
            Set-PowerPlan -PreferredPlan 'High Performance'
          } # end Set Power Plan
          11{ # Edit hosts file
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Edit hosts file)" -NoConsole
            Start-Process -FilePath $env:SystemRoot\system32\notepad.exe -ArgumentList "$env:SystemRoot\system32\drivers\etc\hosts" -Verb runas
          } # end Edit hosts file
          12{ # Configure static routing (edge and ARR)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Configure edge routing)" -NoConsole
            Set-NicConfig
          } # end Configure static routing (edge and ARR)
          13{ # Configure primary DNS suffix (edge and ARR)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Configure primary DNS suffix)" -NoConsole
            Set-PrimaryDnsSuffix
          } # end Configure primary DNS suffix (edge and ARR)
          14{ # Lync/SfB Online Admin components
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Skype for Business Online Admin components)" -NoConsole
            Install-CsOnlineAdminTools -NoPrompt
          } # end Lync/SfB Online Admin components
          15{ # Enable Photo URL option
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Enable Photo URL option)" -NoConsole
            Set-ModuleStatus -name Lync
            if (((Get-CsClientPolicy -identity Global).PolicyEntry).name -eq 'EnablePresencePhotoOptions'){
              Write-Log -Type Warn -Message 'Policy entry already exists'
            } else {
              Write-Log -Type Warn -Message 'Policy entry does not already exist'
              # http://blogs.technet.com/b/lync/archive/2013/11/12/november-2013-update-for-the-lync-2013-desktop-client.aspx
              # does not work on Office 365
              $error.clear()
              $PolicyEntry = New-CsClientPolicyEntry -Name EnablePresencePhotoOptions -Value True
              $PolicyObject = Get-CsClientPolicy -Identity Global
              $PolicyObject.PolicyEntry.Add($PolicyEntry)
              Set-CsClientPolicy -Instance $PolicyObject
            }
          } # end Enable Photo URL option
          16{ # Lync Room System (LRS) Admin Portal
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Lync Room System Admin Portal)" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            if (-Not ($DownloadOnly)){
              if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{942CC691-5B98-42A3-8BC5-A246BA69D983}' -ErrorAction SilentlyContinue)){
                New-FileDownload -SourceFile $URLaspnetmvc4
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLaspnetmvc4 | Split-Path -leaf)" -InstallSwitches '/q' -WaitForRegistryEntry "$UninstallKey\{942CC691-5B98-42A3-8BC5-A246BA69D983}"
                # reboot required?
              } else {
                Write-Log -Type Warn -message "`"AspNetMVC4Setup`" is already installed" -Indent 1
              }
              New-FileDownload -SourceFile $URLlrsadminportal
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLlrsadminportal
            }
          } # end Lync Room System (LRS) Admin Portal
          17{ # Add scheduler URL to simple URLs
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Add scheduler URL to simple URLs)" -NoConsole
            if (Set-ModuleStatus -name Lync){
              Write-Log -Type Info -Message 'Prompting user for URL' -NoConsole
              do {$schedulerURL = Read-Host -Prompt "Enter scheduler URL including 'https://' such as 'https://scheduler.contoso.com'"} while ($schedulerURL -NotMatch 'https://')
              Write-Log -Type Info -Message "User specified $schedulerURL" -NoConsole
              Write-Log -Type Info -Message "Validating $schedulerURL" -NoConsole
              if (Test-IsUriWeb -address $schedulerURL){
                Write-Log -Type Info -Message 'URL is valid' -NoConsole
                Write-Log -Type Info -Message 'Creating New-CsSimpleUrlEntry' -NoConsole
                $urlEntry = New-CsSimpleUrlEntry -Url $schedulerURL
                Write-Log -Type Info -Message 'Creating New-CsSimpleUrl' -NoConsole
                $simpleUrl = New-CsSimpleUrl -Component 'WebScheduler' -Domain '*' -SimpleUrlEntry $urlEntry -ActiveUrl $schedulerURL
                Write-Log -Type Info -Message 'Setting CsSImpleUrlConfiguration' -NoConsole
                Set-CsSimpleUrlConfiguration -SimpleUrl @{Add=$simpleUrl} -Verbose
                Write-Log -Type warn -message 'IMPORTANT: Make sure when creating certificate requests for front end servers and reverse proxies that you include this FQDN in Subject Alternative Names'
              } else {
                Write-Log -Type Error -message 'Scheduler URL is not a valid URL'
              }
            } else {
              Write-Log -Type Error -message 'Could not load module. Either Lync is not installed, or there is a problem.'
            }
          } # end Add scheduler URL to simple URLs
          18{ # Skype federation
            $error.clear()
            Write-Log -Type Divider -NoConsole
            # probably should do some version checking
            # need to verify Lync connection
            Write-Log -Type Info -Message "Option $ServerConfigOption (Skype Federation)" -NoConsole
            if (Set-ModuleStatus -name Lync){
              if (Get-CsPublicProvider -identity 'MSN' -ErrorAction SilentlyContinue){
                Write-Log -Type Info -Message 'Removing MSN Public Provider' -Indent 1
                Remove-CsPublicProvider -identity 'MSN'
              } else {
                Write-Log -Type Info -Message 'Public Provider MSN does not exist' -NoConsole -Indent 1
              }
              if (-Not (Get-CsPublicProvider -identity Skype -ErrorAction SilentlyContinue)){
                Write-Log -Type Info -Message 'Adding Skype Public Provider' -Indent 1
                 New-CsPublicProvider -Identity Skype -ProxyFqdn federation.messenger.msn.com -IconUrl 'https://images.edge.messenger.live.com/Messenger_16x16.png' -VerificationLevel UseSourceVerification -Enabled $true
                 Write-Log -Type warn -message 'Users will not see the Skype option until the next time they login to Lync. They must also be assigned an external access policy that is enabled for communications with public users.' -Indent 1
              } else {                
                Write-Log -Type Warn -Message 'Public Provider Skype already exists' -NoConsole -Indent 1
                Set-CsPublicProvider -Identity Skype -Enabled $true
              }
            }
          } # end Skype federation
          19{ # Temporarily block the installation of unsupported .NET Framework
            # https://support.microsoft.com/en-us/kb/3133990
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Temporarily block the installation of the unsupported .NET Framework)" -NoConsole
            [string] $DotNetWU = 'HKLM:\Software\Microsoft\NET Framework Setup\NDP\WU'
            # TODO: We should find a way to automate the version here with latest supported version
            $DotNetVersionToBlock = '472'
            if (-Not (Get-ItemProperty -Path $DotNetWU -Name "BlockNetFramework$DotNetVersionToBlock" -ErrorAction SilentlyContinue)){
              $null = New-Item -Path $DotNetWU -Force
              $null = New-ItemProperty -Path $DotNetWU -Name "BlockNetFramework$DotNetVersionToBlock" -Value 1 -PropertyType 'DWord' -Force
              if (Get-ItemProperty -Path $DotNetWU -Name "BlockNetFramework$DotNetVersionToBlock"){
                Write-Log -Type Info -Message "Windows Server configured to block installation of the .NET Framework $DotNetVersionToBlock" -Indent 1
              }else{
                Write-Log -Type Error -Message 'Configuration failed.' -Indent 1
              }
            }else{
              Write-Log -Type Warn -Message ".NET Framework $DotNetVersionToBlock already blocked" -Indent 1
            }
          } # end Temporarily block the installation of unsupported .NET Framework
          20{ # UCMA 4.0 - for sefautil.exe
            $error.clear()
            Write-Log -Type Divider -NoConsole
            # probably should check to see if Lync is installed, and throw a warning about best practices
            # http://blogs.technet.com/b/jenstr/archive/2010/12/07/how-to-get-sefautil-running.aspx
            # http://technet.microsoft.com/en-us/library/jj945659.aspx
            # Get-WmiObject -query "SELECT Name,Version FROM win32_product WHERE Name like 'Microsoft Lync Server 2013, Front End Server'" ` -ComputerName $env:ComputerName | ft Name, Version -AutoSize

            Write-Log -Type Info -Message "Option $ServerConfigOption (Microsoft Unified Communications Managed API 4.0, Runtime - for sefautil.exe)" -NoConsole
            if (-Not ($DownloadOnly)){
              Set-ModuleStatus -name ServerManager
              # Windows Identity Foundation is required to install the local configuration store
              # Server-Media-Foundation is required
              # Needs SQL instance RtcLocal
              $RestartNeeded = (Add-WindowsFeature -Name $WinFeatUCMA4).RestartNeeded
              if ($error){
                Write-Log -Type Error -Message $error
                Write-Log -Type Error -Message 'An error has occurred. Exiting.'
                Stop-Script
              }
              Write-Log -Type Info -Message 'Checking if restart is needed' -NoConsole
              if ($RestartNeeded -eq 'Yes'){
                Write-Log -Type Warn -Message 'Restart is required' -NoConsole -Indent 1
                $RestartRequired = $true
                if ((New-Popup -Message $PrereqRebootPromptWarning -Title 'Restart is required' -Buttons YesNo -Icon Question) -eq 6){
                  Write-Log -Type Info -Message 'User chose to reboot' -NoConsole
                  Set-RunOnce
                  Stop-Script -Reboot
                } else {
                  Write-Log -Type Warn -Message 'User chose NOT to reboot' -NoConsole
                  Stop-Script
                }
              }else{
                Write-Log -Type Info -Message 'Restart is NOT needed' -NoConsole -Indent 1
              }
              if (-Not (Get-ItemProperty -Path "$UninstallKey\{41D635FE-4F9D-47F7-8230-9B29D6D42D31}" -ErrorAction SilentlyContinue)){
                New-FileDownload -SourceFile $URLucmaruntime
                New-ProgramInstallation -InstallFile "$TargetFolder\$($URLucmaruntime | Split-Path -leaf)" -InstallSwitches '-q'
                # also Visual C++
              } else {
                Write-Log -Type Warn -Message "`"Microsoft Unified Communications Managed API 4.0, Runtime`" is already installed" -Indent 1
              }
            }else{
              Write-Log -Type Info -Message $DownloadOnlyWarning -NoConsole
              New-FileDownload -SourceFile $URLucmaruntime
            }
          } # end UCMA 4.0 - for sefautil.exe
          21{ # Start Windows Update
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Start Windows Update)" -NoConsole
            if (-Not ($IsSrv2016 -or $IsSrv2019)){
              # Invoke-Expression "$env:windir\system32\wuapp.exe startmenu"
              & "$env:windir\system32\wuapp.exe" startmenu
              Write-Log -Type Info -Message 'Exiting script so that Windows Update can run & reboot (if needed).' -Indent 1
              Stop-Script
            }else{
              Write-Log -Type Warn -Message 'This option not available for Windows Server 2016/2019' -Indent 1
            }
          } # end Start Windows Update
          22{ # Add Trusted Root Certification Authorities to Edge Servers
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Add Trusted Root Certification Authorities to Edge Servers)" -NoConsole
            Add-TrustedRootCertsToEdge
          } # end Add Trusted Root Certification Authorities to Edge Servers
          23{ # Enable Enhanced Experience for Meetings Hosted on Skype for Business On-premises
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Enable Enhanced Experience for Meetings Hosted on Skype for Business On-premises)" -NoConsole
            try{
              Get-CsWebServiceConfiguration | Set-CsWebServiceConfiguration -MeetingUxUseCdn $True -MeetingUxEnableTelemetry $True -JoinLauncherCdnTimeout (New-TimeSpan -Seconds 10)
              Write-Log -Type Warn -Message 'WARNING: If more Front-End servers are deployed later, rerun this option to ensure all are configured the same.' -Indent 1
            }
            # catch [ParameterBindingException]{
            catch {
              Write-Log -Type Error -Message 'Operation failed. This feature requires CU5 to be installed.'
              $ErrorMessage = $_.Exception.Message
              $FailedItem = $_.Exception.ItemName
              Write-Log -Type Info -Message "Error message: $ErrorMessage" -NoConsole
              # Write-Log -Type Info -Message $FailedItem
            }
          } # end Enable Enhanced Experience for Meetings Hosted on Skype for Business On-premises
          24{ # MS Teams PowerShell module - requires PowerShell 5.1 or later
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Microsoft Teams PowerShell module)" -NoConsole
            if ([version] ($PSVersionTable).PSVersion -lt 5.1){
              Write-Log -Type Warn -Message 'Microsoft Teams PowerShell module requires PowerShell version 5.1 or later, which is not installed on this machine. Please install a supported version of PowerShell and try again.'
            }
            try{
              if ([Activator]::CreateInstance([Type]::GetTypeFromCLSID([Guid]'{DCB00C01-570F-4A9B-8D69-199FDBA5723B}')).IsConnectedToInternet){
                Write-Log -Type Info -Message 'Internet access detected' -NoConsole -Indent 1
                if (-Not (Get-Module -ListAvailable -Name MicrosoftTeams)){
                  # first, we install NuGet, which is required to use the 'Install-Module' command for modules in the Gallery
                  Write-Log -Type Info -Message 'Installing NuGet' -Indent 1
                  $null = Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
                  [string] $NuGetVersion = (Get-PackageProvider -Name NuGet).Version
                  Write-Log -Type Info -Message "NuGet $NuGetVersion installed" -NoConsole -Indent 2
                  Write-Log -Type Info -Message 'Installing Microsoft Teams PowerShell module' -Indent 1
                  Install-Module -Name MicrosoftTeams -SkipPublisherCheck -Force
                  [string] $TeamsVersion = (Get-Module -ListAvailable -Name MicrosoftTeams).Version
                  Write-Log -Type Info -Message "Teams module $TeamsVersion installed" -NoConsole -Indent 2
                }else{
                  Write-Log -Type Warn -Message 'Microsoft Teams PowerShell module already installed' -Indent 1
                }
              }else {
                Write-Log -Type Warn -Message 'No Internet access detected'
              }
            }
            catch [Management.Automation.CommandNotFoundException] {
              Write-Log -Type Error -Message 'Installation of Teams PowerShell module failed!'
              Write-Log -Type Error -Message "The Microsoft Teams module requires PowerShell v5.1 or later to install. Please update your PowerShell version (current version: $PowerShellVersion) and try again."
            }
            catch{
              Write-Log -Type Error -Message 'Installation of Teams PowerShell module failed!'
              Write-Log -Type Error -Message $_
            }
          } # end MS Teams PowerShell module
          25{ # SMB file share
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (file share)" -NoConsole
            New-FeShare
          } # end SMB file share
          26{ # Disable Windows Admin Console prompt (WS2019)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Disable WAC prompt)" -NoConsole
            Disable-WacPrompt
          } # end Disable Windows Admin Console prompt (WS2019)
          27{ # Disable power management on NICs
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $ServerConfigOption (Disable power management on NICs)" -NoConsole
            # TODO: Update
            # Set-NICPowerManagement -Disable
          } # end Disable power management on NICs
        } # end switch
      } while ($ServerConfigOption -NotMatch {^99$|^x$|^exit$})
    } # end Misc server config menu
    60{ # Desktop shortcut menu
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Desktop shortcut menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying desktop menu' -NoConsole
        $DesktopOption = Read-Host -Prompt $DesktopMenu
        switch ($DesktopOption) {
          1{ #Logoff tile
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Logoff tile)" -NoConsole
            # New-Tile Logoff
            New-Tile -ShortcutTitle 'Windows Logoff' -ShortcutPath "$env:Public\Desktop\Logoff.lnk" -ShortcutTargetPath "$env:SystemRoot\System32\logoff.exe" -ShortcutIcon 44
          } # end Logoff tile
          2{  # Restart tile
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Restart tile)" -NoConsole
            New-Tile -ShortcutTitle 'Windows Restart' -ShortcutPath "$env:Public\Desktop\Restart.lnk" -ShortcutTargetPath "$env:SystemRoot\System32\shutdown.exe" -ShortcutArguments '-r -t 0' -ShortcutIcon 238
          } # end Restart tile
          3{ # Shutdown tile
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Shutdown tile)" -NoConsole
            New-Tile -ShortcutTitle 'Windows Shutdown' -ShortcutPath "$env:Public\Desktop\Shutdown.lnk" -ShortcutTargetPath "$env:SystemRoot\System32\shutdown.exe" -ShortcutArguments '-s -t 0' -ShortcutIcon 27
          } # end Shutdown tile
          4{ # Windows Update tile
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Windows Update tile)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option is not available for Windows Server 2019'
              Break
            }
            New-Tile -ShortcutTitle 'Windows Update' -ShortcutPath "$env:Public\Desktop\Windows Update.lnk" -ShortcutTargetPath "$env:SystemRoot\System32\wuauclt.exe" -ShortcutArguments '/ShowWUAutoScan' -ShortcutIcon 46
            <#
                /RunHandlerComServer
                /RunStoreAsComServer
                /ShowSettingsDialog
                /ResetAuthorization
                /ResetEulas
                /ShowWindowsUpdate
                /CloseWindowsUpdate
                /SelfUpdateManaged
                /SelfUpdateUnmanaged
                /UpdateNow
                /ShowWUAutoScan
                /ShowFeaturedUpdates - does not seem to work in Server 2012
                /ShowFeaturedOptInDialog - does not seem to work in Server 2012
            #>
          } # end Windows Update tile
          5{ # Management Shell
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Management Shell tile)" -NoConsole
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Management Shell.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Management Shell.lnk" -Destination $env:UserProfile\Desktop
              }            
            }
            if ($skype4b){
              if (Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server\Skype for Business Server Management Shell.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server\Skype for Business Server Management Shell.lnk" -Destination $env:UserProfile\Desktop
              }
            }
            if ($skype4b2019){
              if (Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Management Shell.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Management Shell.lnk" -Destination $env:UserProfile\Desktop
              }
            }            
          } # end Management Shell
          6{ # Deployment Wizard
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Deployment Wizard tile)" -NoConsole
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Deployment Wizard.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Deployment Wizard.lnk" -Destination $env:UserProfile\Desktop
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2015\Skype for Business Server Deployment Wizard.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2015\Skype for Business Server Deployment Wizard.lnk" -Destination $env:UserProfile\Desktop
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Deployment Wizard.lnk"){
                Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Deployment Wizard.lnk" -Destination $env:UserProfile\Desktop
              }
            }
          } # end Deployment Wizard
          7{ # Control Panel
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Lync Server Control Panel tile)" -NoConsole
            if ($lync2013){
              if (Test-Path -Path "$env:CommonProgramFiles\Microsoft Lync Server 2013\AdminUIHost.exe"){
                New-Tile -ShortcutTitle 'Lync Server Control Panel' -ShortcutPath "$env:Public\Desktop\Lync Server Control Panel.lnk" -ShortcutTargetPath "$env:CommonProgramFiles\Microsoft Lync Server 2013\AdminUIHost.exe" -ShortcutIconLibrary "$env:SystemRoot\Installer\{6408FD69-B5A4-48C7-9484-F3EA3C847279}\Icon_ControlPanel" -ShortcutIcon 0
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2015\AdminUIHost.exe"){
                New-Tile -ShortcutTitle 'Skype for Business Server Control Panel' -ShortcutPath "$env:Public\Desktop\Skype for Business Server Control Panel.lnk" -ShortcutTargetPath "$env:CommonProgramFiles\Skype for Business Server 2015\AdminUIHost.exe" -ShortcutIconLibrary "$env:SystemRoot\Installer\{9D5751C8-F6AC-4A33-9704-B1D2EB1769B6}\Icon_ControlPanel" -ShortcutIcon 0
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2019\AdminUIHost.exe"){
                New-Tile -ShortcutTitle 'Skype for Business Server Control Panel' -ShortcutPath "$env:Public\Desktop\Skype for Business Server Control Panel.lnk" -ShortcutTargetPath "$env:CommonProgramFiles\Skype for Business Server 2019\AdminUIHost.exe" -ShortcutIconLibrary "$env:SystemRoot\Installer\{9D5751C8-F6AC-4A33-9704-B1D2EB1769B6}\Icon_ControlPanel" -ShortcutIcon 0
              }
            }
          } # end Control Panel
          8{ # Exchange UM Integration Utility (OcsUmUtil)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Exchange UM Integration Utility (OcsUmUtil) tile)" -NoConsole
            if (Test-Path -Path "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe"){
              Write-Log -Type Info -Message 'User opted to create shortcut for OCSLogger Logging Tool' -NoConsole -Indent 1
              New-Tile -ShortcutTitle 'OCS UM Util' -ShortcutPath "$env:Public\Desktop\OcsUmUtil.lnk" -ShortcutTargetPath "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe" -ShortcutIconLibrary "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe" -ShortcutIcon 0
            }elseif(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2015\Support\OcsUmUtil.exe"){
              Write-Log -Type Info -Message 'User opted to create shortcut for OCSLogger Logging Tool' -NoConsole -Indent 1
              New-Tile -ShortcutTitle 'OCS UM Util' -ShortcutPath "$env:Public\Desktop\OcsUmUtil.lnk" -ShortcutTargetPath "$env:CommonProgramFiles\Skype for Business Server 2015\Support\OcsUmUtil.exe" -ShortcutIconLibrary "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe" -ShortcutIcon 0
            }else{
              Write-Log -Type warn -Message 'Resource kit not installed. Reselect this option after installation.' -Indent 1
            }
          } # end Exchange UM Integration Utility (OcsUmUtil)
          9{ # Snooper
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Snooper tile)" -NoConsole
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\snooper.exe"){
                New-Tile -ShortcutTitle 'Snooper' -ShortcutPath "$env:Public\Desktop\Snooper.lnk" -ShortcutTargetPath "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\snooper.exe" -ShortcutIconLibrary "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\snooper.exe" -ShortcutIcon 0
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\Snooper.exe"){New-Tile -ShortcutTitle 'Snooper' -ShortcutPath "$env:Public\Desktop\Snooper.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\Snooper.exe" -ShortcutIconLibrary "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\Snooper.exe" -ShortcutIcon 0
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\ClsAgent\Snooper.exe"){New-Tile -ShortcutTitle 'Snooper' -ShortcutPath "$env:Public\Desktop\Snooper.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2019\ClsAgent\Snooper.exe" -ShortcutIconLibrary "$env:ProgramFiles\Skype for Business Server 2019\ClsAgent\Snooper.exe" -ShortcutIcon 0
              }
            }
          } # end Snooper
          10{ # OCS Logger/CLS Logger
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (OCS Logger/CLS Logger tile)" -NoConsole
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe"){
                New-Tile -ShortcutTitle 'OCSLogger' -ShortcutPath "$env:Public\Desktop\OCSLogger.lnk" -ShortcutTargetPath "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe" -ShortcutIconLibrary "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\OCSLogger.exe" -ShortcutIcon 0
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\ClsLogger.exe"){
                New-Tile -ShortcutTitle 'CLSLogger' -ShortcutPath "$env:Public\Desktop\CLSLogger.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\ClsLogger.exe" -ShortcutIconLibrary "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\ClsLogger.exe" -ShortcutIcon 0
              }else{
                Write-Log -Type warn -Message 'Skype for Business Server 2015 Debugging Tools not installed. Reselect this option after installation.' -Indent 1
              }
            }
            if ($Skype4b2019){              
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\ClsLogger.exe"){
                New-Tile -ShortcutTitle 'CLSLogger' -ShortcutPath "$env:Public\Desktop\CLSLogger.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\ClsLogger.exe" -ShortcutIconLibrary "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\ClsLogger.exe" -ShortcutIcon 0
              }else{
                Write-Log -Type warn -Message 'Skype for Business 2019 Debugging Tools not installed. Reselect this option after installation.' -Indent 1
              }
            }
          } # end OCS Logger/CLS Logger
          11{ # Topology Builder            
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Topology Builder tile)" -NoConsole            
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                New-Tile -ShortcutTitle 'Lync Server Topology Builder' -ShortcutPath "$env:Public\Desktop\Lync Server Topology Builder.lnk" -ShortcutTargetPath "$env:ProgramFiles\Microsoft Lync Server 2013\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -ShortcutIconLibrary "$env:SystemRoot\Installer\{6408FD69-B5A4-48C7-9484-F3EA3C847279}\Icon_TopoBuilder" -ShortcutIcon 0
              }
            }            
            if ($skype4b){
              if (Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                New-Tile -ShortcutTitle 'Skype for Business Server Topology Builder' -ShortcutPath "$env:Public\Desktop\Skype for Business Server Topology Builder.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2015\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -ShortcutIconLibrary "$env:SystemRoot\Installer\{9D5751C8-F6AC-4A33-9704-B1D2EB1769B6}\Icon_TopoBuilder" -ShortcutIcon 0
              }
            }
            if ($skype4b2019){
              if (Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                New-Tile -ShortcutTitle 'Skype for Business Server Topology Builder' -ShortcutPath "$env:Public\Desktop\Skype for Business Server Topology Builder.lnk" -ShortcutTargetPath "$env:ProgramFiles\Skype for Business Server 2019\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -ShortcutIconLibrary "$env:ProgramFiles\Skype for Business Server 2019\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -ShortcutIcon 0
              }
            }
          } # end Topology Builder
          12{ # Certificate Management (local machine)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Certificate Management (local machine) tile)" -NoConsole
            if (Test-Path -Path "$env:SystemRoot\system32\Certlm.msc"){
              New-Tile -ShortcutTitle 'Certificate Management' -ShortcutPath "$env:Public\Desktop\Certificate Management.lnk" -ShortcutTargetPath "$env:SystemRoot\system32\Certlm.msc" -ShortcutIconLibrary "$env:SystemRoot\system32\mmc.exe" -ShortcutIcon 0
            }
          } # end Certificate Management (local machine)
          13{ # Active Directory Users and Computers (ADUC)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Active Directory Users and Computers (ADUC) tile)" -NoConsole
            if (Test-Path -Path "$env:SystemRoot\system32\dsa.msc"){
              New-Tile -ShortcutTitle 'Active Directory Users and Computers' -ShortcutPath "$env:Public\Desktop\Active Directory Users and Computers.lnk" -ShortcutTargetPath "$env:SystemRoot\system32\dsa.msc" -ShortcutIconLibrary "$env:SystemRoot\system32\dsadmin.dll" -ShortcutIcon 0
            }else{
              Write-Log -Type warn -Message 'Active Directory tools not installed. Reselect this option after installation.' -Indent 1
            }
          } # end Active Directory Users and Computers (ADUC)
          14{ # Message Analyzer
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Active Directory Users and Computers (ADUC) tile)" -NoConsole
            if (Test-Path -Path "$env:ProgramFiles\Microsoft Message Analyzer\MessageAnalyzer.exe"){
              New-Tile -ShortcutTitle 'Microsoft Message Analyzer' -ShortcutPath "$env:Public\Desktop\Microsoft Message Analyzer.lnk" -ShortcutTargetPath "$env:ProgramFiles\Microsoft Message Analyzer\MessageAnalyzer.exe" -ShortcutIconLibrary "$env:ProgramFiles\Microsoft Message Analyzer\MessageAnalyzer.exe" -ShortcutIcon 0
            }else{
              Write-Log -Type warn -Message 'Microsoft Message Analyzer not installed. Reselect this option after installation.' -Indent 1
            }
          } # end Message Analyzer
          15{ # Hosts file
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DesktopOption (Shortcut to edit hosts file)" -NoConsole
            New-Shortcut -Name "$env:public\Desktop\Edit Hosts File.lnk" -File "$env:windir\system32\notepad.exe" -WorkingDir "$env:windir\system32\drivers\etc" -Description 'Hosts file' -Arguments "$env:windir\system32\drivers\etc\hosts"
          } # end Hosts file
        } # end switch
      } while ($DesktopOption -NotMatch {^99$|^x$|^exit$})
    } # end Desktop shortcut menu
    70{ # Taskbar shortcut menu
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Taskbar shortcut menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying taskbar menu' -NoConsole
        $TaskbarOption = Read-Host -Prompt $TaskbarMenu
        switch ($TaskbarOption) {
          1{ # Management Shell            
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Management Shell)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Management Shell.lnk"){
                Set-PinnedApp -File "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Microsoft Lync Server 2013\Lync Server Management Shell.lnk" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if (Test-Path -Path "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2015\Skype for Business Server Management Shell.lnk"){
                Set-PinnedApp -File "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2015\Skype for Business Server Management Shell.lnk" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){              
              if (Test-Path -Path "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Management Shell.lnk"){
                Set-PinnedApp -File "$env:AllUsersProfile\Microsoft\Windows\Start Menu\Programs\Skype for Business Server 2019\Skype for Business Server Management Shell.lnk" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
          } # end Management Shell
          2{  # Deployment Wizard
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Deployment Wizard)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Deployment\Deploy.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Microsoft Lync Server 2013\Deployment\Deploy.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Deploy.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Deploy.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Deployment\Deploy.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2019\Deployment\Deploy.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
          } # end Deployment Wizard
          3{ # Control panel            
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Control panel)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:CommonProgramFiles\Microsoft Lync Server 2013\AdminUIHost.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Microsoft Lync Server 2013\AdminUIHost.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2015\AdminUIHost.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Skype for Business Server 2015\AdminUIHost.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2019\AdminUIHost.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Skype for Business Server 2019\AdminUIHost.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            
          } # end Control panel
          4{ # Exchange UM Integration Utility (OcsUmUtil)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Exchange UM Integration Utility (OcsUmUtil))" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Microsoft Lync Server 2013\Support\OcsUmUtil.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2015\Support\OcsUmUtil.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Skype for Business Server 2015\Support\OcsUmUtil.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:CommonProgramFiles\Skype for Business Server 2019\Support\OcsUmUtil.exe"){
                Set-PinnedApp -File "$env:CommonProgramFiles\Skype for Business Server 2019\Support\OcsUmUtil.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            } 
          } # end Exchange UM Integration Utility (OcsUmUtil)
          5{ # Snooper
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Snooper)" -NoConsole            
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\snooper.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\snooper.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\snooper.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\snooper.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){ # this seems to be for Server 2019
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\ClsAgent\snooper.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2019\ClsAgent\snooper.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation'
              }
            }
            # TODO: Verify this works for SfB 2019 on Win Server 2016. If so, adjust IF statement above for $IsSrv2019
            if ($skype4b2019 -and $IsSrv2016){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\snooper.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\snooper.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation'
              }
            }
          } # end Snooper
          6{ # OCS/CLS logger            
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (OCS/CLS logger)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Microsoft Lync Server 2013\Debugging Tools\ocslogger.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation.'
              }
            }
            if ($skype4b){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\clslogger.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2015\Debugging Tools\clslogger.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Resource Kit not installed. Reselect this option after installation.'
              }
            }
            if ($skype4b2019){
              if(Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\clslogger.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2019\Debugging Tools\clslogger.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Skype for Business Server 2019 Debugging Tools not installed. Reselect this option after installation.'
              }
            }
          } # end OCS/CLS logger
          7{ # Topology Builder
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Topology Builder)" -NoConsole
            if ($IsSrv2019){
              Write-Log -Type Warn -Message 'This option does not work in Windows Server 2019'
              Break
            }
            if ($lync2013){
              if (Test-Path -Path "$env:ProgramFiles\Microsoft Lync Server 2013\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Microsoft Lync Server 2013\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b){
              if (Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2015\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2015\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }
            if ($skype4b2019){
              if (Test-Path -Path "$env:ProgramFiles\Skype for Business Server 2019\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe"){
                Set-PinnedApp -File "$env:ProgramFiles\Skype for Business Server 2019\Administrative Tools\Microsoft.Rtc.Management.TopologyBuilder.exe" -Pin
              }else{
                Write-Log -Type Info -Message 'Core Components not installed. Reselect this option after installation'
              }
            }            
          } # end Topology Builder
          8{ # REMOVE shortcut for PowerShell
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (REMOVE shortcut for PowerShell)" -NoConsole
            Set-PinnedApp -File "$PSHOME\powershell.exe" -unpin
          } # end REMOVE shortcut for PowerShell
          9{ # Certificate Management (local machine)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Certificate Management (local machine))" -NoConsole
            if (Test-Path -Path "$env:SystemRoot\system32\Certlm.msc"){
              Set-PinnedApp -File "$env:SystemRoot\system32\Certlm.msc" -Pin
            }
          } # end Certificate Management (local machine)
          10{ # Active Directory Users and Computers (ADUC)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Active Directory Users and Computers (ADUC))" -NoConsole
            if (Test-Path -Path "$env:SystemRoot\system32\dsa.msc"){
              Set-PinnedApp -File "$env:SystemRoot\system32\dsa.msc" -Pin
            }
          } # end Active Directory Users and Computers (ADUC)
          11{ # Message Analyzer
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (Message Analyzer)" -NoConsole
            if (Test-Path -Path "$env:ProgramFiles\Microsoft Message Analyzer\MessageAnalyzer.exe"){
              Set-PinnedApp -File "$env:ProgramFiles\Microsoft Message Analyzer\MessageAnalyzer.exe" -Pin
            }
          } # end Message Analyzer
          12{ # REMOVE Windows Store App (Windows 2012 R2)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (REMOVE Windows Store App (Windows 2012 R2))" -NoConsole
            if ($IsSrv2016 -or $IsSrv2019){
              Write-Log -Type Warn -Message 'This option is for Windows Server 2012 R2 only'
              Break
            }
            if (Test-Path -Path "$env:USERPROFILE\Store.lnk"){
              Set-PinnedApp -File "$env:USERPROFILE\Store.lnk" -unpin
            }
          } # end REMOVE Windows Store App (Windows 2012 R2)
          13{ # WireShark
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $TaskbarOption (WireShark)" -NoConsole
            if (Test-Path -Path "$env:ProgramFiles\Wireshark\Wireshark-gtk.exe"){
              Set-PinnedApp -File "$env:ProgramFiles\Wireshark\Wireshark-gtk.exe" -Pin
            }
          } # end WireShark
        } # end switch
      } while ($TaskbarOption -NotMatch {^99$|^x$|^exit$})
    } # end Taskbar shortcut menu
    80{ # Download menu
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Downloads menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying downloads menu' -NoConsole
        $DownloadOption = Read-Host -Prompt $DownloadMenu
        switch ($DownloadOption) {
          1{ # Latest Cumulative Update
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Latest Cumulative Update)" -NoConsole
            New-FileDownload -SourceFile $URLLatestCu -IgnoreLocalCopy
          } # end Latest Cumulative Update
          2{ # Watcher Node and Online PowerShell module
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Watcher Node and Online PowerShell module)" -NoConsole
            New-FileDownload -SourceFile $URLwatchernode
            New-FileDownload -SourceFile $URLSkypeOnlineModule
          } # end Watcher Node and Online PowerShell module
          3{ # SCOM Management Pack and Documentation
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (SCOM Management Pack and Documentation)" -NoConsole
            New-FileDownload -SourceFile $URLscommgmtpack
            if ($URLscommgmtpackdoc){New-FileDownload -SourceFile $URLscommgmtpackdoc}
          } # end SCOM Management Pack and Documentation
          4{ # RASK            
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Lync 2013 Rollout and Adoption Success Kit (RASK))" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLraskusereducation
            New-FileDownload -SourceFile $URLraskcoreplanning
            # New-FileDownload -SourceFile $URLraskresources
          } # end RASK
          5{ # SDN
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype for Business, SDN Interface)" -NoConsole
            New-FileDownload -SourceFile $URLsdninstallationguide
            New-FileDownload -SourceFile $URLsdnreleasenotes
            New-FileDownload -SourceFile $URLsdnchm
            New-FileDownload -SourceFile $URLsdnschemad
            New-FileDownload -SourceFile $URLsdnschema
            New-FileDownload -SourceFile $URLsdnlistener
            New-FileDownload -SourceFile $URLsdnmgr
          } # end SDN
          6{ # Lync/SfB Online Admin components
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Lync/Skype for Business Online components)" -NoConsole
            if ($skype4b2019){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business 2019' -Indent 1
              Break
            }
            # Microsoft Online Services Sign-in Assistant
            New-FileDownload -SourceFile $URLMsOnlineServicesSignInAssistant

            # Windows Azure Active Directory Module for Windows PowerShell
            New-FileDownload -SourceFile $URLAzureAdModule
              
            # Skype for Business Online, Windows PowerShell Module
            New-FileDownload -SourceFile $URLSkypeOnlineModule
          } # end Lync/SfB Online Admin components
          7{ # UNUSED - DOES NOT APPEAR IN MENU
          } # end Event Zero connector
          8{ # Network Assessment Tool
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Network Assessment Tool)" -NoConsole
            New-FileDownload -SourceFile $URLNetworkAssessmentTool
          } # end Network Assessment Tool
          9{ # Bandwidth Calculator
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Bandwidth Calculator)" -NoConsole
            New-FileDownload -SourceFile $URLBandwidthCalulator
            New-FileDownload -SourceFile $URLBandwidthCalulatorReleaseNotes
            New-FileDownload -SourceFile $URLBandwidthCalulatorUserGuide
          } # end Bandwidth Calculator
          10{ # Adoption portal
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype for Business Adoption portal)" -NoConsole
            if (-Not($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLAdoptionPortal
          } # end Adoption portal
          11{ # Meeting Migration Tool
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Meeting Migration Tool)" -NoConsole
            New-FileDownload -SourceFile $URLMeetingMigrationTool32 -DestFolder "$TargetFolder\MeetingMigrationTool\32"
            New-FileDownload -SourceFile $URLMeetingMigrationTool64 -DestFolder "$TargetFolder\MeetingMigrationTool\64"
          } # end Meeting Migration Tool
          12{ # Cloud Center Edition
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Cloud Center Edition)" -NoConsole
            if (-Not($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLCce
          } # end Cloud Center Edition
          13{ # Post Move Cleanup Tool
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype for Business Post Move Cleanup Tool)" -NoConsole
            New-FileDownload -SourceFile $URLSkypePostMoveCleanupTool
          } # end Post Move Cleanup Tool
          14{ # Call Quality Dashboard
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Call Quality Dashboard)" -NoConsole
            if (-Not($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLcqd
          } # end Call Quality Dashboard
          15{ # Real-Time Statistics Manager (StatsMan)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Real-Time Statistics Manager (StatsMan))" -NoConsole
            if (-Not($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only'
              Break
            }
            New-FileDownload -SourceFile $URLStatsManPerfAgent
            New-FileDownload -SourceFile $URLStatsManListener
            New-FileDownload -SourceFile $URLStatsManWebSite
            New-FileDownload -SourceFile $URLStatsManUpdate
          } # end Real-Time Statistics Manager (StatsMan)
          16{ # IIS Crypto
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (IIS Crypto)" -NoConsole
            New-FileDownload -SourceFile $URLiiscrypto
          } # end IIS Crypto
          17{ # Skype for Business Basic Client
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype for Business Basic Client)" -NoConsole
            if ($skype4b2019){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business 2019' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLBasicClient64
            New-FileDownload -SourceFile $URLBasicClient32
          } # end Skype for Business Basic Client
          18{ # Skype Room System Administrative Web Portal
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype Room System Administrative Web Portal)" -NoConsole
            if (-Not ($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLSkypeRoomSystemAdminPortal
          } # end Skype Room System Administrative Web Portal
          19{ # Key Health Indicators for Lync Server 2013 and Skype for Business Server 2015/2019
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Key Health Indicators)" -NoConsole
            New-FileDownload -SourceFile $URLkhi
          } # end Key Health Indicators for Lync Server 2013 and Skype for Business Server 2015/2019
          20{ # Skype for Business Server 2015 - 180 Day Eval .iso
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $DownloadOption (Skype for Business Server 2015 - 180 Day Eval .iso)" -NoConsole
            if (-Not ($skype4b)){
              Write-Log -Type Warn -Message 'This option is available for Skype for Business 2015 only' -Indent 1
              Break
            }
            New-FileDownload -SourceFile $URLSfBEval
          } # end Skype for Business Server 2015 - 180 Day Eval .iso
        } # end switch
      } while ($DownloadOption -NotMatch {^99$|^x$|^exit$})
    } # end Download menu
    90{ # Security menu
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Taskbar shortcut menu)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Do {
        Write-Log -Type Divider -NoConsole
        Write-Log -Type Info -Message 'Displaying security menu' -NoConsole
        $TaskbarOption = Read-Host -Prompt $SecurityMenu
        switch ($TaskbarOption) {
          1{ # Disable SSL 2
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable SSL 2)" -NoConsole
            $IsSSL3Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
            if ($IsSSL2Enabled){
              # Disable SSL 2.0 (PCI Compliance)
              $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force
              $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name Enabled -Value 0 -PropertyType 'DWord' -Force
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Name Enabled -Value 0 -PropertyType 'DWord' -Force
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name DisabledByDefault -Value 1 -PropertyType 'DWord' -Force
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Name DisabledByDefault -Value 1 -PropertyType 'DWord' -Force
              $RestartRequired = $true
              $IsSSL2Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
              if (-Not $IsSSL2Enabled){
                Write-Log -Type Warn -Message 'SSL 2.0 is now disabled. A reboot is required before the change takes effect.' -Indent 1
              }else{
                Write-Log -Type Error -Message 'An error occurred attempting to disable SSL 2.0' -Indent 1
              }
            }else{
              Write-Log -Type Warn -Message 'SSL 2.0 is already disabled' -Indent 1
            }
          } # end Disable SSL 2
          2{ # Disable SSL 3 (POODLE protection)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable SSL 3)" -NoConsole
            $IsSSL3Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
            if ($IsSSL3Enabled){
              if ((New-Popup -Message 'At this time, there is no official guidance on protecting against POODLE. It is accepted that disabling SSL 3.0 would help provide protection, but it comes with its own issues. The biggest being that disabling SSL 3.0 will break connectivity for Windows XP clients with IE6/7. For more information, see https://technet.microsoft.com/library/security/3009008. Do you wish to disable SSL 3.0?' -Title 'Disable SSL 3.0' -Buttons YesNo -Icon Question) -eq 6){
                # Disable SSL 3.0 (PCI Compliance) and enable 'POODLE' attack protection
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name Enabled -Value 0 -PropertyType 'DWord' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Name Enabled -Value 0 -PropertyType 'DWord' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name DisabledByDefault -Value 1 -PropertyType 'DWord' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Name DisabledByDefault -Value 1 -PropertyType 'DWord' -Force
                $RestartRequired = $true
                $IsSSL3Enabled = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0
                if (-Not $IsSSL3Enabled){
                  Write-Log -Type Warn -Message 'SSL 3.0 is now disabled. A reboot is required before the change takes effect.' -Indent 1
                }else{
                  Write-Log -Type Error -Message 'An error occurred attempting to disable SSL 3.0' -Indent 1
                }
              }
            }else{
              Write-Log -Type Warn -Message 'SSL 3.0 is already disabled' -Indent 1
            }
          } # end Disable SSL 3 (POODLE protection)
          3{ # EnableSessionTicket: Event IDs 32402, 61045 are logged in Lync Server 2013 Front End servers that are installed on Windows Server 2012 R2
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Suppress event IDs 32402, 61045)" -NoConsole
            # http://support2.microsoft.com/kb/2901554
            if ($IsSrv2012R2){
              New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL' -Name EnableSessionTicket -Value 2 -PropertyType 'DWord' -Force
              if (Get-Command -module lync){
                Stop-CsWindowsService
                # make sure everything stopped
                Start-CsWindowsService
                # make sure everything started
              }
            }else{
              Write-Log -Type Warn -Message 'This server is not running Windows 2012 R2' -Indent 1
            }
          } # end EnableSessionTicket: Event IDs 32402, 61045 are logged in Lync Server 2013 Front End servers that are installed on Windows Server 2012 R2
          4{ # Disable RC4 Cipher
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable RC4 Cipher)" -NoConsole
            if ($IsSrv2016 -or $IsSrv2019){
              Write-Log -Type Warn -Message 'This option is not available for this operating system'
              Break
            }
            if ($IsSrv2012){
              # Install hotfix from https://support.microsoft.com/en-us/kb/2868725
              New-FileDownload -SourceFile $URLdisablerc4patch
            }            
            try{
              Write-Log -Type Info -Message 'Checking current status of RC4 cipher' -NoConsole -Indent 1
              if (((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0) -or ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0) -or ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0) -or ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 64/128' -Name Enabled -ErrorAction SilentlyContinue).Enabled -ne 0)){
                Write-Log -Type Info -Message 'Disabling RC4 cipher' -Indent 1
                # We have to use the following method or the keys don't get created correctly due to the forward slashes
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC4 128/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                       
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC4 56/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                        
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC4 40/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()

                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC4 64/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()

                Write-Log -Type Warn -Message 'RC4 cipher disabled. A reboot is required before the change takes effect.' -Indent 1    
                $RebootRequired = $true
              }else{
                Write-Log -Type Warn -Message 'RC4 cipher is already disabled' -Indent 1
              }
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }
            
          } # end Disable RC4 Cipher
          5{ # Lync Edge Server Replication failed FALSE with red cross
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Lync Edge Server Replication failed FALSE with red cross)" -NoConsole
            if (-Not ($lync2013)){
              Write-Log -Type Warn -Message 'This option is not available for Skype for Business' -Indent 1
              Break
            }
            New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL' -Name ClientAuthTrustMode -Value 2 -PropertyType 'DWord' -Force
            Restart-Computer -Force
          } # end Lync Edge Server Replication failed FALSE with red cross
          6{ # Disable SMBv1
            # https://support.microsoft.com/en-us/help/2696547/how-to-enable-and-disable-smbv1,-smbv2,-and-smbv3-in-windows-vista,-windows-server-2008,-windows-7,-windows-server-2008-r2,-windows-8,-and-windows-server-2012
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable SMBv1)" -NoConsole
            Disable-Smbv1Protocol
            <#
                if (-Not (Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSmb1Protocol)){
                Write-Log -Type Warn -Message 'SMBv1 already disabled' -Indent 1
                }else{
                Write-Log -Type Info -Message 'Disabling SMBv1' -NoConsole -Indent 1
                Set-SmbServerConfiguration -EnableSMB1Protocol $false -Confirm:$false
                Write-Log -Type Warn -Message 'SMBv1 disabled. A reboot is required before the change takes effect.' -Indent 1    
                $RebootRequired = $true
                }
            #>
          } # end Disable SMBv1
          7{ # Set LmCompatibilityLevel to 5 (NTLM2 only)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Set LmCompatibilityLevel to 5 (NTLM2 only))" -NoConsole
            # https://technet.microsoft.com/en-us/library/cc960646.aspx
            # Windows XP:  0
            # Windows 2003: 2
            # Vista/2008: 3
            # Win7/2008 R2: 3 
            If (-Not (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\' -Name LmCompatibilityLevel -ErrorAction SilentlyContinue).LmCompatibilityLevel -eq 5){
              Write-Log -Type Info -Message 'Setting LmCompatibilityLevel to 5 (NTLMv2 only)' -NoConsole
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\' -Name LmCompatibilityLevel -Value 5 -PropertyType 'DWord' -Force
              Write-Log -Type Warn -Message 'LmCompatibilityLevel set to 5 (NTLM2 only). A reboot is required before the change takes effect.' -Indent 1    
              $RestartRequired = $true
            }else{
              Write-Log -Type Warn -Message 'LmCompatibilityLevel already set to 5 (NTLM2 only)' -Indent 1
            }
          } # end set LmCompatibilityLevel to 5 (NTLM2 only)
          8{ # Disable Link-Local Multicast Name Resolution (LLMNR)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable Link-Local Multicast Name Resolution (LLMNR))" -NoConsole
            if (-Not (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name EnableMulticast -ErrorAction SilentlyContinue).EnableMulticast -eq 1){
              Write-Log -Type Info -Message 'Disabling Link-Local Multicast Name Resolution (LLMNR)' -NoConsole -Indent 1
              $null = New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Force
              $null = New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name EnableMulticast -Value 1 -PropertyType 'DWord' -Force
              Write-Log -Type Warn -Message 'Link-Local Multicast Name Resolution (LLMNR) disabled. A reboot is required before the change takes effect.' -NoConsole -Indent 2
            }else{
              Write-Log -Type Warn -Message 'Link-Local Multicast Name Resolution (LLMNR) already disabled' -Indent 1
            }
          } # end Disable Link-Local Multicast Name Resolution (LLMNR)
          9{ # Disable NetBIOS Name Service (NBTNS)
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable NetBIOS Name Service (NBTNS))" -NoConsole
            try{
              Write-Log -Type Info -Message 'Checking initial settings for all NICs' -Indent 1
              $adapters = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled = 'true'" )
              ForEach ($adapter in $adapters){
                $ThisNic = (Get-WmiObject -Class Win32_NetworkAdapter | Where-Object {$_.Index -eq $adapter.index} | Select-Object -Property NetConnectionId).NetConnectionId
                Write-Log -Type Info -Message "NIC: $ThisNic ($($adapter.Description))" -NoConsole -Indent 2
                Write-Log -Type Info -Message "NetBIOS: $($adapter.TcpipNetbiosOptions)" -NoConsole -Indent 3
              }
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }

            try{
              Write-Log -Type Info -Message 'Disabling NetBIOS Name Service (NBTNS)' -NoConsole -Indent 1
              $adapters = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled = 'true'" )
              ForEach ($adapter in $adapters){
                $null = $adapter.SetTcpipNetbios(2)
              }
              Write-Log -Type Warn -Message 'NetBIOS Name Service (NBTNS) disabled. A reboot is required before the change takes effect.' -Indent 2
              $RestartRequired = $true
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }

            try{
              Write-Log -Type Info -Message 'Checking final settings for all NICs' -NoConsole -Indent 1
              $adapters = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled = 'true'" | Select-Object -Property Index,Description,TcpipNetbiosOptions)
              ForEach ($adapter in $adapters){
                # $ThisNic = Get-WmiObject -Class Win32_NetworkAdapter | Where-Object {$_.Index -eq $adapter.index}
                $ThisNic = (Get-WmiObject -Class Win32_NetworkAdapter | Where-Object {$_.Index -eq $adapter.index} | Select-Object -Property NetConnectionId).NetConnectionId
                Write-Log -Type Info -Message "NIC: $ThisNic ($($adapter.Description))" -NoConsole -Indent 2
                Write-Log -Type Info -Message "NetBIOS: $($adapter.TcpipNetbiosOptions)" -NoConsole -Indent 3
              }
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }            
          } # end Disable NetBIOS Name Service (NBTNS)
          10{ # Configure longer Diffie-Hellman ephemeral (DHE) key shares
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Configure longer Diffie-Hellman ephemeral (DHE) key shares)" -NoConsole
            if ( -Not (Test-Path -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman')){
              Write-Log -Type Info -Message 'Configuring longer Diffie-Hellman ephemeral (DHE) key shares for TLS servers' -NoConsole
              $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms' -Name 'Diffie-Hellman' -Force
              Write-Log -Type Info -Message 'Setting to enable 2048 modulus size' -Indent 1
              $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -Name ServerMinKeyBitLength -Value 2048 -Force
              $RestartRequired = $true
            }elseif ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -Name ServerMinKeyBitLength).ServerMinKeyBitLength -eq 2048){
              Write-Log -Type Warn -Message 'Longer Diffie-Hellman ephemeral (DHE) key shares already configured for 2048 modulus size' -Indent 1
            }else{
              Write-Log -Type Warn -Message 'Unexpected Diffie-Helmman ephemeral (DHE) key share configuration. Please investigate.' -Indent 1
              }
          } # end Configure longer Diffie-Hellman ephemeral (DHE) key shares
          11{ # Disable PCT 1.0
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable PCT 1.0)" -NoConsole
            try{
                Write-Log -Type Info -Message 'Disabling PCT 1.0' -Indent 1
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Name DisabledByDefault -Value 1
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Name DisabledByDefault -Value 1
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Name Enabled -Value 0
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Name Enabled -Value 0
                $RebootRequired = $true
                Write-Log -Type Warn -Message 'PCT 1.0 disabled. A reboot is required before the change takes effect.' -Indent 1
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            } 
          } # end Disable PCT 1.0
          12{ # Disable weak ciphers
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable weak ciphers)" -NoConsole
            try{
                Write-Log -Type Info -Message 'Disabling DES 56/56' -Indent 1
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('DES 56/56')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                $RebootRequired = $true
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }
            try{
                Write-Log -Type Info -Message 'Disabling NULL' -Indent 1
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\NULL' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\NULL' -Name Enabled -Value 0
                $RebootRequired = $true
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }
            try{
                Write-Log -Type Info -Message 'Disabling RC2' -Indent 1
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC2 128/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC2 40/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC2 56/128')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                $Key = (Get-Item -Path HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $True).CreateSubKey('RC2 56/56')
                $Key.SetValue('Enabled', '0', [Microsoft.Win32.RegistryValueKind]::DWORD)
                $key.close()
                $RebootRequired = $true
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            }
            Write-Log -Type Warn -Message 'Weak ciphers disabled. A reboot is required before the change takes effect.' -Indent 1
          } # end Disable weak ciphers
          13{ # Disable Multi-Protocol Unified Hello
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Disable Multi-Protocol Unified Hello)" -NoConsole
            try{
                Write-Log -Type Info -Message 'Disabling Multi-Protocol Unified Hello' -Indent 1
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force
                $null = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Force
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Name DisabledByDefault -Value 1
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Name DisabledByDefault -Value 1
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Name Enabled -Value 0
                $null = New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Name Enabled -Value 0
                $RebootRequired = $true
                Write-Log -Type Warn -Message 'Multi-Protocol Unified Hello disabled. A reboot is required before the change takes effect.' -Indent 1
            }
            catch{
              Write-Log -Type Error -Message "Failed with `'$($_.Exception.Message)`'"
            } 
          } # end Disable Multi-Protocol Unified Hello
          14{ # Remove Windows Defender Antivirus
            $error.clear()
            Write-Log -Type Divider -NoConsole
            Write-Log -Type Info -Message "Option $MenuOption (Remove Windows Defender Antivirus)" -NoConsole
            Write-Log -Type Divider -NoConsole
            if (-Not($IsSrv2016 -or $IsSrv2019)){
              Write-Log -Type -Message 'This option is only supported on Windows Server 2016 and 2019' -Indent 1
              Break
            }
            Write-Log -Type Info -Message 'Removing Windows Defender' -NoLog
            Write-Log -Type Info -Message "Removing Windows Features: $(("$WinFeatDefender").Replace(' ', ', '))" -NoConsole
            Set-ModuleStatus -Name ServerManager
            $WindowsFeatures = Remove-WindowsFeature -Name $WinFeatDefender -WarningAction SilentlyContinue
            $RestartNeeded = $WindowsFeatures.RestartNeeded
            Write-Log -Type Info -Message 'Checking if restart is needed' -NoConsole
            if ($RestartNeeded -eq 'Yes'){
              Write-Log -Type Warn -Message 'Restart is required' -NoConsole -Indent 1
              if ((New-Popup -Message $PrereqRebootPromptWarning -Title 'Restart is required' -Buttons YesNo -Icon Question) -eq 6){
                Write-Log -Type Info -Message 'User chose to reboot' -NoConsole -Indent 1
                Set-RunOnce
                Stop-Script -Reboot
              } else {
                Write-Log -Type Warn -Message 'User chose NOT to reboot' -NoConsole
                Stop-Script
              }
            }else{
              Write-Log -Type Info -Message 'Restart is NOT needed' -NoConsole -Indent 1
            }
          } # end remove Windows Defender Antivirus
        } # end switch
      } while ($TaskbarOption -NotMatch {^99$|^x$|^exit$})
    } # end Security menu

    92{ # Configure push notifications
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Lync 2013 push notifications)" -NoConsole
      Write-Log -Type Divider -NoConsole
      # TODO: Validate this applies to Lync only
      if (-Not (Get-CsHostingProvider | Where-Object {$_.proxyfqdn -eq 'sipfed.online.lync.com'})){
        Write-Log -Type Info -Message 'Adding hosting provider'
        New-CsHostingProvider -Identity 'LyncOnline' -Enabled $True -ProxyFqdn 'sipfed.online.lync.com' -VerificationLevel UseSourceVerification
      } else {
        Write-Log -Type Warn -Message 'hosting provider configuration already exists'
      }
      if (-Not (Get-CsAllowedDomain -Identity 'push.lync.com' -ErrorAction SilentlyContinue)){
        Write-Log -Type Info -Message 'Adding allowed domain'
        New-CsAllowedDomain -Identity 'push.lync.com'
      } else {
        Write-Log -Type Warn -Message 'allowed domain already exists'
      }
      if (-Not ((Get-CsAccessEdgeConfiguration).AllowFederatedUsers)){
        Write-Log -Type Info -Message 'Enabling allow federated users'
        Set-CsAccessEdgeConfiguration -AllowFederatedUsers $True
      } else {
        Write-Log -Type Warn -Message 'allow federated users already enabled'
      }
    } # end Configure push notifications    

    95{
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (How to report a bug for this script)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Get-UpdateInfo -Article $Article
    } # end Check for update
    96{ # How to report a bug
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (How to report a bug for this script)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Write-Host $BugReport -ForegroundColor yellow
      Stop-Script
    } # end How to report a bug
    97{ # Visit website for this script
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Visit website for this script)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Test-IsProxyEnabled
      Write-Log -Type Info -Message "Opening default browser and browsing to https://ucunleashed.com/$Article" -NoConsole -Indent 1
      Start-Process -FilePath "https://ucunleashed.com/$Article"
    } # end Visit website for this script
    98{ # Restart computer
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Restart computer)" -NoConsole
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message 'Restarting computer' -NoConsole
      Stop-Script -Reboot
    } # end Restart computer
    {($_ -eq 99) -or ($_ -eq 'x') -or ($_ -eq 'exit')} { # Exit
      $error.clear()
      Write-Log -Type Divider -NoConsole
      Write-Log -Type Info -Message "Option $MenuOption (Exit)" -NoConsole
      Write-Log -Type Divider -NoConsole      
      Invoke-RestartQuery -NoRunOnce
      Stop-Script
    } # end exit
  } # end main switch
} while ($MenuOption -NotMatch {^99$|^98$|^x$|^exit$})
# SIG # Begin signature block
# MIIcdgYJKoZIhvcNAQcCoIIcZzCCHGMCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU1Qk4Ob8EIwghALsqae98+DbS
# Q6igghelMIIFLjCCBBagAwIBAgIQBGzkiH+YUBF7gAQK1UkILzANBgkqhkiG9w0B
# AQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMB4XDTE4MDgzMDAwMDAwMFoXDTE5MTIw
# NDEyMDAwMFowazELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAk1JMRkwFwYDVQQHExBT
# dGVybGluZyBIZWlnaHRzMRkwFwYDVQQKExBJbm5lcnZhdGlvbiwgTExDMRkwFwYD
# VQQDExBJbm5lcnZhdGlvbiwgTExDMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEApUl30DBskezzYb9R3gf330zYDjGCiPGF08f7XXW25qT4pCZalCwMjhVe
# ZVpwbtpClfS02qgk82GbbiST/tsh8AEane8u00eJwIXpQeMQ+ejbs/o+Zi/c7tEb
# 3hb6KUIMnDBcEeVznsPug1i0lt9izNAk04zlnA6aor2QoymZ766VHXy1140fdh9W
# N4pCahsXaWK/iscAOjPWUEhKCfSPQhi7IgfAoMswcLgSint8aJMWDp4LEApyN1x8
# 5snSBl8+GT/bncblPlHcS0NAOJGegDovz/7OoG8rth67JLqcqTbFGHhUpj5mLPBz
# Rf99oamNZIzJJGkpdy9t8flX8mXAbwIDAQABo4IBxTCCAcEwHwYDVR0jBBgwFoAU
# WsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYEFOJ1u602Jcn9h0h/qjd0fBGJ
# nCLxMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNVHR8E
# cDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVk
# LWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTIt
# YXNzdXJlZC1jcy1nMS5jcmwwTAYDVR0gBEUwQzA3BglghkgBhv1sAwEwKjAoBggr
# BgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAIBgZngQwBBAEw
# gYQGCCsGAQUFBwEBBHgwdjAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tME4GCCsGAQUFBzAChkJodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRTSEEyQXNzdXJlZElEQ29kZVNpZ25pbmdDQS5jcnQwDAYDVR0TAQH/
# BAIwADANBgkqhkiG9w0BAQsFAAOCAQEA8Q25M6Fa1dMHNaKJ+QkRny4fRvd8qfAn
# UNTbtsGnG7iP75Q6jLxxC/lrorgjXD9OPHrHC/hbf3QXs4Fax3jYfEWMUhjXbQRB
# KC94ZIKrrHwg2iIumNTCZtXhWiGurYqXi7zW7RjCPJWqGhmRrdGedaOFCWf9wsN2
# VD+ISFYxU4tUXY0eFLIrhJ27BNfPfKPi8uJb4d7we8nvwaRxZ077c9nleYJNIsxQ
# jOubbCUpBx6NBY9Jp8Rp2Zq9EbgjXnpYQ692FQSPRKFEEgUwFpiP9PsdSd4V39Jo
# NGdBEYmOtBCYrA1go/YVk34x/e4EwI9zoBSm1HhLL3VPb2WgbyouujCCBTAwggQY
# oAMCAQICEAQJGBtf1btmdVNDtW+VUAgwDQYJKoZIhvcNAQELBQAwZTELMAkGA1UE
# BhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2lj
# ZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4X
# DTEzMTAyMjEyMDAwMFoXDTI4MTAyMjEyMDAwMFowcjELMAkGA1UEBhMCVVMxFTAT
# BgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEx
# MC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAPjTsxx/DhGvZ3cH0wsx
# SRnP0PtFmbE620T1f+Wondsy13Hqdp0FLreP+pJDwKX5idQ3Gde2qvCchqXYJawO
# eSg6funRZ9PG+yknx9N7I5TkkSOWkHeC+aGEI2YSVDNQdLEoJrskacLCUvIUZ4qJ
# RdQtoaPpiCwgla4cSocI3wz14k1gGL6qxLKucDFmM3E+rHCiq85/6XzLkqHlOzEc
# z+ryCuRXu0q16XTmK/5sy350OTYNkO/ktU6kqepqCquE86xnTrXE94zRICUj6whk
# PlKWwfIPEvTFjg/BougsUfdzvL2FsWKDc0GCB+Q4i2pzINAPZHM8np+mM6n9Gd8l
# k9ECAwEAAaOCAc0wggHJMBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQD
# AgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHkGCCsGAQUFBwEBBG0wazAkBggrBgEF
# BQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRw
# Oi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3J0MIGBBgNVHR8EejB4MDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5jb20v
# RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsMy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsME8GA1UdIARI
# MEYwOAYKYIZIAYb9bAACBDAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdp
# Y2VydC5jb20vQ1BTMAoGCGCGSAGG/WwDMB0GA1UdDgQWBBRaxLl7KgqjpepxA8Bg
# +S32ZXUOWDAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzANBgkqhkiG
# 9w0BAQsFAAOCAQEAPuwNWiSz8yLRFcgsfCUpdqgdXRwtOhrE7zBh134LYP3DPQ/E
# r4v97yrfIFU3sOH20ZJ1D1G0bqWOWuJeJIFOEKTuP3GOYw4TS63XX0R58zYUBor3
# nEZOXP+QsRsHDpEV+7qvtVHCjSSuJMbHJyqhKSgaOnEoAjwukaPAJRHinBRHoXpo
# aK+bp1wgXNlxsQyPu6j4xRJon89Ay0BEpRPw5mQMJQhCMrI2iiQC/i9yfhzXSUWW
# 6Fkd6fp0ZGuy62ZD2rOwjNXpDd32ASDOmTFjPQgaGLOBm0/GkxAG/AeB+ova+YJJ
# 92JuoVP6EpQYhS6SkepobEQysmah5xikmmRR7zCCBmowggVSoAMCAQICEAMBmgI6
# /1ixa9bV6uYX8GYwDQYJKoZIhvcNAQEFBQAwYjELMAkGA1UEBhMCVVMxFTATBgNV
# BAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8G
# A1UEAxMYRGlnaUNlcnQgQXNzdXJlZCBJRCBDQS0xMB4XDTE0MTAyMjAwMDAwMFoX
# DTI0MTAyMjAwMDAwMFowRzELMAkGA1UEBhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0
# MSUwIwYDVQQDExxEaWdpQ2VydCBUaW1lc3RhbXAgUmVzcG9uZGVyMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAo2Rd/Hyz4II14OD2xirmSXU7zG7gU6mf
# H2RZ5nxrf2uMnVX4kuOe1VpjWwJJUNmDzm9m7t3LhelfpfnUh3SIRDsZyeX1kZ/G
# FDmsJOqoSyyRicxeKPRktlC39RKzc5YKZ6O+YZ+u8/0SeHUOplsU/UUjjoZEVX0Y
# hgWMVYd5SEb3yg6Np95OX+Koti1ZAmGIYXIYaLm4fO7m5zQvMXeBMB+7NgGN7yfj
# 95rwTDFkjePr+hmHqH7P7IwMNlt6wXq4eMfJBi5GEMiN6ARg27xzdPpO2P6qQPGy
# znBGg+naQKFZOtkVCVeZVjCT88lhzNAIzGvsYkKRrALA76TwiRGPdwIDAQABo4ID
# NTCCAzEwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAww
# CgYIKwYBBQUHAwgwggG/BgNVHSAEggG2MIIBsjCCAaEGCWCGSAGG/WwHATCCAZIw
# KAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwggFkBggr
# BgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUAIABvAGYAIAB0AGgAaQBzACAA
# QwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4AcwB0AGkAdAB1AHQAZQBzACAA
# YQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQAaABlACAARABpAGcAaQBDAGUA
# cgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQAaABlACAAUgBlAGwAeQBpAG4A
# ZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUAbgB0ACAAdwBoAGkAYwBoACAA
# bABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkAIABhAG4AZAAgAGEAcgBlACAA
# aQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUAcgBlAGkAbgAgAGIAeQAgAHIA
# ZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMVMB8GA1UdIwQYMBaAFBUAEisT
# mLKZB+0e36K+Vw0rZwLNMB0GA1UdDgQWBBRhWk0ktkkynUoqeRqDS/QeicHKfTB9
# BgNVHR8EdjB0MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRBc3N1cmVkSURDQS0xLmNybDA4oDagNIYyaHR0cDovL2NybDQuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmwwdwYIKwYBBQUHAQEEazBpMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKG
# NWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRENB
# LTEuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQCdJX4bM02yJoFcm4bOIyAPgIfliP//
# sdRqLDHtOhcZcRfNqRu8WhY5AJ3jbITkWkD73gYBjDf6m7GdJH7+IKRXrVu3mrBg
# JuppVyFdNC8fcbCDlBkFazWQEKB7l8f2P+fiEUGmvWLZ8Cc9OB0obzpSCfDscGLT
# Ykuw4HOmksDTjjHYL+NtFxMG7uQDthSr849Dp3GdId0UyhVdkkHa+Q+B0Zl0DSbE
# Dn8btfWg8cZ3BigV6diT5VUW8LsKqxzbXEgnZsijiwoc5ZXarsQuWaBh3drzbaJh
# 6YoLbewSGL33VVRAA5Ira8JRwgpIr7DUbuD0FAo6G+OPPcqvao173NhEMIIGzTCC
# BbWgAwIBAgIQBv35A5YDreoACus/J7u6GzANBgkqhkiG9w0BAQUFADBlMQswCQYD
# VQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGln
# aWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0Ew
# HhcNMDYxMTEwMDAwMDAwWhcNMjExMTEwMDAwMDAwWjBiMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSEwHwYDVQQDExhEaWdpQ2VydCBBc3N1cmVkIElEIENBLTEwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDogi2Z+crCQpWlgHNAcNKeVlRcqcTSQQaPyTP8
# TUWRXIGf7Syc+BZZ3561JBXCmLm0d0ncicQK2q/LXmvtrbBxMevPOkAMRk2T7It6
# NggDqww0/hhJgv7HxzFIgHweog+SDlDJxofrNj/YMMP/pvf7os1vcyP+rFYFkPAy
# IRaJxnCI+QWXfaPHQ90C6Ds97bFBo+0/vtuVSMTuHrPyvAwrmdDGXRJCgeGDboJz
# PyZLFJCuWWYKxI2+0s4Grq2Eb0iEm09AufFM8q+Y+/bOQF1c9qjxL6/siSLyaxhl
# scFzrdfx2M8eCnRcQrhofrfVdwonVnwPYqQ/MhRglf0HBKIJAgMBAAGjggN6MIID
# djAOBgNVHQ8BAf8EBAMCAYYwOwYDVR0lBDQwMgYIKwYBBQUHAwEGCCsGAQUFBwMC
# BggrBgEFBQcDAwYIKwYBBQUHAwQGCCsGAQUFBwMIMIIB0gYDVR0gBIIByTCCAcUw
# ggG0BgpghkgBhv1sAAEEMIIBpDA6BggrBgEFBQcCARYuaHR0cDovL3d3dy5kaWdp
# Y2VydC5jb20vc3NsLWNwcy1yZXBvc2l0b3J5Lmh0bTCCAWQGCCsGAQUFBwICMIIB
# Vh6CAVIAQQBuAHkAIAB1AHMAZQAgAG8AZgAgAHQAaABpAHMAIABDAGUAcgB0AGkA
# ZgBpAGMAYQB0AGUAIABjAG8AbgBzAHQAaQB0AHUAdABlAHMAIABhAGMAYwBlAHAA
# dABhAG4AYwBlACAAbwBmACAAdABoAGUAIABEAGkAZwBpAEMAZQByAHQAIABDAFAA
# LwBDAFAAUwAgAGEAbgBkACAAdABoAGUAIABSAGUAbAB5AGkAbgBnACAAUABhAHIA
# dAB5ACAAQQBnAHIAZQBlAG0AZQBuAHQAIAB3AGgAaQBjAGgAIABsAGkAbQBpAHQA
# IABsAGkAYQBiAGkAbABpAHQAeQAgAGEAbgBkACAAYQByAGUAIABpAG4AYwBvAHIA
# cABvAHIAYQB0AGUAZAAgAGgAZQByAGUAaQBuACAAYgB5ACAAcgBlAGYAZQByAGUA
# bgBjAGUALjALBglghkgBhv1sAxUwEgYDVR0TAQH/BAgwBgEB/wIBADB5BggrBgEF
# BQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBD
# BggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6oDigNoY0aHR0cDovL2Ny
# bDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDA6oDig
# NoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9v
# dENBLmNybDAdBgNVHQ4EFgQUFQASKxOYspkH7R7for5XDStnAs0wHwYDVR0jBBgw
# FoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQEFBQADggEBAEZQPsm3
# KCSnOB22WymvUs9S6TFHq1Zce9UNC0Gz7+x1H3Q48rJcYaKclcNQ5IK5I9G6OoZy
# rTh4rHVdFxc0ckeFlFbR67s2hHfMJKXzBBlVqefj56tizfuLLZDCwNK1lL1eT7EF
# 0g49GqkUW6aGMWKoqDPkmzmnxPXOHXh2lCVz5Cqrz5x2S+1fwksW5EtwTACJHvzF
# ebxMElf+X+EevAJdqP77BzhPDcZdkbkPZ0XN1oPt55INjbFpjE/7WeAjD9KqrgB8
# 7pxCDs+R1ye3Fu4Pw718CqDuLAhVhSK46xgaTfwqIa1JMYNHlXdx3LEbS0scEJx3
# FMGdTy9alQgpECYxggQ7MIIENwIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UE
# ChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYD
# VQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBAhAE
# bOSIf5hQEXuABArVSQgvMAkGBSsOAwIaBQCgeDAYBgorBgEEAYI3AgEMMQowCKAC
# gAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsx
# DjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBS4fWjNmBYGZ5I1z70W/d/r
# B1cbPTANBgkqhkiG9w0BAQEFAASCAQChMG/dKw0onbAW+uX4Fz4FGEz40kPDca8e
# Gm61MtQOKm0nnxKF8SDI7fzGlW9pGXyn9sDV7GGFvC60JrAMZo03R9A0Na18WwOu
# 6Cn4d1WYU8Uc2gD0SF3GxwPgqvOOovnDuGoo0DiHrECv8t+qtbp/PE5Md0xs61xU
# CMfw6GLfz6+ds6pe80hiZ/LeuhYH3uHwpUgBlq65/p08c90b0w+9KWBLC5IaKc/P
# rDCFM3ENgelEsJB5mSKJs2qH5rk0j3y2UobPhsjaGPCbnY+he4MiZSOGCfAfr1h1
# kDuthsjJaRq3uGugUiDofzr1KxS9rYXwS2qDSLHdHyu3l3sOFXjgoYICDzCCAgsG
# CSqGSIb3DQEJBjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UE
# AxMYRGlnaUNlcnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkG
# BSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0xOTA4MTIyMjUxNThaMCMGCSqGSIb3DQEJBDEWBBTwDWE6tJVzbtp8ujiz
# JA4lWx8f3jANBgkqhkiG9w0BAQEFAASCAQBPrktov5pgRcpsPyAvvslwbOzfKR+P
# EPjzmroiu2UzEmE6uP8ITU0Sr5LMbcWr1D8fPI+f1pjZBKw5QDhSKRfejgXpG/8k
# DnnT+k0zBpTdHuTgChTofUxWoo/MwpTAwFZ5JjpEo0mNOD7WOjVBNour1bkZBEhd
# 0MpO6XlUROwHSmHsrKih1n7sKGwDPExCngF7hf+usDkXfDcYM36rB5fauT30x0qj
# baSWRtR2vO0IIvmeQ4CTfErTNbc3/xht7Xmmi57FFCm6k24I0MD/NHaeGJyvMuRd
# nEVUi8J7qGRuDC9XAcLv088DLn6UZzCxWHG4Nx+n40npXKo3V8IdSEnH
# SIG # End signature block
